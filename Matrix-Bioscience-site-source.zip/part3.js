
/* ---------- render ---------- */
var app = $('#app');
function toast(msg) {
  var w = $('#toasts'); if (!w) return;
  var d = document.createElement('div'); d.className = 'toast'; d.textContent = msg; w.appendChild(d);
  setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 4200);
}
async function copyText(text, msg) {
  try { await navigator.clipboard.writeText(text); toast(msg || tr('Copié', 'Copied')); return; } catch (e) { /* fall through */ }
  try {
    var ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0';
    document.body.appendChild(ta); ta.select(); var ok = document.execCommand('copy'); document.body.removeChild(ta);
    toast(ok ? (msg || tr('Copié', 'Copied')) : tr('Sélectionnez le texte et copiez-le manuellement.', 'Select the text and copy it manually.'));
  } catch (e2) { toast(tr('Sélectionnez le texte et copiez-le manuellement.', 'Select the text and copy it manually.')); }
}
async function saveFile(name, data) { if (!cap.dl) { toast(tr('Téléchargement indisponible dans cette vue.', 'Download unavailable in this view.')); return; } try { await cap.dl.save({ filename: name, data: data }); } catch (e) { /* declined */ } }

function viewFor(r) {
  if (r === 'domaines') return viewDomains();
  if (r === 'articles') return viewArticles();
  if (r === 'comite') return viewBoard();
  if (r === 'auteurs') return viewGuidelines();
  if (r === 'politiques') return viewPolicies();
  if (r === 'contact') return viewContact();
  if (r === 'soumettre') return viewSubmit();
  if (r === 'suivi') return viewTrack();
  if (r === 'editorial') return viewAdmin();
  return viewHome();
}
function renderView() {
  var v = $('#view'); if (!v) return;
  v.innerHTML = viewFor(route);
  if (pending) { var el = document.getElementById(pending); pending = null; if (el) setTimeout(function () { el.scrollIntoView({ block: 'start' }); }, 30); }
}
function renderAll() {
  app.innerHTML = headerHTML() + '<main id="view" tabindex="-1"></main>' + footerHTML();
  renderView();
}
function setRoute() {
  var h = (location.hash || '').replace(/^#/, '');
  route = ROUTES.indexOf(h) >= 0 ? h : 'accueil';
  renderAll();
  if (!pending) window.scrollTo(0, 0);
  if (route === 'suivi') { track.subs = null; track.status = {}; track.err = ''; loadTrack(); }
}

/* ---------- editorial edit helpers ---------- */
function newMember() { return { id: uid2(), name: '', role: 'associate', aff: '', country: '', expertise: '', orcid: '', bio: '', photo: '' }; }
function newArticle() { return { id: uid2(), title: '', authors: '', type: 'research', area: 'C', date: '', issue: '', doi: '', abstract: '', pdf: '', link: '' }; }
function armed(el, label) {
  if (el.getAttribute('data-armed')) return true;
  el.setAttribute('data-armed', '1'); el.setAttribute('data-orig', el.textContent); el.textContent = label;
  setTimeout(function () { if (el.isConnected) { el.removeAttribute('data-armed'); el.textContent = el.getAttribute('data-orig'); } }, 4000);
  return false;
}
function saveMember() {
  var d = adm.edit.data;
  if (!d.name.trim() || !d.aff.trim()) { adm.edit.err = tr('Nom et institution sont requis.', 'Name and institution are required.'); renderView(); return; }
  if (d.orcid.trim() && !/^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$/.test(d.orcid.trim())) { adm.edit.err = tr('Format ORCID invalide.', 'Invalid ORCID format.'); renderView(); return; }
  var m = Object.assign({}, d, { name: d.name.trim(), aff: d.aff.trim(), orcid: d.orcid.trim() });
  var i = -1; DATA.board.forEach(function (x, k) { if (x.id === m.id) i = k; });
  if (i >= 0) DATA.board[i] = m; else DATA.board.push(m);
  adm.edit = null; markDirty(); renderView(); toast(tr('Membre enregistré. Pensez à publier.', 'Member saved. Remember to publish.'));
}
function saveArticle() {
  var d = adm.edit.data;
  if (!d.title.trim() || !d.authors.trim()) { adm.edit.err = tr('Titre et auteurs sont requis.', 'Title and authors are required.'); renderView(); return; }
  if (d.link.trim() && !/^https?:\/\//i.test(d.link.trim())) { adm.edit.err = tr('Le lien doit commencer par https://', 'The link must start with https://'); renderView(); return; }
  var a = Object.assign({}, d, { title: d.title.trim(), authors: d.authors.trim(), doi: d.doi.trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i, ''), link: d.link.trim() });
  var i = -1; DATA.articles.forEach(function (x, k) { if (x.id === a.id) i = k; });
  if (i >= 0) DATA.articles[i] = a; else DATA.articles.push(a);
  adm.edit = null; markDirty(); renderView(); toast(tr('Article enregistré. Pensez à publier.', 'Article saved. Remember to publish.'));
}
function saveSettings(form) {
  var fd = new FormData(form), em = String(fd.get('email') || '').trim();
  if (em && !/^\S+@\S+\.\S+$/.test(em)) { toast(tr('Adresse e-mail invalide.', 'Invalid email address.')); return; }
  DATA.settings = { email: em, issn: String(fd.get('issn') || '').trim(), publisher: String(fd.get('publisher') || '').trim(), issue: String(fd.get('issue') || '').trim(), address: String(fd.get('address') || '').trim(), open: !!fd.get('open') };
  markDirty(); toast(tr('Paramètres enregistrés. Pensez à publier.', 'Settings saved. Remember to publish.'));
}
async function saveStatus(ref) {
  var sel = $('#st-sel'), note = $('#st-note');
  if (!sel || !cap.db) return;
  var now = new Date().toISOString();
  try {
    await cap.db.doc('status/' + ref).set({ ref: ref, status: sel.value, updatedAt: now });
    await cap.db.doc('notes/' + ref).set({ ref: ref, text: note.value, updatedAt: now });
    toast(tr('Statut enregistré', 'Status saved'));
  } catch (er) { toast(tr('Enregistrement impossible', 'Could not save') + (er && er.code ? ' (' + er.code + ')' : '')); }
}

/* ---------- events ---------- */
document.addEventListener('click', function (e) {
  var t = e.target;
  var cp = t.closest && t.closest('[data-copy]');
  if (cp) { copyText(cp.getAttribute('data-copy')); return; }
  var sc = t.closest && t.closest('[data-scroll]');
  if (sc) { e.preventDefault(); var el0 = document.getElementById(sc.getAttribute('data-scroll')); if (el0) el0.scrollIntoView({ block: 'start' }); return; }
  var dm = t.closest && t.closest('[data-dom]');
  if (dm) { pending = 'dom-' + dm.getAttribute('data-dom'); if (route === 'domaines') { e.preventDefault(); renderView(); } return; }
  var ar = t.closest && t.closest('[data-area]');
  if (ar) { F.area = ar.getAttribute('data-area'); step = 0; done = null; saveDraft(); return; }
  var well = t.closest && t.closest('.well[data-row]');
  if (well) { pending = 'dom-' + well.getAttribute('data-row'); if (location.hash === '#domaines') { renderView(); } else { location.hash = 'domaines'; } return; }
  var a = t.closest && t.closest('[data-act]');
  if (!a) return;
  var act = a.getAttribute('data-act'), i = parseInt(a.getAttribute('data-i'), 10);
  if (act === 'closeOv') { if (a.id === 'ovbg' && t !== a) return; $('#ov').innerHTML = ''; return; }
  if (act === 'lang') { lang = lang === 'fr' ? 'en' : 'fr'; lsSet('mb-lang', lang); document.documentElement.setAttribute('lang', lang); renderAll(); return; }
  if (act === 'theme') {
    var cur = document.documentElement.getAttribute('data-theme');
    if (!cur) cur = (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
    var nx = cur === 'dark' ? 'light' : 'dark'; document.documentElement.setAttribute('data-theme', nx); lsSet('mb-theme', nx); return;
  }
  if (act === 'menu') { var top = $('#top'); var o = top.classList.toggle('open'); a.setAttribute('aria-expanded', o ? 'true' : 'false'); return; }
  if (act === 'step') {
    var to = parseInt(a.getAttribute('data-to'), 10);
    if (to > step) { var er = validate(step); if (Object.keys(er).length) { errs = er; renderView(); firstBad(); return; } }
    errs = {}; step = to; renderView(); window.scrollTo(0, 0); return;
  }
  if (act === 'addAuthor') { F.authors.push({ name: '', aff: '', country: '', email: '', orcid: '', corr: false }); saveDraft(); renderView(); return; }
  if (act === 'delAuthor') { var wasC = F.authors[i].corr; F.authors.splice(i, 1); if (wasC && F.authors.length) F.authors[0].corr = true; saveDraft(); renderView(); return; }
  if (act === 'corr') { F.authors.forEach(function (x, k) { x.corr = k === i; }); saveDraft(); return; }
  if (act === 'rmFile') { var kind = a.getAttribute('data-kind'); F[kind].splice(i, 1); saveDraft(); renderView(); return; }
  if (act === 'resetForm') { if (!armed(a, tr('Confirmer l’effacement', 'Confirm clearing'))) return; F = blankForm(); step = 0; errs = {}; lsSet('mb-draft', ''); renderView(); return; }
  if (act === 'newSub') { done = null; step = 0; errs = {}; renderView(); window.scrollTo(0, 0); return; }
  if (act === 'copyPkg') { copyText(packageText(done.rec), tr('Dossier copié', 'File copied')); return; }
  if (act === 'dlPkg') { saveFile('matrix-bioscience-' + done.rec.ref + '.txt', packageText(done.rec)); return; }
  if (act === 'filter') { adm.filter = a.getAttribute('data-v'); var b = $('#adm-body'); if (b) b.innerHTML = subsHTML(); return; }
  if (act === 'openSub') {
    var ref = a.getAttribute('data-ref'), rec = null; adm.subs.forEach(function (r) { if (r.ref === ref) rec = r; });
    if (rec) { $('#ov').innerHTML = openSubHTML(rec); var f = $('#st-sel'); if (f) f.focus(); } return;
  }
  if (act === 'saveStatus') { saveStatus(a.getAttribute('data-ref')); return; }
  if (act === 'tab') { adm.tab = a.getAttribute('data-v'); adm.edit = null; renderView(); return; }
  if (act === 'exportCsv') { exportCsv(); return; }
  if (act === 'mNew') { adm.edit = { kind: 'member', id: 'new', data: newMember(), err: '' }; renderView(); return; }
  if (act === 'mEdit') { adm.edit = { kind: 'member', id: DATA.board[i].id, data: Object.assign(newMember(), DATA.board[i]), err: '' }; renderView(); var n1 = $('#e-name'); if (n1) n1.focus(); return; }
  if (act === 'mDel') { if (!armed(a, tr('Confirmer', 'Confirm'))) return; DATA.board.splice(i, 1); markDirty(); renderView(); return; }
  if (act === 'mUp' && i > 0) { var t1 = DATA.board[i]; DATA.board[i] = DATA.board[i - 1]; DATA.board[i - 1] = t1; markDirty(); renderView(); return; }
  if (act === 'mDown' && i < DATA.board.length - 1) { var t2 = DATA.board[i]; DATA.board[i] = DATA.board[i + 1]; DATA.board[i + 1] = t2; markDirty(); renderView(); return; }
  if (act === 'aNew') { adm.edit = { kind: 'article', id: 'new', data: newArticle(), err: '' }; renderView(); return; }
  if (act === 'aEdit') { adm.edit = { kind: 'article', id: DATA.articles[i].id, data: Object.assign(newArticle(), DATA.articles[i]), err: '' }; renderView(); var n2 = $('#e-title'); if (n2) n2.focus(); return; }
  if (act === 'aDel') { if (!armed(a, tr('Confirmer', 'Confirm'))) return; DATA.articles.splice(i, 1); markDirty(); renderView(); return; }
  if (act === 'cancelEdit') { adm.edit = null; renderView(); return; }
  if (act === 'rmPhoto') { adm.edit.data.photo = ''; renderView(); return; }
  if (act === 'rmPdf') { adm.edit.data.pdf = ''; renderView(); return; }
  if (act === 'publish') { publishSite(); return; }
  if (act === 'copyJson') { copyText(JSON.stringify(DATA, null, 2), tr('JSON copié', 'JSON copied')); return; }
  if (act === 'dlJson') { saveFile('matrix-bioscience-contenu.json', JSON.stringify(DATA, null, 2)); return; }
});

function onField(e) {
  var t = e.target, v;
  if (!t || !t.getAttribute) return;
  var f = t.getAttribute('data-f');
  if (f) {
    v = t.type === 'checkbox' ? t.checked : t.value; F[f] = v;
    if (errs[f]) { delete errs[f]; var fl = t.closest('.fld'); if (fl) { fl.classList.remove('bad'); var er = $('.err', fl); if (er) er.parentNode.removeChild(er); } }
    if (f === 'abstract') { var c = $('#abs-count'), tt = typeOf(F.type), wc = words(v); if (c) { c.textContent = wc + ' / ' + tt[4] + ' ' + tr('mots', 'words'); c.classList.toggle('over', wc > tt[4]); } }
    if (f === 'type' && e.type === 'change') renderView();
    saveDraft(); return;
  }
  var au = t.getAttribute('data-a');
  if (au) { var p = au.split('.'); F.authors[+p[0]][p[1]] = t.value; if (errs['a' + p[0]] && errs['a' + p[0]][p[1]]) { delete errs['a' + p[0]][p[1]]; var fl2 = t.closest('.fld'); if (fl2) fl2.classList.remove('bad'); } saveDraft(); return; }
  var ed = t.getAttribute('data-e');
  if (ed && adm.edit) { adm.edit.data[ed] = t.value; return; }
  var fa = t.getAttribute('data-fa');
  if (fa) { fArt[fa] = t.value; var l = $('#art-list'); if (l) l.innerHTML = articleList(); return; }
  if (t.id === 'adm-q') { adm.q = t.value; var b = $('#adm-body'); if (b) b.innerHTML = subsHTML(); }
}
document.addEventListener('input', onField);
document.addEventListener('change', function (e) {
  var t = e.target;
  if (t && t.getAttribute) {
    if (t.getAttribute('data-up')) { uploadFile(t); return; }
    if (t.getAttribute('data-eup')) { eupload(t); return; }
  }
  if (t && t.tagName === 'SELECT') onField(e);
});
async function eupload(input) {
  var k = input.getAttribute('data-eup'), file = input.files && input.files[0];
  if (!file || !cap.assets || !adm.edit) return;
  if (file.size > 20 * 1048576) { toast(tr('Fichier trop volumineux (20 Mo maximum).', 'File too large (20 MB maximum).')); return; }
  try {
    toast(tr('Téléversement…', 'Uploading…'));
    var res = await cap.assets.upload(file, file.type ? { type: file.type } : undefined);
    adm.edit.data[k] = res.id; renderView();
  } catch (er) { toast(tr('Téléversement impossible', 'Upload failed') + (er && er.code ? ' (' + er.code + ')' : '')); }
}
document.addEventListener('submit', function (e) {
  var f = e.target; if (!f || !f.getAttribute) return;
  var kind = f.getAttribute('data-form'); if (!kind) return;
  e.preventDefault();
  if (kind === 'submit') doSubmit();
  else if (kind === 'member') saveMember();
  else if (kind === 'article') saveArticle();
  else if (kind === 'settings') saveSettings(f);
});
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape') { var ov = $('#ov'); if (ov && ov.innerHTML) ov.innerHTML = ''; }
  if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.matches && e.target.matches('tr.click')) { e.preventDefault(); e.target.click(); }
});
function hl(e, on) {
  var t = e.target, el = t.closest && (t.closest('.leg[data-dom]') || t.closest('.well[data-row]'));
  var p = $('#plate'); if (!el || !p) return;
  if (on) p.setAttribute('data-hl', el.getAttribute('data-dom') || el.getAttribute('data-row')); else p.removeAttribute('data-hl');
}
document.addEventListener('mouseover', function (e) { hl(e, true); });
document.addEventListener('mouseout', function (e) { hl(e, false); });
document.addEventListener('focusin', function (e) { hl(e, true); });
document.addEventListener('focusout', function (e) { hl(e, false); });
window.addEventListener('hashchange', setRoute);

/* ---------- init ---------- */
async function use(n) { try { if (window.claude && typeof window.claude.use === 'function') return await window.claude.use(n); } catch (e) { /* unavailable */ } return null; }
async function init() {
  document.documentElement.setAttribute('lang', lang);
  setRoute();
  var r = await Promise.all([use('user'), use('db'), use('assets'), use('downloads'), use('artifact')]);
  try { if (r[0]) { cap.admin = !!(await r[0].canEdit()); cap.uid = await r[0].id(); } } catch (e) { /* ignore */ }
  cap.db = r[1]; cap.assets = r[2]; cap.dl = r[3]; cap.art = r[4]; cap.ready = true;
  var keep = route === 'soumettre' && (F.title || F.abstract);
  if (!keep || true) { var y = window.scrollY; renderAll(); window.scrollTo(0, y); }
  if (route === 'suivi') loadTrack();
}
init();
})();
/*MB-END*/
