/*MB-START*/
(function () {
'use strict';

/* ---------- helpers ---------- */
var FONT_URL = 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wdth,wght@12..96,75..100,200..800&family=IBM+Plex+Mono:wght@400;500&family=Newsreader:ital,opsz,wght@0,6..72,300..700;1,6..72,300..700&display=swap';
var $ = function (s, r) { return (r || document).querySelector(s); };
var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ESC[c]; }); }
function nl2p(s) { return String(s || '').split(/\n{2,}/).map(function (p) { return '<p>' + esc(p).replace(/\n/g, '<br>') + '</p>'; }).join(''); }
function uid2() { return Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3); }
function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } }
function words(s) { var m = String(s || '').trim().match(/\S+/g); return m ? m.length : 0; }

var DATA = {};
try { DATA = JSON.parse($('#site-data').textContent) || {}; } catch (e) { DATA = {}; }
DATA.settings = Object.assign({ email: '', issn: '', publisher: '', address: '', open: true, issue: '' }, DATA.settings || {});
DATA.board = Array.isArray(DATA.board) ? DATA.board : [];
DATA.articles = Array.isArray(DATA.articles) ? DATA.articles : [];

var lang = lsGet('mb-lang');
if (lang !== 'fr' && lang !== 'en') lang = /^en/i.test(navigator.language || '') ? 'en' : 'fr';
function tr(fr, en) { return lang === 'fr' ? fr : en; }
var th0 = lsGet('mb-theme');
if (th0 === 'dark' || th0 === 'light') document.documentElement.setAttribute('data-theme', th0);

var cap = { db: null, uid: null, assets: null, dl: null, art: null, admin: false, ready: false };
var route = 'accueil';
var pending = null;
var dirty = false;

var ROUTES = ['accueil', 'domaines', 'articles', 'comite', 'auteurs', 'politiques', 'contact', 'soumettre', 'suivi', 'editorial'];
var NAV = [
  ['accueil', 'Accueil', 'Home'], ['domaines', 'Domaines', 'Fields'], ['articles', 'Articles', 'Articles'],
  ['comite', 'Comité éditorial', 'Editorial board'], ['auteurs', 'Auteurs', 'Authors'],
  ['politiques', 'Politiques', 'Policies'], ['contact', 'Contact', 'Contact']
];

/* ---------- content ---------- */
var DOMAINS = [
  { k: 'A', fr: ['Sciences biologiques', 'Biologie cellulaire et moléculaire, génétique, physiologie, écologie et biodiversité. Des travaux qui expliquent le fonctionnement des organismes et de leurs populations.', ['Biologie cellulaire et moléculaire', 'Génétique et génomique', 'Physiologie', 'Écologie et biodiversité', 'Évolution', 'Biologie du développement']],
    en: ['Biological sciences', 'Cell and molecular biology, genetics, physiology, ecology and biodiversity. Work that explains how organisms and their populations function.', ['Cell and molecular biology', 'Genetics and genomics', 'Physiology', 'Ecology and biodiversity', 'Evolution', 'Developmental biology']] },
  { k: 'B', fr: ['Biotechnologie', 'Outils et procédés qui utilisent le vivant : génie génétique, bioprocédés, biologie synthétique, biotechnologies industrielles et environnementales.', ['Génie génétique et édition du génome', 'Bioprocédés et fermentation industrielle', 'Biologie synthétique', 'Biotechnologie environnementale', 'Bio-informatique et biologie des systèmes', 'Biocapteurs et diagnostic']],
    en: ['Biotechnology', 'Tools and processes built on living systems: genetic engineering, bioprocesses, synthetic biology, industrial and environmental biotechnology.', ['Genetic engineering and genome editing', 'Bioprocesses and industrial fermentation', 'Synthetic biology', 'Environmental biotechnology', 'Bioinformatics and systems biology', 'Biosensors and diagnostics']] },
  { k: 'C', fr: ['Microbiologie', 'Bactéries, virus, champignons et levures, leurs communautés et leurs effets sur la santé, les aliments et les milieux naturels.', ['Bactériologie, virologie, mycologie', 'Microbiotes (intestin, sol, aliments)', 'Probiotiques et souches d’intérêt technologique', 'Résistance aux antimicrobiens', 'Microbiologie alimentaire', 'Métagénomique']],
    en: ['Microbiology', 'Bacteria, viruses, fungi and yeasts, their communities and their effects on health, food and natural environments.', ['Bacteriology, virology, mycology', 'Microbiomes (gut, soil, food)', 'Probiotics and technological strains', 'Antimicrobial resistance', 'Food microbiology', 'Metagenomics']] },
  { k: 'D', fr: ['Biochimie', 'Structure et fonction des molécules du vivant, voies métaboliques et régulation, avec une attention particulière à la nutrition et aux molécules bioactives.', ['Enzymologie', 'Métabolisme et régulation', 'Protéomique et métabolomique', 'Biochimie nutritionnelle', 'Molécules bioactives', 'Stress oxydant et antioxydants']],
    en: ['Biochemistry', 'Structure and function of biological molecules, metabolic pathways and their regulation, with a focus on nutrition and bioactive compounds.', ['Enzymology', 'Metabolism and regulation', 'Proteomics and metabolomics', 'Nutritional biochemistry', 'Bioactive compounds', 'Oxidative stress and antioxidants']] },
  { k: 'E', fr: ['Agriculture', 'Production végétale et animale, sols, protection des cultures et adaptation des systèmes de production au climat.', ['Agronomie et production végétale', 'Élevage et production animale', 'Aquaculture', 'Sols et fertilité', 'Protection des cultures', 'Agriculture durable et climat', 'Ressources génétiques']],
    en: ['Agriculture', 'Crop and animal production, soils, crop protection and the adaptation of production systems to climate.', ['Agronomy and crop production', 'Livestock and animal production', 'Aquaculture', 'Soils and fertility', 'Crop protection', 'Sustainable agriculture and climate', 'Genetic resources']] },
  { k: 'F', fr: ['Systèmes alimentaires', 'De la production à la consommation : chaînes de valeur, sécurité alimentaire et nutritionnelle, politiques publiques, durabilité.', ['Sécurité alimentaire et nutritionnelle', 'Chaînes de valeur', 'Pertes et gaspillage alimentaires', 'Politiques et gouvernance', 'Durabilité et impact environnemental', 'Alimentation et santé publique', 'Savoirs locaux et aliments traditionnels']],
    en: ['Food systems', 'From production to consumption: value chains, food and nutrition security, public policy, sustainability.', ['Food and nutrition security', 'Value chains', 'Food loss and waste', 'Policy and governance', 'Sustainability and environmental impact', 'Diet and public health', 'Local knowledge and traditional foods']] },
  { k: 'G', fr: ['Science des aliments', 'Transformation, conservation, qualité et sécurité sanitaire des aliments, aliments fonctionnels et procédés de fermentation.', ['Transformation et conservation', 'Qualité et sécurité sanitaire', 'Aliments fonctionnels et nutraceutiques', 'Fermentation', 'Analyse sensorielle', 'Emballage', 'Valorisation des coproduits']],
    en: ['Food science', 'Processing, preservation, quality and safety of foods, functional foods and fermentation processes.', ['Processing and preservation', 'Quality and food safety', 'Functional foods and nutraceuticals', 'Fermentation', 'Sensory analysis', 'Packaging', 'By-product valorisation']] },
  { k: 'H', fr: ['Interdisciplinaire', 'Travaux qui relient plusieurs domaines : une approche One Health, un lien entre alimentation et santé, une méthode utile à plusieurs disciplines.', ['One Health', 'Alimentation et santé métabolique', 'Statistiques et modélisation', 'Éthique, biosécurité et réglementation', 'Enseignement des sciences du vivant']],
    en: ['Interdisciplinary', 'Work that connects several fields: a One Health approach, a link between diet and health, a method useful across disciplines.', ['One Health', 'Diet and metabolic health', 'Statistics and modelling', 'Ethics, biosafety and regulation', 'Life science education']] }
];
function dom(k) { for (var i = 0; i < DOMAINS.length; i++) if (DOMAINS[i].k === k) return DOMAINS[i]; return DOMAINS[7]; }
function domName(k) { return dom(k)[lang][0]; }
function domVar(k) { return 'var(--d-' + String(k).toLowerCase() + ')'; }

var TYPES = [
  ['research', 'Article de recherche', 'Original research', 6000, 250, 'Travaux originaux avec méthodes, résultats et discussion.', 'Original work with methods, results and discussion.'],
  ['review', 'Revue de littérature', 'Review article', 8000, 300, 'Synthèse critique et structurée de la littérature sur une question précise.', 'Critical, structured synthesis of the literature on a defined question.'],
  ['short', 'Communication brève', 'Short communication', 3000, 150, 'Résultat préliminaire ou ciblé qui mérite une diffusion rapide.', 'Preliminary or focused finding that deserves fast dissemination.'],
  ['methods', 'Méthodes et protocoles', 'Methods and protocols', 5000, 250, 'Méthode nouvelle ou améliorée, décrite assez précisément pour être reproduite.', 'New or improved method, described precisely enough to be reproduced.'],
  ['perspective', 'Point de vue', 'Perspective', 2000, 150, 'Position argumentée sur une question d’actualité scientifique.', 'Argued position on a current scientific question.'],
  ['data', 'Note de données', 'Data note', 2500, 150, 'Description d’un jeu de données, d’une collection de souches ou d’un génome.', 'Description of a dataset, a strain collection or a genome.']
];
function typeOf(k) { for (var i = 0; i < TYPES.length; i++) if (TYPES[i][0] === k) return TYPES[i]; return TYPES[0]; }
function typeName(k) { var t = typeOf(k); return lang === 'fr' ? t[1] : t[2]; }

var ROLES = [
  ['founder', 'Fondateur', 'Founder', 'Fondation', 'Founding'],
  ['chief', 'Rédacteur en chef', 'Editor-in-Chief', 'Rédaction en chef', 'Editor-in-Chief'],
  ['deputy', 'Rédacteur en chef adjoint', 'Deputy Editor', 'Rédaction en chef adjointe', 'Deputy Editors'],
  ['associate', 'Rédacteur associé', 'Associate Editor', 'Rédacteurs associés', 'Associate Editors'],
  ['scientific', 'Membre du comité scientifique', 'Scientific committee member', 'Comité scientifique', 'Scientific committee'],
  ['advisory', 'Conseil consultatif international', 'International advisory board', 'Conseil consultatif international', 'International advisory board']
];
function roleOf(k) { for (var i = 0; i < ROLES.length; i++) if (ROLES[i][0] === k) return ROLES[i]; return ROLES[4]; }
function roleRank(k) { for (var i = 0; i < ROLES.length; i++) if (ROLES[i][0] === k) return i; return 4; }

var STATUSES = [
  ['received', 'Reçue', 'Received', '--d-h'],
  ['screening', 'Contrôle éditorial', 'Editorial screening', '--d-b'],
  ['review', 'En évaluation', 'Under review', '--d-c'],
  ['revision', 'Révision demandée', 'Revision requested', '--d-f'],
  ['accepted', 'Acceptée', 'Accepted', '--d-a'],
  ['rejected', 'Refusée', 'Declined', '--crit'],
  ['published', 'Publiée', 'Published', '--d-d']
];
function stOf(k) { for (var i = 0; i < STATUSES.length; i++) if (STATUSES[i][0] === k) return STATUSES[i]; return STATUSES[0]; }
function pill(k) { var s = stOf(k); return '<span class="pill" style="--c:var(' + s[3] + ')">' + esc(lang === 'fr' ? s[1] : s[2]) + '</span>'; }

function fmtDate(iso, long) {
  if (!iso) return '';
  var d = new Date(iso);
  if (isNaN(d.getTime())) return String(iso);
  try { return d.toLocaleDateString(lang === 'fr' ? 'fr-FR' : 'en-GB', { day: 'numeric', month: long ? 'long' : 'short', year: 'numeric' }); } catch (e) { return String(iso).slice(0, 10); }
}
function initials(n) { var p = String(n || '?').trim().split(/\s+/); return ((p[0] || '?')[0] + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase(); }
function hue(n) { var h = 0, s = String(n || ''); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return 'var(--d-' + 'abcdefg'[h % 7] + ')'; }
function issnText() { return DATA.settings.issn ? 'ISSN ' + esc(DATA.settings.issn) : tr('ISSN en cours d’attribution', 'ISSN pending'); }
function issueLabel() { return DATA.settings.issue || tr('Volume 1, Numéro 1', 'Volume 1, Issue 1'); }

/* ---------- plate ---------- */
function plateSVG() {
  var rows = 'ABCDEFGH', cols = 12, pitch = 36, R = 14, ox = 38, oy = 34;
  var w = ox + (cols - 1) * pitch + 2 * R + 16, h = oy + 7 * pitch + 2 * R + 14;
  var s = '<svg class="plate" id="plate" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(tr('Microplaque de 96 puits. Chaque rangée de A à H correspond à un domaine de la revue.', '96-well microplate. Each row from A to H stands for one field of the journal.')) + '">';
  s += '<path class="plate-body" d="M26 2 H' + (w - 12) + ' Q' + (w - 2) + ' 2 ' + (w - 2) + ' 12 V' + (h - 12) + ' Q' + (w - 2) + ' ' + (h - 2) + ' ' + (w - 12) + ' ' + (h - 2) + ' H12 Q2 ' + (h - 2) + ' 2 ' + (h - 12) + ' V26 Z"/>';
  var r, c, cx, cy, op;
  for (c = 0; c < cols; c++) s += '<text class="plate-lbl" x="' + (ox + R + c * pitch) + '" y="' + (oy - 6) + '">' + (c + 1) + '</text>';
  for (r = 0; r < 8; r++) {
    cy = oy + R + r * pitch;
    s += '<text class="plate-lbl" x="18" y="' + (cy + 4) + '">' + rows[r] + '</text>';
    for (c = 0; c < cols; c++) {
      cx = ox + R + c * pitch;
      if (c === cols - 1) { s += '<circle class="well blank r-' + rows[r] + '" data-row="' + rows[r] + '" cx="' + cx + '" cy="' + cy + '" r="' + R + '"/>'; }
      else { op = (0.96 - c * 0.078).toFixed(2); s += '<circle class="well r-' + rows[r] + '" data-row="' + rows[r] + '" cx="' + cx + '" cy="' + cy + '" r="' + R + '" fill-opacity="' + op + '"/>'; }
    }
  }
  return s + '</svg>';
}
function logoSVG() {
  return '<svg viewBox="0 0 30 30" aria-hidden="true"><circle cx="9" cy="9" r="6" fill="var(--d-c)"/><circle cx="21" cy="9" r="6" fill="var(--d-a)" fill-opacity=".72"/><circle cx="9" cy="21" r="6" fill="var(--d-b)" fill-opacity=".5"/><circle cx="21" cy="21" r="6" fill="none" stroke="var(--ink-2)" stroke-width="1.5"/></svg>';
}

/* ---------- shell ---------- */
function headerHTML() {
  var nav = NAV.map(function (n) { return '<a href="#' + n[0] + '"' + (route === n[0] ? ' aria-current="page"' : '') + '>' + esc(tr(n[1], n[2])) + '</a>'; }).join('');
  var admin = cap.admin ? '<a class="ibtn admin-link" href="#editorial" title="' + esc(tr('Espace éditorial', 'Editorial desk')) + '"' + (route === 'editorial' ? ' aria-current="page"' : '') + '>' + esc(tr('Éditeur', 'Editor')) + '</a>' : '';
  return '<header class="top" id="top"><div class="wrap">' +
    '<a class="brand" href="#accueil" aria-label="Matrix Bioscience">' + logoSVG() + '<b>Matrix Bioscience</b></a>' +
    '<nav class="nav" aria-label="' + esc(tr('Navigation principale', 'Main navigation')) + '">' + nav + '</nav>' +
    '<div class="tools">' + admin +
    '<button class="ibtn" data-act="lang" aria-label="' + esc(tr('Switch to English', 'Passer en français')) + '">' + (lang === 'fr' ? 'EN' : 'FR') + '</button>' +
    '<button class="ibtn" data-act="theme" aria-label="' + esc(tr('Changer de thème', 'Switch theme')) + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg></button>' +
    '<a class="btn primary sm" href="#soumettre">' + esc(tr('Soumettre', 'Submit')) + '</a>' +
    '<button class="ibtn menu-btn" data-act="menu" aria-label="Menu" aria-expanded="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>' +
    '</div></div></header>';
}
function footerHTML() {
  var s = DATA.settings;
  return '<footer class="foot"><div class="wrap"><div class="foot-grid">' +
    '<div><a class="brand" href="#accueil">' + logoSVG() + '<b>Matrix Bioscience</b></a>' +
    '<p class="muted" style="margin-top:14px;max-width:26em;font-size:16px">' + esc(tr('Revue multidisciplinaire en accès libre : sciences biologiques, biotechnologie, microbiologie, biochimie, agriculture, systèmes alimentaires et science des aliments.', 'Open-access multidisciplinary journal: biological sciences, biotechnology, microbiology, biochemistry, agriculture, food systems and food science.')) + '</p>' +
    '<p class="mono muted" style="margin-top:12px;font-size:12.5px">' + issnText() + (s.publisher ? ' · ' + esc(s.publisher) : '') + '</p></div>' +
    '<div><h4>' + esc(tr('La revue', 'The journal')) + '</h4><ul>' +
    '<li><a href="#domaines">' + esc(tr('Domaines', 'Fields')) + '</a></li><li><a href="#articles">Articles</a></li><li><a href="#comite">' + esc(tr('Comité éditorial', 'Editorial board')) + '</a></li><li><a href="#politiques">' + esc(tr('Politiques', 'Policies')) + '</a></li></ul></div>' +
    '<div><h4>' + esc(tr('Auteurs', 'Authors')) + '</h4><ul>' +
    '<li><a href="#soumettre">' + esc(tr('Soumettre un manuscrit', 'Submit a manuscript')) + '</a></li><li><a href="#suivi">' + esc(tr('Suivre une soumission', 'Track a submission')) + '</a></li><li><a href="#auteurs">' + esc(tr('Instructions aux auteurs', 'Author guidelines')) + '</a></li><li><a href="#contact">Contact</a></li></ul></div>' +
    '</div><small>© 2026 Matrix Bioscience. ' + esc(tr('Les articles sont publiés sous licence Creative Commons CC BY 4.0.', 'Articles are published under a Creative Commons CC BY 4.0 licence.')) + '</small></div></footer>';
}

/* ---------- public views ---------- */
function headHTML(eyebrow, title, lead) {
  return '<section class="page-head"><div class="wrap"><p class="eyebrow">' + eyebrow + '</p><h1>' + esc(title) + '</h1>' + (lead ? '<p>' + esc(lead) + '</p>' : '') + '</div></section>';
}
function legendHTML() {
  return DOMAINS.map(function (d) {
    return '<a class="leg r-' + d.k + '" href="#domaines" data-dom="' + d.k + '"><b>' + d.k + '</b><i></i>' + esc(d[lang][0]) + '</a>';
  }).join('');
}
function articleItem(a) {
  var pdf = a.pdf ? '<a href="/_blob/' + esc(a.pdf) + '" target="_blank" rel="noopener">PDF</a>' : (a.link ? '<a href="' + esc(a.link) + '" target="_blank" rel="noopener">' + esc(tr('Texte intégral', 'Full text')) + '</a>' : '');
  var doi = a.doi ? '<a href="https://doi.org/' + esc(a.doi) + '" target="_blank" rel="noopener">DOI ' + esc(a.doi) + '</a>' : '';
  return '<article class="art"><div class="art-meta"><span class="dot" style="--c:' + domVar(a.area) + '">' + esc(domName(a.area)) + '</span><span>' + esc(typeName(a.type)) + '</span>' +
    (a.date ? '<span>' + esc(fmtDate(a.date, true)) + '</span>' : '') + (a.issue ? '<span>' + esc(a.issue) + '</span>' : '') + '</div>' +
    '<h3>' + esc(a.title) + '</h3><p class="au">' + esc(a.authors) + '</p>' +
    (a.abstract ? '<details><summary>' + esc(tr('Résumé', 'Abstract')) + '</summary><p>' + esc(a.abstract) + '</p></details>' : '') +
    ((pdf || doi) ? '<div class="links">' + pdf + doi + '</div>' : '') + '</article>';
}
function memberHTML(m) {
  var av = m.photo ? '<div class="avatar"><img src="/_blob/' + esc(m.photo) + '" alt="" loading="lazy"></div>' : '<div class="avatar" style="--c:' + hue(m.name) + '" aria-hidden="true">' + esc(initials(m.name)) + '</div>';
  var exp = String(m.expertise || '').split(',').map(function (x) { return x.trim(); }).filter(Boolean);
  return '<div class="member">' + av + '<div><h3>' + esc(m.name) + '</h3><p class="aff">' + esc([m.aff, m.country].filter(Boolean).join(', ')) + '</p>' +
    (exp.length ? '<div class="exp">' + exp.map(function (x) { return '<span class="tag">' + esc(x) + '</span>'; }).join('') + '</div>' : '') +
    (m.bio ? '<p class="bio">' + esc(m.bio) + '</p>' : '') +
    (m.orcid ? '<a class="orcid" href="https://orcid.org/' + esc(m.orcid) + '" target="_blank" rel="noopener">ORCID ' + esc(m.orcid) + '</a>' : '') + '</div></div>';
}
function sortedBoard() {
  return DATA.board.map(function (m, i) { return { m: m, i: i }; }).sort(function (a, b) { return roleRank(a.m.role) - roleRank(b.m.role) || a.i - b.i; }).map(function (x) { return x.m; });
}

function viewHome() {
  var arts = DATA.articles.slice().sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')); }).slice(0, 3);
  var board = sortedBoard().slice(0, 6);
  var steps = [
    [tr('Soumission en ligne', 'Online submission'), tr('Le dossier est déposé avec le manuscrit en PDF et les déclarations.', 'The file is deposited with the PDF manuscript and the declarations.')],
    [tr('Contrôle éditorial', 'Editorial check'), tr('Périmètre, forme, contrôle de similarité et éthique.', 'Scope, format, similarity check and ethics.')],
    [tr('Évaluation', 'Peer review'), tr('Au moins deux relecteurs indépendants, en double anonymat.', 'At least two independent reviewers, double-anonymous.')],
    [tr('Décision', 'Decision'), tr('Accepter, demander une révision ou refuser, avec les rapports.', 'Accept, request a revision or decline, with the reports.')],
    [tr('Révision', 'Revision'), tr('Les auteurs répondent point par point aux relecteurs.', 'Authors reply to the reviewers point by point.')],
    [tr('Publication', 'Publication'), tr('Mise en ligne en accès libre dès la mise en forme terminée.', 'Open-access release as soon as typesetting is done.')]
  ];
  return '<section class="hero"><div class="wrap hero-grid"><div>' +
    '<p class="eyebrow">' + esc(tr('Revue à comité de lecture', 'Peer-reviewed journal')) + ' · ' + issnText() + '</p>' +
    '<h1>Matrix <span>Bioscience</span></h1>' +
    '<p class="lede">' + esc(tr('Revue en accès libre consacrée aux sciences biologiques, à la biotechnologie, à la microbiologie, à la biochimie, à l’agriculture, aux systèmes alimentaires et à la science des aliments. Elle publie des travaux originaux, des revues de littérature et des articles de méthode après évaluation par les pairs.', 'An open-access journal covering the biological sciences, biotechnology, microbiology, biochemistry, agriculture, food systems and food science. It publishes original research, reviews and methods papers after peer review.')) + '</p>' +
    '<div class="cta-row"><a class="btn primary" href="#soumettre">' + esc(tr('Soumettre un manuscrit', 'Submit a manuscript')) + '</a><a class="btn" href="#auteurs">' + esc(tr('Instructions aux auteurs', 'Author guidelines')) + '</a></div>' +
    '<dl class="facts">' +
    '<div><dt>' + esc(tr('Accès libre', 'Open access')) + '</dt><dd>' + esc(tr('Licence CC BY 4.0, lecture gratuite', 'CC BY 4.0 licence, free to read')) + '</dd></div>' +
    '<div><dt>' + esc(tr('Évaluation par les pairs', 'Peer review')) + '</dt><dd>' + esc(tr('Double anonymat, deux relecteurs au minimum', 'Double-anonymous, two reviewers minimum')) + '</dd></div>' +
    '<div><dt>' + esc(tr('Publication continue', 'Continuous publication')) + '</dt><dd>' + esc(tr('Chaque article paraît dès qu’il est prêt', 'Each article appears as soon as it is ready')) + '</dd></div>' +
    '<div><dt>' + esc(tr('Deux langues', 'Two languages')) + '</dt><dd>' + esc(tr('Manuscrits en anglais ou en français', 'Manuscripts in English or French')) + '</dd></div>' +
    '</dl></div>' +
    '<figure class="plate-wrap">' + plateSVG() + '<div class="legend" id="legend">' + legendHTML() + '</div>' +
    '<figcaption class="plate-cap">' + esc(tr('Une rangée par domaine, de A à H. La dilution de gauche à droite reprend la logique d’une plaque de 96 puits ; la colonne 12 reste vide, comme les puits témoins.', 'One row per field, A to H. The left-to-right dilution follows the logic of a 96-well plate; column 12 stays empty, like control wells.')) + '</figcaption></figure>' +
    '</div></section>' +

    '<section class="band alt"><div class="wrap"><div class="sec-head"><div><p class="eyebrow">' + esc(tr('Dernières publications', 'Latest publications')) + '</p><h2>' + esc(tr('Articles récents', 'Recent articles')) + '</h2></div>' +
    (arts.length ? '<a class="btn sm" href="#articles">' + esc(tr('Tous les articles', 'All articles')) + '</a>' : '') + '</div>' +
    (arts.length ? arts.map(articleItem).join('') :
      '<div class="empty"><h3>' + esc(tr('Le premier numéro est en préparation', 'The first issue is in preparation')) + '</h3><p>' + esc(tr('Aucun article n’est encore publié. Les premiers manuscrits acceptés paraîtront dans ' + issueLabel() + '.', 'No article is published yet. The first accepted manuscripts will appear in ' + issueLabel() + '.')) + '</p><a class="btn primary sm" href="#soumettre">' + esc(tr('Proposer un manuscrit', 'Propose a manuscript')) + '</a></div>') +
    '</div></section>' +

    '<section class="band"><div class="wrap"><div class="callout"><div>' +
    '<p class="eyebrow" style="color:inherit;opacity:.7">' + esc(DATA.settings.open ? tr('Appel ouvert', 'Open call') : tr('Appel à venir', 'Call opening soon')) + ' · ' + esc(issueLabel()) + '</p>' +
    '<h2 style="margin-top:10px">' + esc(tr('Six formats d’article, une même exigence de rigueur', 'Six article formats, one standard of rigour')) + '</h2>' +
    '<p>' + esc(tr('Les travaux qui croisent plusieurs disciplines sont les bienvenus : un résultat de microbiologie lu par des spécialistes de l’aliment, une méthode utile aux agronomes comme aux biochimistes.', 'Work that crosses disciplines is welcome: a microbiology result read by food scientists, a method useful to agronomists and biochemists alike.')) + '</p>' +
    '<div class="cta-row" style="margin-top:20px"><a class="btn primary" href="#soumettre">' + esc(tr('Soumettre', 'Submit')) + '</a><a class="btn" href="#auteurs">' + esc(tr('Formats et consignes', 'Formats and guidelines')) + '</a></div></div>' +
    '<ul>' + TYPES.map(function (t) { return '<li><b>' + t[3].toLocaleString(lang === 'fr' ? 'fr-FR' : 'en-GB') + '</b>' + esc(lang === 'fr' ? t[1] : t[2]) + '</li>'; }).join('') + '</ul>' +
    '</div><p class="muted" style="font-size:14px;margin-top:10px;font-family:var(--f-display)">' + esc(tr('Nombre maximal de mots du texte principal, hors références.', 'Maximum main-text word count, excluding references.')) + '</p></div></section>' +

    '<section class="band alt"><div class="wrap"><div class="sec-head"><div><p class="eyebrow">' + esc(tr('Parcours d’un manuscrit', 'Life of a manuscript')) + '</p><h2>' + esc(tr('De la soumission à la publication', 'From submission to publication')) + '</h2></div></div>' +
    '<ol class="steps">' + steps.map(function (s) { return '<li><h3>' + esc(s[0]) + '</h3><p>' + esc(s[1]) + '</p></li>'; }).join('') + '</ol></div></section>' +

    '<section class="band"><div class="wrap"><div class="sec-head"><div><p class="eyebrow">' + esc(tr('Comité éditorial', 'Editorial board')) + '</p><h2>' + esc(tr('Les personnes qui dirigent la revue', 'The people who lead the journal')) + '</h2></div><a class="btn sm" href="#comite">' + esc(tr('Voir le comité', 'See the board')) + '</a></div>' +
    (board.length ? '<div class="members">' + board.map(memberHTML).join('') + '</div>' : '<div class="empty"><h3>' + esc(tr('Comité en cours de constitution', 'Board being assembled')) + '</h3><p>' + esc(tr('Les noms des rédacteurs et des membres du comité scientifique seront annoncés ici.', 'Names of editors and scientific committee members will be announced here.')) + '</p></div>') +
    '</div></section>';
}

function viewDomains() {
  return headHTML(esc(tr('Champs couverts', 'Scope')), tr('Huit domaines, une même revue', 'Eight fields, one journal'),
    tr('Matrix Bioscience accepte tout manuscrit qui relève d’un de ces domaines ou qui en relie plusieurs. En cas de doute sur le périmètre, écrivez au secrétariat avant de soumettre.', 'Matrix Bioscience accepts any manuscript that falls within one of these fields or links several of them. If you are unsure about scope, write to the editorial office before submitting.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap">' +
    DOMAINS.map(function (d) {
      return '<div class="dom r-' + d.k + '" id="dom-' + d.k + '"><div class="dom-row"><span class="dom-letter">' + d.k + '</span><span class="dots"><i></i><i></i><i></i><i></i></span></div>' +
        '<div><h2>' + esc(d[lang][0]) + '</h2><p>' + esc(d[lang][1]) + '</p><div class="cta-row" style="margin-top:18px"><a class="btn sm" href="#soumettre" data-area="' + d.k + '">' + esc(tr('Soumettre dans ce domaine', 'Submit in this field')) + '</a></div></div>' +
        '<ul class="topics">' + d[lang][2].map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>';
    }).join('') + '</div></section>';
}

var fArt = { q: '', area: '', type: '' };
function filteredArticles() {
  var q = fArt.q.trim().toLowerCase();
  return DATA.articles.filter(function (a) {
    if (fArt.area && a.area !== fArt.area) return false;
    if (fArt.type && a.type !== fArt.type) return false;
    if (q && (a.title + ' ' + a.authors + ' ' + (a.abstract || '')).toLowerCase().indexOf(q) < 0) return false;
    return true;
  }).sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')); });
}
function articleList() {
  var l = filteredArticles();
  if (l.length) return l.map(articleItem).join('');
  if (DATA.articles.length) return '<div class="empty"><h3>' + esc(tr('Aucun résultat', 'No result')) + '</h3><p>' + esc(tr('Aucun article ne correspond à ces filtres.', 'No article matches these filters.')) + '</p></div>';
  return '<div class="empty"><h3>' + esc(tr('Le premier numéro est en préparation', 'The first issue is in preparation')) + '</h3><p>' + esc(tr('Les articles acceptés seront publiés ici, un par un, avec leur DOI et leur PDF en accès libre.', 'Accepted articles will be published here one by one, with their DOI and open-access PDF.')) + '</p><a class="btn primary sm" href="#soumettre">' + esc(tr('Proposer un manuscrit', 'Propose a manuscript')) + '</a></div>';
}
function viewArticles() {
  return headHTML(esc(issueLabel()), tr('Articles', 'Articles'), tr('Tous les articles sont en accès libre. Filtrez par domaine ou par type.', 'All articles are open access. Filter by field or type.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="filters">' +
    '<div class="fld"><label for="fa-q">' + esc(tr('Recherche', 'Search')) + '</label><input type="search" id="fa-q" data-fa="q" value="' + esc(fArt.q) + '" placeholder="' + esc(tr('Titre, auteur, mot du résumé', 'Title, author, abstract word')) + '"></div>' +
    '<div class="fld"><label for="fa-area">' + esc(tr('Domaine', 'Field')) + '</label><select id="fa-area" data-fa="area"><option value="">' + esc(tr('Tous', 'All')) + '</option>' + DOMAINS.map(function (d) { return '<option value="' + d.k + '"' + (fArt.area === d.k ? ' selected' : '') + '>' + esc(d[lang][0]) + '</option>'; }).join('') + '</select></div>' +
    '<div class="fld"><label for="fa-type">Type</label><select id="fa-type" data-fa="type"><option value="">' + esc(tr('Tous', 'All')) + '</option>' + TYPES.map(function (t) { return '<option value="' + t[0] + '"' + (fArt.type === t[0] ? ' selected' : '') + '>' + esc(lang === 'fr' ? t[1] : t[2]) + '</option>'; }).join('') + '</select></div>' +
    '</div><div id="art-list">' + articleList() + '</div></div></section>';
}

function viewBoard() {
  var groups = ROLES.map(function (r) { return { r: r, list: sortedBoard().filter(function (m) { return m.role === r[0]; }) }; }).filter(function (g) { return g.list.length; });
  return headHTML(esc(tr('Gouvernance scientifique', 'Scientific governance')), tr('Comité éditorial', 'Editorial board'),
    tr('Les rédacteurs décident des manuscrits retenus pour évaluation et des décisions finales. Les membres du comité scientifique orientent la politique de la revue et relisent des manuscrits.', 'Editors decide which manuscripts go to review and make final decisions. Scientific committee members guide journal policy and review manuscripts.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap">' +
    (groups.length ? groups.map(function (g) {
      return '<div class="board-group"><div><h2>' + esc(lang === 'fr' ? g.r[3] : g.r[4]) + '</h2><p class="n">' + g.list.length + '</p></div><div class="members">' + g.list.map(memberHTML).join('') + '</div></div>';
    }).join('') : '<div class="empty"><h3>' + esc(tr('Comité en cours de constitution', 'Board being assembled')) + '</h3><p>' + esc(tr('Les noms seront annoncés ici.', 'Names will be announced here.')) + '</p></div>') +
    '<div class="panel" style="margin-top:36px;display:flex;justify-content:space-between;gap:20px;align-items:center;flex-wrap:wrap"><div style="max-width:38em"><h3 style="font-size:20px;font-weight:650">' + esc(tr('Devenir relecteur ou membre du comité', 'Become a reviewer or board member')) + '</h3><p class="muted" style="margin-top:6px">' + esc(tr('Nous recherchons des chercheurs actifs dans chacun des huit domaines. Envoyez un CV court et vos domaines d’expertise au secrétariat.', 'We are looking for active researchers in each of the eight fields. Send a short CV and your areas of expertise to the editorial office.')) + '</p></div><a class="btn" href="#contact">' + esc(tr('Contacter le secrétariat', 'Contact the editorial office')) + '</a></div>' +
    '</div></section>';
}

function viewGuidelines() {
  var secs = [
    ['types', tr('Types d’articles', 'Article types'), '<div class="tbl-wrap"><table><thead><tr><th>Type</th><th class="num">' + esc(tr('Mots (max.)', 'Words (max.)')) + '</th><th class="num">' + esc(tr('Résumé (max.)', 'Abstract (max.)')) + '</th><th>' + esc(tr('Contenu', 'Content')) + '</th></tr></thead><tbody>' +
      TYPES.map(function (t) { return '<tr><td><b>' + esc(lang === 'fr' ? t[1] : t[2]) + '</b></td><td class="num">' + t[3].toLocaleString(lang === 'fr' ? 'fr-FR' : 'en-GB') + '</td><td class="num">' + t[4] + '</td><td>' + esc(lang === 'fr' ? t[5] : t[6]) + '</td></tr>'; }).join('') +
      '</tbody></table></div><p class="muted" style="font-size:15px">' + esc(tr('Le texte principal s’entend hors résumé, références, légendes et tableaux. Un dépassement raisonnable est discuté avec l’éditeur avant la soumission.', 'Main text excludes abstract, references, legends and tables. A reasonable excess is discussed with the editor before submission.')) + '</p>'],
    ['structure', tr('Structure du manuscrit', 'Manuscript structure'),
      tr('<p><b>Page de titre.</b> Titre précis (jusqu’à 20 mots), auteurs avec affiliations et ORCID, auteur correspondant, mots-clés (3 à 8).</p><p><b>Résumé.</b> Un seul paragraphe pour les articles de recherche : contexte, objectif, méthodes, résultats principaux, conclusion. Fournissez-le en anglais et en français.</p><p><b>Corps du texte.</b> Introduction, matériel et méthodes, résultats, discussion, conclusion. Les revues de littérature remplacent méthodes et résultats par une section décrivant la stratégie de recherche bibliographique.</p><p><b>Fin d’article.</b> Contributions des auteurs (taxonomie CRediT), financement, conflits d’intérêts, éthique, disponibilité des données, remerciements, références.</p>',
        '<p><b>Title page.</b> Precise title (up to 20 words), authors with affiliations and ORCID, corresponding author, keywords (3 to 8).</p><p><b>Abstract.</b> A single paragraph for research articles: background, aim, methods, main results, conclusion. Provide it in English and French.</p><p><b>Main text.</b> Introduction, materials and methods, results, discussion, conclusion. Reviews replace methods and results with a section describing the literature search strategy.</p><p><b>End matter.</b> Author contributions (CRediT taxonomy), funding, conflicts of interest, ethics, data availability, acknowledgements, references.</p>')],
    ['format', tr('Mise en forme', 'Formatting'),
      tr('<ul><li>Dépôt du manuscrit en PDF lors de la soumission. La version Word éditable est demandée avec la révision.</li><li>Police de 11 points, interligne 1,5, numérotation continue des lignes et des pages.</li><li>Figures en 300 dpi minimum, avec légende autonome. Tableaux modifiables, jamais sous forme d’image.</li><li>Unités du Système international. Noms d’espèces en italique, nom complet à la première mention.</li><li>Souches microbiennes : numéro de collection ou de dépôt. Séquences : numéro d’accès dans une base publique.</li></ul>',
        '<ul><li>Upload the manuscript as a PDF at submission. The editable Word version is requested with the revision.</li><li>11-point font, 1.5 line spacing, continuous line and page numbers.</li><li>Figures at 300 dpi minimum, each with a self-contained legend. Editable tables, never as images.</li><li>SI units. Species names in italics, full name at first mention.</li><li>Microbial strains: collection or deposit number. Sequences: accession number in a public database.</li></ul>')],
    ['refs', tr('Références', 'References'),
      tr('<p>Références numérotées dans l’ordre d’apparition, au format Vancouver, avec le DOI quand il existe. Citez de préférence des sources évaluées par des pairs. Toute donnée non publiée ou communication personnelle se signale dans le texte, pas dans la liste.</p>',
        '<p>References numbered in order of appearance, Vancouver format, with the DOI when one exists. Prefer peer-reviewed sources. Unpublished data and personal communications are flagged in the text, not in the list.</p>')],
    ['avant', tr('Avant de soumettre', 'Before you submit'),
      tr('<ul><li>Le manuscrit est original et n’est pas en évaluation ailleurs.</li><li>Tous les auteurs ont lu et approuvé la version soumise.</li><li>L’approbation éthique, le consentement et les autorisations de prélèvement sont documentés.</li><li>Les données et les souches sont accessibles ou leur restriction est justifiée.</li><li>Tout recours à un outil d’intelligence artificielle générative est déclaré.</li></ul>',
        '<ul><li>The manuscript is original and not under review elsewhere.</li><li>All authors have read and approved the submitted version.</li><li>Ethics approval, consent and collection permits are documented.</li><li>Data and strains are accessible or any restriction is justified.</li><li>Any use of generative AI tools is declared.</li></ul>')],
    ['apres', tr('Après acceptation', 'After acceptance'),
      tr('<p>Les épreuves sont envoyées à l’auteur correspondant, qui dispose de quelques jours pour les corriger. L’article est ensuite publié avec son DOI. Les auteurs conservent leur droit d’auteur et le texte est diffusé sous licence CC BY 4.0.</p>',
        '<p>Proofs are sent to the corresponding author, who has a few days to correct them. The article is then published with its DOI. Authors keep their copyright and the text is released under a CC BY 4.0 licence.</p>')]
  ];
  return headHTML(esc(tr('Pour les auteurs', 'For authors')), tr('Instructions aux auteurs', 'Author guidelines'), tr('Ce qu’il faut préparer avant d’ouvrir le formulaire de soumission.', 'What to prepare before opening the submission form.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap two-col"><nav class="toc" aria-label="' + esc(tr('Sur cette page', 'On this page')) + '">' +
    secs.map(function (s) { return '<a href="#auteurs" data-scroll="g-' + s[0] + '">' + esc(s[1]) + '</a>'; }).join('') + '</nav>' +
    '<div class="prose">' + secs.map(function (s) { return '<h2 id="g-' + s[0] + '" style="scroll-margin-top:90px">' + esc(s[1]) + '</h2>' + s[2]; }).join('') +
    '<div class="cta-row" style="margin-top:36px"><a class="btn primary" href="#soumettre">' + esc(tr('Ouvrir le formulaire de soumission', 'Open the submission form')) + '</a></div></div></div></section>';
}

function viewPolicies() {
  var P = [
    [tr('Évaluation par les pairs', 'Peer review'), tr('Chaque manuscrit passe d’abord un contrôle éditorial portant sur le périmètre, la forme et la similarité avec des textes existants. Les manuscrits retenus sont envoyés à au moins deux relecteurs indépendants, en double anonymat : les relecteurs ignorent l’identité des auteurs et les auteurs celle des relecteurs. Les décisions possibles sont l’acceptation, la révision mineure, la révision majeure et le refus. Un auteur qui conteste une décision peut écrire à l’éditeur en argumentant ; un second avis est alors demandé à un rédacteur qui n’a pas traité le manuscrit.', 'Every manuscript first goes through an editorial check of scope, format and similarity with existing texts. Retained manuscripts go to at least two independent reviewers, double-anonymous: reviewers do not know the authors and authors do not know the reviewers. Possible decisions are acceptance, minor revision, major revision and rejection. An author who disputes a decision may write to the editor with arguments; a second opinion is then requested from an editor who did not handle the manuscript.')],
    [tr('Accès libre et licence', 'Open access and licence'), tr('Tous les articles sont lisibles gratuitement dès leur publication et diffusés sous licence Creative Commons CC BY 4.0. Les auteurs conservent leur droit d’auteur. Les conditions financières, y compris les éventuelles exonérations pour les auteurs de pays à revenu faible, sont communiquées avant l’acceptation et jamais après.', 'All articles are free to read on publication and released under a Creative Commons CC BY 4.0 licence. Authors keep their copyright. Financial terms, including any waivers for authors from low-income countries, are communicated before acceptance and never after.')],
    [tr('Éthique de la recherche', 'Research ethics'), tr('Les études sur des personnes exigent l’approbation d’un comité d’éthique et un consentement éclairé. Les études sur des animaux suivent les lignes directrices ARRIVE et l’approbation d’un comité compétent. Les essais cliniques doivent être enregistrés avant l’inclusion du premier participant. Pour les ressources génétiques et les souches prélevées dans un pays, les auteurs indiquent les autorisations obtenues, y compris au titre du Protocole de Nagoya. Les travaux à risque biologique précisent le niveau de biosécurité utilisé.', 'Studies on people require ethics committee approval and informed consent. Animal studies follow the ARRIVE guidelines and approval by a competent committee. Clinical trials must be registered before the first participant is enrolled. For genetic resources and strains collected in a country, authors state the permits obtained, including under the Nagoya Protocol. Work with biological risk states the biosafety level used.')],
    [tr('Intégrité, plagiat et images', 'Integrity, plagiarism and images'), tr('Les manuscrits sont contrôlés avec un logiciel de similarité avant l’évaluation. La revue refuse le plagiat, y compris le plagiat de ses propres textes, la fabrication ou la falsification de données et la manipulation d’images. Des images originales (gels, immunoempreintes, microscopie) peuvent être demandées. Les manuscrits issus d’officines de rédaction sont refusés.', 'Manuscripts are screened with similarity software before review. The journal rejects plagiarism, including self-plagiarism, fabrication or falsification of data, and image manipulation. Original images (gels, blots, microscopy) may be requested. Manuscripts from paper mills are rejected.')],
    [tr('Auteurs et contributions', 'Authorship and contributions'), tr('Est auteur toute personne qui a contribué de façon substantielle à la conception, aux données ou à leur analyse, a participé à la rédaction et approuve la version finale. Les contributions sont décrites selon la taxonomie CRediT. Tout ajout, retrait ou changement d’ordre des auteurs après la soumission exige l’accord écrit de tous les auteurs concernés.', 'An author is anyone who made a substantial contribution to the design, the data or their analysis, took part in drafting and approves the final version. Contributions are described with the CRediT taxonomy. Any addition, removal or reordering of authors after submission requires written agreement from all authors involved.')],
    [tr('Conflits d’intérêts', 'Conflicts of interest'), tr('Auteurs, relecteurs et rédacteurs déclarent tout lien financier ou personnel susceptible d’influencer le travail ou son évaluation. Un rédacteur ne traite pas un manuscrit de son entourage proche ni de sa propre institution. Les auteurs peuvent proposer jusqu’à trois relecteurs et en exclure ; l’éditeur n’est pas tenu de suivre ces suggestions.', 'Authors, reviewers and editors declare any financial or personal tie that could influence the work or its evaluation. An editor does not handle a manuscript from a close associate or their own institution. Authors may suggest up to three reviewers and exclude some; the editor is not bound by these suggestions.')],
    [tr('Données et matériel', 'Data and materials'), tr('Chaque article comporte une déclaration de disponibilité des données. Les séquences sont déposées dans une base publique avant la publication et les souches dans une collection reconnue quand c’est possible. Si les données ne peuvent pas être partagées, la raison est exposée.', 'Each article carries a data availability statement. Sequences are deposited in a public database before publication and strains in a recognised collection when possible. If data cannot be shared, the reason is stated.')],
    [tr('Intelligence artificielle', 'Artificial intelligence'), tr('Un outil d’IA ne peut pas être auteur. Les auteurs déclarent tout usage d’un outil génératif dans la rédaction, l’analyse ou la production d’images, et restent responsables du contenu. Les relecteurs et rédacteurs ne déposent pas de manuscrits confidentiels dans des outils d’IA accessibles au public.', 'An AI tool cannot be an author. Authors declare any use of a generative tool in writing, analysis or image production, and remain responsible for the content. Reviewers and editors do not upload confidential manuscripts to publicly accessible AI tools.')],
    [tr('Corrections et rétractations', 'Corrections and retractions'), tr('Une erreur qui modifie l’interprétation d’un article donne lieu à un erratum. Un article dont les conclusions sont invalidées par une faute ou une inconduite est rétracté ; la notice reste liée à l’article, qui demeure consultable avec la mention de rétractation. La revue s’appuie sur les recommandations du Committee on Publication Ethics (COPE) pour instruire les plaintes.', 'An error that changes the interpretation of an article leads to a correction. An article whose conclusions are invalidated by error or misconduct is retracted; the notice stays linked to the article, which remains accessible with a retraction mark. The journal relies on the Committee on Publication Ethics (COPE) recommendations to investigate complaints.')],
    [tr('Confidentialité et archivage', 'Confidentiality and archiving'), tr('Les manuscrits soumis sont confidentiels jusqu’à leur publication. Les données personnelles des auteurs et des relecteurs servent uniquement à la gestion éditoriale. Les articles publiés sont conservés dans au moins une archive numérique pérenne.', 'Submitted manuscripts are confidential until publication. Personal data of authors and reviewers is used solely for editorial management. Published articles are preserved in at least one long-term digital archive.')]
  ];
  return headHTML(esc(tr('Règles de la revue', 'Journal rules')), tr('Politiques éditoriales', 'Editorial policies'), tr('Ces règles s’appliquent aux auteurs, aux relecteurs et aux rédacteurs.', 'These rules apply to authors, reviewers and editors.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="acc">' +
    P.map(function (p, i) { return '<details' + (i === 0 ? ' open' : '') + '><summary>' + esc(p[0]) + '</summary><div class="body"><p>' + esc(p[1]) + '</p></div></details>'; }).join('') + '</div></div></section>';
}

function viewContact() {
  var s = DATA.settings;
  var mail = s.email ? '<p class="mono" style="font-size:17px;overflow-wrap:anywhere">' + esc(s.email) + '</p><button class="btn sm" data-copy="' + esc(s.email) + '" style="margin-top:12px">' + esc(tr('Copier l’adresse', 'Copy address')) + '</button>' :
    '<p class="muted">' + esc(tr('L’adresse du secrétariat sera publiée prochainement.', 'The editorial office address will be published soon.')) + '</p>' + (cap.admin ? '<p class="hint" style="margin-top:8px">' + esc(tr('Renseignez-la dans Espace éditorial > Paramètres.', 'Set it under Editorial desk > Settings.')) + '</p>' : '');
  return headHTML(esc(tr('Secrétariat de rédaction', 'Editorial office')), 'Contact', tr('Pour une question avant soumission, une proposition de numéro spécial ou une candidature de relecteur.', 'For a pre-submission question, a special issue proposal or a reviewer application.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="grid g3">' +
    '<div class="panel"><h3 style="font-size:19px;font-weight:650;margin-bottom:12px">' + esc(tr('Adresse du secrétariat', 'Editorial office address')) + '</h3>' + mail + '</div>' +
    '<div class="panel"><h3 style="font-size:19px;font-weight:650;margin-bottom:12px">' + esc(tr('Publication', 'Publisher')) + '</h3><p>' + esc(s.publisher || tr('Éditeur à préciser', 'Publisher to be announced')) + '</p>' + (s.address ? '<p class="muted" style="margin-top:8px">' + esc(s.address).replace(/\n/g, '<br>') + '</p>' : '') + '<p class="mono muted" style="margin-top:12px;font-size:12.5px">' + issnText() + '</p></div>' +
    '<div class="panel"><h3 style="font-size:19px;font-weight:650;margin-bottom:12px">' + esc(tr('Numéros spéciaux', 'Special issues')) + '</h3><p class="muted">' + esc(tr('Une thématique, une liste de contributeurs pressentis et un calendrier suffisent pour ouvrir la discussion. Indiquez ces éléments dans votre message.', 'A theme, a list of prospective contributors and a timeline are enough to start the discussion. Include them in your message.')) + '</p></div>' +
    '</div></div></section>';
}

/* ---------- submission form ---------- */
function blankForm() {
  return {
    type: 'research', area: 'C', title: '', abstract: '', keywords: '', mlang: 'en', words: '',
    authors: [{ name: '', aff: '', country: '', email: '', orcid: '', corr: true }], credit: '',
    cover: '', suggest: '', exclude: '', funding: '', coi: '',
    ethics: 'na', ethicsText: '', data: 'text', dataText: '', ai: 'none', aiText: '',
    d1: false, d2: false, d3: false, d4: false, files: [], supp: []
  };
}
var F = blankForm();
try { var dr = lsGet('mb-draft'); if (dr) F = Object.assign(blankForm(), JSON.parse(dr)); } catch (e) { F = blankForm(); }
var step = 0, errs = {}, done = null, busy = false;
var saveTimer = null;
function saveDraft() { clearTimeout(saveTimer); saveTimer = setTimeout(function () { lsSet('mb-draft', JSON.stringify(F)); }, 400); }

function opts(list, sel) { return list.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (String(sel) === String(o[0]) ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join(''); }
function fld(id, label, inner, o) {
  o = o || {};
  return '<div class="fld' + (o.err ? ' bad' : '') + '"><label for="' + id + '">' + label + (o.req ? '<span class="req" aria-hidden="true"> *</span>' : '') + '</label>' + inner +
    (o.hint ? '<p class="hint">' + o.hint + '</p>' : '') + (o.err ? '<p class="err" role="alert">' + esc(o.err) + '</p>' : '') + '</div>';
}
function tin(name, o) {
  o = o || {};
  return '<input type="' + (o.type || 'text') + '" id="f-' + name + '" data-f="' + name + '" value="' + esc(F[name]) + '"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (errs[name] ? ' aria-invalid="true"' : '') + '>';
}
function tarea(name, rows, ph) { return '<textarea id="f-' + name + '" data-f="' + name + '" rows="' + (rows || 4) + '"' + (ph ? ' placeholder="' + esc(ph) + '"' : '') + (errs[name] ? ' aria-invalid="true"' : '') + '>' + esc(F[name]) + '</textarea>'; }
function chk(name, label) { return '<label class="chk' + (errs[name] ? ' bad' : '') + '"><input type="checkbox" id="f-' + name + '" data-f="' + name + '"' + (F[name] ? ' checked' : '') + '><span>' + label + (errs[name] ? '<br><span class="err">' + esc(errs[name]) + '</span>' : '') + '</span></label>'; }

function step0() {
  var t = typeOf(F.type), wc = words(F.abstract);
  return '<div class="stack">' +
    '<div class="row2">' + fld('f-type', tr('Type d’article', 'Article type'), '<select id="f-type" data-f="type">' + opts(TYPES.map(function (x) { return [x[0], lang === 'fr' ? x[1] : x[2]]; }), F.type) + '</select>', { req: 1, hint: esc(tr('Maximum ' + t[3] + ' mots de texte principal, résumé de ' + t[4] + ' mots au plus.', 'Up to ' + t[3] + ' main-text words, abstract of ' + t[4] + ' words at most.')) }) +
    fld('f-area', tr('Domaine principal', 'Main field'), '<select id="f-area" data-f="area">' + opts(DOMAINS.map(function (d) { return [d.k, d.k + ' · ' + d[lang][0]]; }), F.area) + '</select>', { req: 1 }) + '</div>' +
    fld('f-title', tr('Titre', 'Title'), tin('title'), { req: 1, err: errs.title }) +
    fld('f-abstract', tr('Résumé', 'Abstract'), tarea('abstract', 8) + '<div class="count' + (wc > t[4] ? ' over' : '') + '" id="abs-count">' + wc + ' / ' + t[4] + ' ' + esc(tr('mots', 'words')) + '</div>', { req: 1, err: errs.abstract }) +
    fld('f-keywords', tr('Mots-clés', 'Keywords'), tin('keywords'), { req: 1, err: errs.keywords, hint: esc(tr('Entre 3 et 8 mots-clés, séparés par des virgules.', 'Between 3 and 8 keywords, separated by commas.')) }) +
    '<div class="row2">' + fld('f-mlang', tr('Langue du manuscrit', 'Manuscript language'), '<select id="f-mlang" data-f="mlang">' + opts([['en', 'English'], ['fr', 'Français']], F.mlang) + '</select>', { req: 1 }) +
    fld('f-words', tr('Nombre de mots du texte principal', 'Main-text word count'), tin('words', { type: 'number' }), { err: errs.words, hint: esc(tr('Facultatif.', 'Optional.')) }) + '</div></div>';
}
function authorBlock(a, i) {
  var e = errs['a' + i] || {};
  var id = function (n) { return 'a' + i + '-' + n; };
  function ain(n, type) { return '<input type="' + (type || 'text') + '" id="' + id(n) + '" data-a="' + i + '.' + n + '" value="' + esc(a[n]) + '"' + (e[n] ? ' aria-invalid="true"' : '') + '>'; }
  return '<div class="author"><div class="author-head"><b style="font-family:var(--f-display)">' + esc(tr('Auteur ', 'Author ')) + (i + 1) + '</b><div class="rowact">' +
    '<label class="chk" style="grid-template-columns:20px auto;font-size:14px"><input type="radio" name="corr" id="' + id('corr') + '" data-act="corr" data-i="' + i + '"' + (a.corr ? ' checked' : '') + '><span>' + esc(tr('Auteur correspondant', 'Corresponding author')) + '</span></label>' +
    (F.authors.length > 1 ? '<button type="button" class="btn sm danger" data-act="delAuthor" data-i="' + i + '">' + esc(tr('Retirer', 'Remove')) + '</button>' : '') + '</div></div>' +
    '<div class="row2">' + fld(id('name'), tr('Nom complet', 'Full name'), ain('name'), { req: 1, err: e.name }) + fld(id('email'), 'E-mail', ain('email', 'email'), { req: a.corr ? 1 : 0, err: e.email }) + '</div>' +
    '<div class="row2">' + fld(id('aff'), tr('Affiliation', 'Affiliation'), ain('aff'), { req: 1, err: e.aff }) + fld(id('country'), tr('Pays', 'Country'), ain('country')) + '</div>' +
    fld(id('orcid'), 'ORCID', ain('orcid'), { err: e.orcid, hint: esc(tr('Format 0000-0000-0000-0000. Facultatif.', 'Format 0000-0000-0000-0000. Optional.')) }) + '</div>';
}
function step1() {
  return '<div class="stack"><div class="authors">' + F.authors.map(authorBlock).join('') + '</div>' +
    (errs.authors ? '<p class="err" role="alert">' + esc(errs.authors) + '</p>' : '') +
    '<div><button type="button" class="btn sm" data-act="addAuthor">' + esc(tr('Ajouter un auteur', 'Add an author')) + '</button></div>' +
    fld('f-credit', tr('Contributions des auteurs', 'Author contributions'), tarea('credit', 4, tr('Exemple : A.B. conceptualisation, méthodologie ; C.D. analyse, rédaction.', 'Example: A.B. conceptualisation, methodology; C.D. analysis, writing.')), { hint: esc(tr('Taxonomie CRediT. Facultatif à la soumission, obligatoire à l’acceptation.', 'CRediT taxonomy. Optional at submission, required at acceptance.')) }) + '</div>';
}
function step2() {
  return '<div class="stack">' +
    fld('f-cover', tr('Lettre de présentation', 'Cover letter'), tarea('cover', 6), { req: 1, err: errs.cover, hint: esc(tr('Intérêt de l’article pour les lecteurs de la revue, nouveauté, lien avec le périmètre.', 'Why the article matters to the journal’s readers, what is new, how it fits the scope.')) }) +
    '<div class="row2">' + fld('f-suggest', tr('Relecteurs proposés', 'Suggested reviewers'), tarea('suggest', 4, tr('Un par ligne : nom, institution, e-mail (3 maximum)', 'One per line: name, institution, email (3 maximum)')), {}) +
    fld('f-exclude', tr('Relecteurs à exclure', 'Reviewers to exclude'), tarea('exclude', 4, tr('Un par ligne, avec le motif', 'One per line, with the reason')), {}) + '</div>' +
    fld('f-funding', tr('Financement', 'Funding'), tarea('funding', 3, tr('Organismes, numéros de subvention, ou « Aucun financement spécifique ».', 'Funders, grant numbers, or “No specific funding”.')), {}) +
    fld('f-coi', tr('Conflits d’intérêts', 'Conflicts of interest'), tarea('coi', 3, tr('Décrivez-les, ou écrivez « Aucun conflit d’intérêts ».', 'Describe them, or write “No conflicts of interest”.')), { req: 1, err: errs.coi }) +
    '<div class="row2">' + fld('f-ethics', tr('Éthique', 'Ethics'), '<select id="f-ethics" data-f="ethics">' + opts([['na', tr('Sans objet (pas d’humains, d’animaux ni de prélèvements réglementés)', 'Not applicable (no humans, animals or regulated sampling)')], ['human', tr('Étude sur des personnes, approbation obtenue', 'Human study, approval obtained')], ['animal', tr('Étude sur des animaux, approbation obtenue', 'Animal study, approval obtained')], ['permit', tr('Ressources biologiques avec autorisation de prélèvement', 'Biological resources with collection permit')]], F.ethics) + '</select>', { req: 1 }) +
    fld('f-ethicsText', tr('Référence d’approbation', 'Approval reference'), tin('ethicsText'), { err: errs.ethicsText, hint: esc(tr('Comité, numéro et date. Obligatoire sauf « sans objet ».', 'Committee, number and date. Required unless “not applicable”.')) }) + '</div>' +
    '<div class="row2">' + fld('f-data', tr('Disponibilité des données', 'Data availability'), '<select id="f-data" data-f="data">' + opts([['text', tr('Dans l’article et ses annexes', 'In the article and its supplements')], ['repo', tr('Déposées dans un dépôt public', 'Deposited in a public repository')], ['request', tr('Sur demande raisonnable', 'On reasonable request')], ['none', tr('Non disponibles (motif à préciser)', 'Not available (reason required)')]], F.data) + '</select>', { req: 1 }) +
    fld('f-dataText', tr('Précisions', 'Details'), tin('dataText'), { err: errs.dataText, hint: esc(tr('Lien ou numéro d’accès du dépôt, ou motif de la restriction.', 'Repository link or accession, or reason for the restriction.')) }) + '</div>' +
    '<div class="row2">' + fld('f-ai', tr('Outils d’IA générative', 'Generative AI tools'), '<select id="f-ai" data-f="ai">' + opts([['none', tr('Aucun outil utilisé', 'No tool used')], ['used', tr('Outil utilisé (à décrire)', 'Tool used (describe)')]], F.ai) + '</select>', { req: 1 }) +
    fld('f-aiText', tr('Description de l’usage', 'Description of use'), tin('aiText'), { err: errs.aiText }) + '</div>' +
    '<div class="stack" style="gap:12px;padding-top:6px">' +
    chk('d1', esc(tr('Le manuscrit est original et n’est pas en cours d’évaluation dans une autre revue.', 'The manuscript is original and not under review in another journal.'))) +
    chk('d2', esc(tr('Tous les auteurs ont lu et approuvé la version soumise.', 'All authors have read and approved the submitted version.'))) +
    chk('d3', esc(tr('Les exigences éthiques et réglementaires ont été respectées.', 'Ethical and regulatory requirements have been met.'))) +
    chk('d4', esc(tr('J’accepte la publication sous licence CC BY 4.0 en cas d’acceptation.', 'I agree to publication under a CC BY 4.0 licence if accepted.'))) + '</div></div>';
}
function fileLi(f, kind, i) {
  return '<li><span>' + esc(f.name) + ' <span class="muted">· ' + (f.size ? (f.size / 1048576).toFixed(1) + ' Mo' : '') + '</span></span><button type="button" class="btn link" data-act="rmFile" data-kind="' + kind + '" data-i="' + i + '">' + esc(tr('Retirer', 'Remove')) + '</button></li>';
}
function step3() {
  var canUp = !!cap.assets && !!cap.db && !!cap.uid, t = typeOf(F.type);
  var au = F.authors.map(function (a) { return a.name + (a.corr ? ' *' : ''); }).join(', ');
  var files = canUp ?
    '<div class="filebox"><div><b class="lbl">' + esc(tr('Manuscrit (PDF)', 'Manuscript (PDF)')) + '</b><span class="req"> *</span><p class="hint">' + esc(tr('PDF de 20 Mo au plus, sans nom d’auteur dans le texte ni dans les propriétés du fichier (évaluation en double anonymat).', 'PDF up to 20 MB, with no author names in the text or file properties (double-anonymous review).')) + '</p></div>' +
    (F.files.length ? '<ul class="filelist">' + F.files.map(function (f, i) { return fileLi(f, 'files', i); }).join('') + '</ul>' : '') +
    '<div><input type="file" id="up-ms" data-up="files" accept="application/pdf,.pdf"></div>' + (errs.files ? '<p class="err" role="alert">' + esc(errs.files) + '</p>' : '') + '</div>' +
    '<div class="filebox"><div><b class="lbl">' + esc(tr('Fichiers complémentaires (facultatif)', 'Supplementary files (optional)')) + '</b><p class="hint">' + esc(tr('PDF, images, CSV ou texte. 20 Mo par fichier.', 'PDF, images, CSV or text. 20 MB per file.')) + '</p></div>' +
    (F.supp.length ? '<ul class="filelist">' + F.supp.map(function (f, i) { return fileLi(f, 'supp', i); }).join('') + '</ul>' : '') +
    '<div><input type="file" id="up-supp" data-up="supp" accept=".pdf,.csv,.txt,.json,.md,image/png,image/jpeg,image/webp"></div></div>' :
    '<div class="alert warn"><b>' + esc(tr('Dépôt de fichier indisponible avec votre accès.', 'File upload is not available with your access.')) + '</b> ' + esc(tr('Préparez le dossier ci-dessous, puis envoyez le manuscrit en PDF par e-mail au secrétariat en indiquant la référence qui vous sera donnée.', 'Prepare the file below, then email the PDF manuscript to the editorial office quoting the reference you will be given.')) + '</div>';
  return '<div class="stack">' + files +
    '<div><h3 style="font-size:18px;font-weight:650;margin-bottom:6px">' + esc(tr('Récapitulatif', 'Summary')) + '</h3><dl class="recap">' +
    '<div><dt>' + esc(tr('Titre', 'Title')) + '</dt><dd>' + esc(F.title) + '</dd></div>' +
    '<div><dt>Type</dt><dd>' + esc(lang === 'fr' ? t[1] : t[2]) + '</dd></div>' +
    '<div><dt>' + esc(tr('Domaine', 'Field')) + '</dt><dd>' + esc(domName(F.area)) + '</dd></div>' +
    '<div><dt>' + esc(tr('Auteurs', 'Authors')) + '</dt><dd>' + esc(au) + '</dd></div>' +
    '<div><dt>' + esc(tr('Mots-clés', 'Keywords')) + '</dt><dd>' + esc(F.keywords) + '</dd></div>' +
    '<div><dt>' + esc(tr('Résumé', 'Abstract')) + '</dt><dd>' + words(F.abstract) + ' ' + esc(tr('mots', 'words')) + '</dd></div></dl></div>' +
    (canUp ? '<div class="alert ok">' + esc(tr('L’envoi en ligne est disponible : le dossier sera transmis directement à la rédaction.', 'Online submission is available: the file will go straight to the editorial team.')) + '</div>' :
      '<div class="alert warn"><b>' + esc(tr('Envoi par e-mail.', 'Submission by email.')) + '</b> ' + esc(tr('Vous n’êtes pas connecté, ou l’envoi en ligne n’est pas activé pour votre accès. En validant, vous obtenez un dossier prêt à copier et à envoyer au secrétariat.', 'You are not signed in, or online submission is not enabled for your access. On confirming, you get a file ready to copy and send to the editorial office.')) + '</div>') +
    '</div>';
}
var STEPS = [['Manuscrit', 'Manuscript'], ['Auteurs', 'Authors'], ['Déclarations', 'Declarations'], ['Envoi', 'Send']];
function stepBodies() { return [step0, step1, step2, step3]; }

function validate(n) {
  var e = {}, t = typeOf(F.type), kw;
  if (n === 0) {
    if (F.title.trim().length < 10) e.title = tr('Saisissez un titre d’au moins 10 caractères.', 'Enter a title of at least 10 characters.');
    var wc = words(F.abstract);
    if (wc < 50) e.abstract = tr('Le résumé doit compter au moins 50 mots.', 'The abstract must be at least 50 words.');
    else if (wc > t[4]) e.abstract = tr('Le résumé dépasse ' + t[4] + ' mots (' + wc + ').', 'The abstract exceeds ' + t[4] + ' words (' + wc + ').');
    kw = F.keywords.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
    if (kw.length < 3 || kw.length > 8) e.keywords = tr('Indiquez entre 3 et 8 mots-clés.', 'Give between 3 and 8 keywords.');
    if (F.words && (isNaN(+F.words) || +F.words < 0)) e.words = tr('Nombre invalide.', 'Invalid number.');
  } else if (n === 1) {
    var okc = 0;
    F.authors.forEach(function (a, i) {
      var x = {};
      if (!a.name.trim()) x.name = tr('Nom requis.', 'Name required.');
      if (!a.aff.trim()) x.aff = tr('Affiliation requise.', 'Affiliation required.');
      if (a.corr) { okc++; if (!/^\S+@\S+\.\S+$/.test(a.email.trim())) x.email = tr('Adresse e-mail valide requise.', 'Valid email required.'); }
      else if (a.email.trim() && !/^\S+@\S+\.\S+$/.test(a.email.trim())) x.email = tr('Adresse e-mail invalide.', 'Invalid email.');
      if (a.orcid.trim() && !/^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$/.test(a.orcid.trim())) x.orcid = tr('Format ORCID invalide.', 'Invalid ORCID format.');
      if (Object.keys(x).length) e['a' + i] = x;
    });
    if (okc !== 1) e.authors = tr('Désignez un auteur correspondant.', 'Select one corresponding author.');
  } else if (n === 2) {
    if (F.cover.trim().length < 30) e.cover = tr('Rédigez une lettre de présentation (30 caractères minimum).', 'Write a cover letter (30 characters minimum).');
    if (!F.coi.trim()) e.coi = tr('Déclaration requise, même s’il n’y a aucun conflit.', 'Statement required, even if there is no conflict.');
    if (F.ethics !== 'na' && !F.ethicsText.trim()) e.ethicsText = tr('Indiquez la référence d’approbation.', 'Give the approval reference.');
    if ((F.data === 'repo' || F.data === 'none') && !F.dataText.trim()) e.dataText = tr('Précisez le dépôt ou le motif.', 'Specify the repository or the reason.');
    if (F.ai === 'used' && !F.aiText.trim()) e.aiText = tr('Décrivez l’usage de l’outil.', 'Describe the tool use.');
    ['d1', 'd2', 'd3', 'd4'].forEach(function (k) { if (!F[k]) e[k] = tr('Case à cocher pour continuer.', 'Tick to continue.'); });
  } else if (n === 3) {
    if (cap.assets && cap.db && cap.uid && !F.files.length) e.files = tr('Déposez le manuscrit en PDF.', 'Upload the PDF manuscript.');
  }
  return e;
}
function firstBad() { var el = $('[aria-invalid="true"], .chk.bad input, .filebox .err'); if (el) { try { el.focus(); } catch (x) { /* ignore */ } } }

function viewSubmit() {
  if (done) return viewDone();
  var online = !!cap.db && !!cap.uid;
  return headHTML(esc(tr('Soumission en ligne', 'Online submission')), tr('Soumettre un manuscrit', 'Submit a manuscript'), tr('Quatre étapes. Votre saisie est conservée sur cet appareil jusqu’à l’envoi.', 'Four steps. Your entries are kept on this device until you send.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="sub-grid"><div>' +
    '<ol class="stepper">' + STEPS.map(function (s, i) { return '<li class="' + (i === step ? 'on' : (i < step ? 'done' : '')) + '"' + (i === step ? ' aria-current="step"' : '') + '><small>' + esc(tr('Étape ', 'Step ')) + (i + 1) + '</small>' + esc(tr(s[0], s[1])) + '</li>'; }).join('') + '</ol>' +
    '<form id="subform" novalidate data-form="submit"><div class="panel" id="stepbody">' + stepBodies()[step]() + '</div>' +
    '<div class="formnav"><div>' + (step > 0 ? '<button type="button" class="btn" data-act="step" data-to="' + (step - 1) + '">' + esc(tr('Retour', 'Back')) + '</button>' : '') + '</div>' +
    '<div>' + (step < 3 ? '<button type="button" class="btn primary" data-act="step" data-to="' + (step + 1) + '">' + esc(tr('Continuer', 'Continue')) + '</button>' :
      '<button type="submit" class="btn primary"' + (busy ? ' disabled' : '') + '>' + esc(busy ? tr('Envoi…', 'Sending…') : (online ? tr('Envoyer le manuscrit', 'Send manuscript') : tr('Préparer le dossier', 'Prepare the file'))) + '</button>') + '</div></div></form></div>' +
    '<aside class="stack" style="align-content:start">' +
    '<div class="alert' + (online ? ' ok' : ' warn') + '">' + (online ? '<b>' + esc(tr('Connecté.', 'Signed in.')) + '</b> ' + esc(tr('Votre soumission sera transmise en ligne.', 'Your submission will be sent online.')) : '<b>' + esc(tr('Mode e-mail.', 'Email mode.')) + '</b> ' + esc(tr('Connectez-vous pour envoyer en ligne et suivre le dossier ; sinon vous recevrez un dossier à envoyer par e-mail.', 'Sign in to submit online and track the file; otherwise you will get a file to send by email.'))) + '</div>' +
    '<div class="panel"><h3 style="font-size:17px;font-weight:650">' + esc(tr('Avant de commencer', 'Before you start')) + '</h3><p class="muted" style="font-size:15px;margin-top:6px">' + esc(tr('Préparez un PDF anonymisé, la liste des auteurs avec leurs ORCID et vos déclarations éthiques.', 'Prepare an anonymised PDF, the author list with ORCIDs and your ethics statements.')) + '</p><p style="margin-top:10px"><a href="#auteurs">' + esc(tr('Instructions aux auteurs', 'Author guidelines')) + '</a></p><p style="margin-top:4px"><a href="#suivi">' + esc(tr('Suivre mes soumissions', 'Track my submissions')) + '</a></p>' +
    '<button type="button" class="btn link" data-act="resetForm" style="margin-top:8px">' + esc(tr('Effacer le brouillon', 'Clear draft')) + '</button></div></aside></div></div></section>';
}
function recordFromForm(ref) {
  return {
    ref: ref, createdAt: new Date().toISOString(), type: F.type, area: F.area, title: F.title.trim(), abstract: F.abstract.trim(),
    keywords: F.keywords.trim(), mlang: F.mlang, words: F.words || '', authors: F.authors.map(function (a) { return { name: a.name.trim(), aff: a.aff.trim(), country: a.country.trim(), email: a.email.trim(), orcid: a.orcid.trim(), corr: !!a.corr }; }),
    credit: F.credit, cover: F.cover, suggest: F.suggest, exclude: F.exclude, funding: F.funding, coi: F.coi,
    ethics: F.ethics, ethicsText: F.ethicsText, data: F.data, dataText: F.dataText, ai: F.ai, aiText: F.aiText, files: F.files, supp: F.supp
  };
}
function packageText(r) {
  var L = [];
  L.push('MATRIX BIOSCIENCE · ' + tr('Dossier de soumission', 'Submission file'));
  L.push(tr('Référence', 'Reference') + ': ' + r.ref);
  L.push(tr('Date', 'Date') + ': ' + r.createdAt);
  L.push('');
  L.push(tr('Type', 'Type') + ': ' + typeName(r.type));
  L.push(tr('Domaine', 'Field') + ': ' + domName(r.area));
  L.push(tr('Titre', 'Title') + ': ' + r.title);
  L.push(tr('Langue', 'Language') + ': ' + r.mlang);
  L.push(tr('Mots-clés', 'Keywords') + ': ' + r.keywords);
  L.push('');
  L.push(tr('AUTEURS', 'AUTHORS'));
  r.authors.forEach(function (a, i) { L.push((i + 1) + '. ' + a.name + (a.corr ? ' (' + tr('correspondant', 'corresponding') + ')' : '') + ' — ' + a.aff + (a.country ? ', ' + a.country : '') + (a.email ? ' — ' + a.email : '') + (a.orcid ? ' — ORCID ' + a.orcid : '')); });
  if (r.credit) { L.push(''); L.push(tr('CONTRIBUTIONS', 'CONTRIBUTIONS')); L.push(r.credit); }
  L.push(''); L.push(tr('RÉSUMÉ', 'ABSTRACT')); L.push(r.abstract);
  L.push(''); L.push(tr('LETTRE DE PRÉSENTATION', 'COVER LETTER')); L.push(r.cover);
  if (r.suggest) { L.push(''); L.push(tr('RELECTEURS PROPOSÉS', 'SUGGESTED REVIEWERS')); L.push(r.suggest); }
  if (r.exclude) { L.push(''); L.push(tr('RELECTEURS À EXCLURE', 'REVIEWERS TO EXCLUDE')); L.push(r.exclude); }
  L.push(''); L.push(tr('FINANCEMENT', 'FUNDING')); L.push(r.funding || '-');
  L.push(tr('CONFLITS D’INTÉRÊTS', 'CONFLICTS OF INTEREST') + ': ' + r.coi);
  L.push(tr('ÉTHIQUE', 'ETHICS') + ': ' + r.ethics + (r.ethicsText ? ' — ' + r.ethicsText : ''));
  L.push(tr('DONNÉES', 'DATA') + ': ' + r.data + (r.dataText ? ' — ' + r.dataText : ''));
  L.push(tr('IA GÉNÉRATIVE', 'GENERATIVE AI') + ': ' + r.ai + (r.aiText ? ' — ' + r.aiText : ''));
  L.push(''); L.push(tr('Déclarations 1 à 4 cochées par l’auteur correspondant.', 'Declarations 1 to 4 ticked by the corresponding author.'));
  return L.join('\n');
}
function viewDone() {
  var r = done.rec, online = done.online, mail = DATA.settings.email;
  return headHTML(esc(online ? tr('Soumission enregistrée', 'Submission recorded') : tr('Dossier prêt', 'File ready')), online ? tr('Merci, votre manuscrit est reçu', 'Thank you, your manuscript is received') : tr('Dossier prêt à envoyer', 'File ready to send'),
    online ? tr('Conservez cette référence. Elle sert à suivre le dossier et à écrire à la rédaction.', 'Keep this reference. Use it to track the file and to write to the editorial team.') : tr('Rien n’a encore été transmis. Envoyez le texte ci-dessous au secrétariat par e-mail, avec le manuscrit en PDF.', 'Nothing has been sent yet. Email the text below to the editorial office together with the PDF manuscript.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="stack" style="max-width:820px"><div><p class="eyebrow" style="margin-bottom:8px">' + esc(tr('Référence', 'Reference')) + '</p><div class="refbox" id="refbox">' + esc(r.ref) + '</div></div>' +
    (online ? '<div class="alert ok">' + esc(tr('La rédaction contrôle le périmètre, la forme et la similarité du texte, puis vous écrit. Le statut du dossier est consultable dans « Suivre une soumission ».', 'The editorial team checks scope, format and similarity, then writes to you. File status is available under “Track a submission”.')) + '</div>' :
      '<div class="alert warn"><b>' + esc(tr('Adresse du secrétariat : ', 'Editorial office address: ')) + '</b>' + (mail ? '<span class="mono">' + esc(mail) + '</span>' : esc(tr('à venir (voir la page Contact)', 'coming soon (see the Contact page)'))) + '</div>' +
      '<pre class="pkg" id="pkg">' + esc(packageText(r)) + '</pre>') +
    '<div class="cta-row">' + (online ? '' : '<button class="btn primary" data-act="copyPkg">' + esc(tr('Copier le dossier', 'Copy the file')) + '</button>') +
    (cap.dl ? '<button class="btn' + (online ? ' primary' : '') + '" data-act="dlPkg">' + esc(tr('Télécharger le récépissé', 'Download receipt')) + '</button>' : '') +
    (online ? '<a class="btn" href="#suivi">' + esc(tr('Suivre ma soumission', 'Track my submission')) + '</a>' : '') +
    '<button class="btn link" data-act="newSub">' + esc(tr('Nouvelle soumission', 'New submission')) + '</button></div></div></div></section>';
}
async function doSubmit() {
  if (busy) return;
  for (var n = 0; n < 4; n++) { var e = validate(n); if (Object.keys(e).length) { errs = e; step = n; renderView(); firstBad(); return; } }
  var online = !!cap.db && !!cap.uid, ref = 'MB-' + new Date().getFullYear() + '-' + Math.random().toString(36).slice(2, 8).toUpperCase();
  var rec = recordFromForm(ref);
  if (!online) { done = { rec: rec, online: false }; renderView(); window.scrollTo(0, 0); return; }
  busy = true; renderView();
  try {
    var dref = cap.db.doc('submissions/' + cap.uid), snap = await dref.get(), o = {};
    o[ref] = rec;
    if (snap.exists) await dref.update({ subs: o }); else await dref.set({ uid: cap.uid, subs: o });
    done = { rec: rec, online: true };
    F = blankForm(); step = 0; errs = {}; lsSet('mb-draft', '');
  } catch (er) {
    if (er && er.code === 'invalid_argument') { done = { rec: rec, online: false }; busy = false; renderView(); window.scrollTo(0, 0); toast(tr('L’envoi en ligne n’est pas autorisé pour votre accès : utilisez l’e-mail.', 'Online submission is not allowed for your access: use email.')); return; }
    toast(tr('L’envoi a échoué. Votre saisie est conservée ; réessayez ou utilisez l’e-mail.', 'Sending failed. Your entries are kept; try again or use email.') + (er && er.code ? ' (' + er.code + ')' : ''));
  }
  busy = false; renderView(); window.scrollTo(0, 0);
}
async function uploadFile(input) {
  var kind = input.getAttribute('data-up'), file = input.files && input.files[0];
  if (!file || !cap.assets) return;
  var isPdf = /pdf$/i.test(file.type) || /\.pdf$/i.test(file.name);
  var type = file.type;
  if (!type) { var x = (file.name.split('.').pop() || '').toLowerCase(); type = { pdf: 'application/pdf', csv: 'text/csv', txt: 'text/plain', json: 'application/json', md: 'text/markdown' }[x] || ''; }
  if (/excel/.test(type)) type = 'text/csv';
  if (kind === 'files' && !isPdf) { errs.files = tr('Le manuscrit doit être un PDF.', 'The manuscript must be a PDF.'); renderView(); return; }
  if (file.size > 20 * 1048576) { toast(tr('Fichier trop volumineux (20 Mo maximum).', 'File too large (20 MB maximum).')); input.value = ''; return; }
  try {
    toast(tr('Téléversement…', 'Uploading…'));
    var res = await cap.assets.upload(file, type ? { type: type } : undefined);
    var item = { id: res.id, name: file.name, size: res.sizeBytes };
    if (kind === 'files') F.files = [item]; else F.supp.push(item);
    delete errs.files; saveDraft(); renderView();
  } catch (er) {
    toast(tr('Téléversement impossible', 'Upload failed') + (er && er.code ? ' (' + er.code + ')' : ''));
  }
}

/* ---------- tracking ---------- */
var track = { loading: false, subs: null, status: {}, err: '' };
async function loadTrack() {
  if (!cap.db || !cap.uid || track.loading) return;
  track.loading = true;
  try {
    var snap = await cap.db.doc('submissions/' + cap.uid).get(), list = [];
    if (snap.exists) { var subs = (snap.data() || {}).subs || {}; Object.keys(subs).forEach(function (k) { list.push(subs[k]); }); }
    list.sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); });
    track.subs = list;
    for (var i = 0; i < list.length; i++) {
      var s = await cap.db.doc('status/' + list[i].ref).get();
      track.status[list[i].ref] = s.exists ? (s.data() || {}) : null;
    }
  } catch (er) { track.err = er && er.code ? er.code : 'error'; track.subs = track.subs || []; }
  track.loading = false;
  if (route === 'suivi') renderView();
}
function viewTrack() {
  var head = headHTML(esc(tr('Mes dossiers', 'My files')), tr('Suivre une soumission', 'Track a submission'), tr('Le statut est mis à jour par la rédaction à chaque étape.', 'The editorial team updates the status at each stage.'));
  var body;
  if (!cap.db || !cap.uid) body = '<div class="empty"><h3>' + esc(tr('Connexion requise', 'Sign-in required')) + '</h3><p>' + esc(tr('Le suivi en ligne n’est disponible que pour les manuscrits soumis en ligne par un compte connecté. Pour un envoi par e-mail, écrivez au secrétariat avec votre référence.', 'Online tracking is only available for manuscripts submitted online by a signed-in account. For an email submission, write to the editorial office with your reference.')) + '</p></div>';
  else if (track.subs === null) body = '<p class="muted">' + esc(tr('Chargement…', 'Loading…')) + '</p>';
  else if (!track.subs.length) body = '<div class="empty"><h3>' + esc(tr('Aucune soumission', 'No submission')) + '</h3><p>' + esc(tr('Vous n’avez pas encore soumis de manuscrit avec ce compte.', 'You have not submitted a manuscript with this account yet.')) + '</p><a class="btn primary sm" href="#soumettre">' + esc(tr('Soumettre', 'Submit')) + '</a></div>';
  else body = '<div class="list">' + track.subs.map(function (s) {
    var st = track.status[s.ref], k = st && st.status ? st.status : 'received';
    return '<div><div class="t"><b>' + esc(s.title) + '</b><span class="mono">' + esc(s.ref) + '</span> · <span>' + esc(fmtDate(s.createdAt, true)) + '</span> · <span>' + esc(typeName(s.type)) + '</span></div><div>' + pill(k) + '</div></div>';
  }).join('') + '</div>';
  return head + '<section class="band tight" style="padding-top:8px"><div class="wrap" style="max-width:900px;margin:0 auto">' + body + (track.err ? '<p class="err" style="margin-top:12px">' + esc(track.err) + '</p>' : '') + '</div></section>';
}

/* ---------- editorial desk ---------- */
var adm = { tab: 'subs', subs: [], status: {}, notes: {}, filter: 'all', q: '', subscribed: false, open: null, edit: null, err: '' };
function flatten(docs) {
  var out = [];
  docs.forEach(function (d) { var dd = d.data() || {}, subs = dd.subs || {}; Object.keys(subs).forEach(function (k) { var r = subs[k]; r._uid = d.id; out.push(r); }); });
  out.sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); });
  return out;
}
function startAdmin() {
  if (adm.subscribed || !cap.db || !cap.admin) return;
  adm.subscribed = true;
  var refresh = function () { if (route === 'editorial' && adm.tab === 'subs') { var b = $('#adm-body'); if (b) b.innerHTML = subsHTML(); } };
  var onErr = function (e) { adm.err = (e && e.code) || 'error'; refresh(); };
  try {
    cap.db.collection('submissions').onSnapshot(function (s) { adm.subs = flatten(s.docs); refresh(); }, onErr);
    cap.db.collection('status').onSnapshot(function (s) { adm.status = {}; s.docs.forEach(function (d) { adm.status[d.id] = d.data() || {}; }); refresh(); }, onErr);
    cap.db.collection('notes').onSnapshot(function (s) { adm.notes = {}; s.docs.forEach(function (d) { adm.notes[d.id] = d.data() || {}; }); }, onErr);
  } catch (e) { onErr(e); }
}
function statusOfRef(ref) { var s = adm.status[ref]; return s && s.status ? s.status : 'received'; }
function subsHTML() {
  var counts = { all: adm.subs.length };
  STATUSES.forEach(function (s) { counts[s[0]] = 0; });
  adm.subs.forEach(function (r) { counts[statusOfRef(r.ref)]++; });
  var q = adm.q.trim().toLowerCase();
  var list = adm.subs.filter(function (r) {
    if (adm.filter !== 'all' && statusOfRef(r.ref) !== adm.filter) return false;
    if (q && (r.title + ' ' + r.ref + ' ' + r.authors.map(function (a) { return a.name; }).join(' ')).toLowerCase().indexOf(q) < 0) return false;
    return true;
  });
  var chips = '<div class="chips"><button class="chip" data-act="filter" data-v="all" aria-pressed="' + (adm.filter === 'all') + '">' + esc(tr('Toutes', 'All')) + ' <em>' + counts.all + '</em></button>' +
    STATUSES.map(function (s) { return '<button class="chip" data-act="filter" data-v="' + s[0] + '" aria-pressed="' + (adm.filter === s[0]) + '">' + esc(lang === 'fr' ? s[1] : s[2]) + ' <em>' + counts[s[0]] + '</em></button>'; }).join('') + '</div>';
  var tbl = list.length ? '<div class="tbl-wrap"><table><thead><tr><th>' + esc(tr('Référence', 'Reference')) + '</th><th>' + esc(tr('Date', 'Date')) + '</th><th>' + esc(tr('Titre', 'Title')) + '</th><th>' + esc(tr('Domaine', 'Field')) + '</th><th>' + esc(tr('Auteur correspondant', 'Corresponding author')) + '</th><th>' + esc(tr('Statut', 'Status')) + '</th></tr></thead><tbody>' +
    list.map(function (r) {
      var c = (r.authors.filter(function (a) { return a.corr; })[0] || r.authors[0] || {});
      return '<tr class="click" tabindex="0" data-act="openSub" data-ref="' + esc(r.ref) + '"><td class="mono" style="font-size:12.5px">' + esc(r.ref) + '</td><td style="white-space:nowrap">' + esc(fmtDate(r.createdAt)) + '</td><td style="min-width:260px"><b>' + esc(r.title) + '</b></td><td><span class="dot" style="--c:' + domVar(r.area) + '">' + esc(domName(r.area)) + '</span></td><td>' + esc(c.name || '') + '</td><td>' + pill(statusOfRef(r.ref)) + '</td></tr>';
    }).join('') + '</tbody></table></div>' :
    '<div class="empty"><h3>' + esc(adm.subs.length ? tr('Aucun résultat', 'No result') : tr('Aucune soumission reçue', 'No submission received')) + '</h3><p>' + esc(adm.subs.length ? tr('Modifiez le filtre ou la recherche.', 'Change the filter or search.') : tr('Les manuscrits soumis en ligne apparaîtront ici en temps réel.', 'Manuscripts submitted online will appear here in real time.')) + '</p></div>';
  return chips + tbl + (adm.err ? '<p class="err" style="margin-top:10px">' + esc(adm.err) + '</p>' : '');
}
function csvCell(v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; }
async function exportCsv() {
  if (!cap.dl) { toast(tr('Export indisponible dans cette vue.', 'Export unavailable in this view.')); return; }
  var head = ['reference', 'date', 'status', 'type', 'field', 'title', 'corresponding_author', 'email', 'authors', 'keywords', 'files'];
  var rows = adm.subs.map(function (r) {
    var c = r.authors.filter(function (a) { return a.corr; })[0] || r.authors[0] || {};
    return [r.ref, r.createdAt, statusOfRef(r.ref), r.type, domName(r.area), r.title, c.name, c.email, r.authors.map(function (a) { return a.name; }).join('; '), r.keywords, (r.files || []).map(function (f) { return f.name; }).join('; ')].map(csvCell).join(',');
  });
  try { await cap.dl.save({ filename: 'matrix-bioscience-submissions.csv', data: '﻿' + [head.join(',')].concat(rows).join('\n') }); } catch (e) { /* declined */ }
}
function openSubHTML(r) {
  var st = statusOfRef(r.ref), note = (adm.notes[r.ref] || {}).text || '';
  function row(k, v) { return '<div><dt>' + esc(k) + '</dt><dd>' + v + '</dd></div>'; }
  var files = (r.files || []).concat(r.supp || []);
  return '<div class="ov" data-act="closeOv" id="ovbg"><div class="sheet" role="dialog" aria-modal="true" aria-labelledby="ov-t"><div class="sheet-head"><div><p class="eyebrow">' + esc(r.ref) + ' · ' + esc(fmtDate(r.createdAt, true)) + '</p><h2 id="ov-t" style="margin-top:6px">' + esc(r.title) + '</h2></div><button class="btn sm" data-act="closeOv" data-close="1">' + esc(tr('Fermer', 'Close')) + '</button></div><div class="sheet-body">' +
    '<div class="panel"><div class="row2"><div class="fld"><label for="st-sel">' + esc(tr('Statut', 'Status')) + '</label><select id="st-sel">' + opts(STATUSES.map(function (s) { return [s[0], lang === 'fr' ? s[1] : s[2]]; }), st) + '</select></div>' +
    '<div class="fld"><label for="st-note">' + esc(tr('Note interne (invisible pour les auteurs)', 'Internal note (hidden from authors)')) + '</label><textarea id="st-note" rows="3">' + esc(note) + '</textarea></div></div><div class="cta-row" style="margin-top:14px"><button class="btn primary sm" data-act="saveStatus" data-ref="' + esc(r.ref) + '">' + esc(tr('Enregistrer', 'Save')) + '</button></div></div>' +
    '<div><h3>' + esc(tr('Fiche', 'Record')) + '</h3><dl class="recap">' +
    row('Type', esc(typeName(r.type))) + row(tr('Domaine', 'Field'), esc(domName(r.area))) + row(tr('Langue', 'Language'), esc(r.mlang)) + row(tr('Mots-clés', 'Keywords'), esc(r.keywords)) +
    row(tr('Auteurs', 'Authors'), r.authors.map(function (a) { return esc(a.name) + (a.corr ? ' *' : '') + ' — ' + esc(a.aff) + (a.country ? ', ' + esc(a.country) : '') + (a.email ? ' — <span class="mono">' + esc(a.email) + '</span>' : '') + (a.orcid ? ' — ORCID ' + esc(a.orcid) : ''); }).join('<br>')) +
    row(tr('Résumé', 'Abstract'), esc(r.abstract)) + row(tr('Lettre de présentation', 'Cover letter'), esc(r.cover).replace(/\n/g, '<br>')) +
    (r.suggest ? row(tr('Relecteurs proposés', 'Suggested reviewers'), esc(r.suggest).replace(/\n/g, '<br>')) : '') + (r.exclude ? row(tr('Relecteurs exclus', 'Excluded reviewers'), esc(r.exclude).replace(/\n/g, '<br>')) : '') +
    row(tr('Financement', 'Funding'), esc(r.funding || '-')) + row(tr('Conflits d’intérêts', 'Conflicts of interest'), esc(r.coi)) +
    row(tr('Éthique', 'Ethics'), esc(r.ethics) + (r.ethicsText ? ' — ' + esc(r.ethicsText) : '')) + row(tr('Données', 'Data'), esc(r.data) + (r.dataText ? ' — ' + esc(r.dataText) : '')) + row(tr('IA générative', 'Generative AI'), esc(r.ai) + (r.aiText ? ' — ' + esc(r.aiText) : '')) +
    row(tr('Fichiers', 'Files'), files.length ? files.map(function (f) { return '<a href="/_blob/' + esc(f.id) + '" target="_blank" rel="noopener">' + esc(f.name) + '</a>'; }).join('<br>') : esc(tr('Aucun fichier déposé en ligne', 'No file uploaded online'))) +
    '</dl></div></div></div></div>';
}

function memberForm(d) {
  function ei(n, label, o) { o = o || {}; return fld('e-' + n, label, '<input type="text" id="e-' + n + '" data-e="' + n + '" value="' + esc(d[n]) + '">', { req: o.req, hint: o.hint }); }
  return '<form class="panel stack" data-form="member" novalidate><h3 style="font-size:20px;font-weight:650">' + esc(adm.edit.id === 'new' ? tr('Ajouter un membre', 'Add a member') : tr('Modifier le membre', 'Edit member')) + '</h3>' +
    '<div class="row2">' + ei('name', tr('Nom complet', 'Full name'), { req: 1 }) + fld('e-role', tr('Fonction', 'Role'), '<select id="e-role" data-e="role">' + opts(ROLES.map(function (r) { return [r[0], lang === 'fr' ? r[1] : r[2]]; }), d.role) + '</select>', { req: 1 }) + '</div>' +
    '<div class="row2">' + ei('aff', tr('Institution', 'Institution'), { req: 1 }) + ei('country', tr('Pays', 'Country')) + '</div>' +
    ei('expertise', tr('Domaines d’expertise', 'Expertise'), { hint: esc(tr('Séparés par des virgules.', 'Separated by commas.')) }) +
    '<div class="row2">' + ei('orcid', 'ORCID', { hint: '0000-0000-0000-0000' }) + '<div class="fld"><label for="e-photo">' + esc(tr('Photo', 'Photo')) + '</label>' + (d.photo ? '<div class="rowact"><div class="avatar" style="width:48px;height:48px"><img src="/_blob/' + esc(d.photo) + '" alt=""></div><button type="button" class="btn sm" data-act="rmPhoto">' + esc(tr('Retirer', 'Remove')) + '</button></div>' : '') + (cap.assets ? '<input type="file" id="e-photo" data-eup="photo" accept="image/png,image/jpeg,image/webp">' : '<p class="hint">' + esc(tr('Dépôt de photo indisponible dans cette vue.', 'Photo upload unavailable in this view.')) + '</p>') + '</div></div>' +
    fld('e-bio', tr('Courte biographie', 'Short bio'), '<textarea id="e-bio" data-e="bio" rows="3">' + esc(d.bio) + '</textarea>', {}) +
    (adm.edit.err ? '<p class="err" role="alert">' + esc(adm.edit.err) + '</p>' : '') +
    '<div class="cta-row"><button type="submit" class="btn primary sm">' + esc(tr('Enregistrer', 'Save')) + '</button><button type="button" class="btn sm" data-act="cancelEdit">' + esc(tr('Annuler', 'Cancel')) + '</button></div></form>';
}
function articleForm(d) {
  function ei(n, label, o) { o = o || {}; return fld('e-' + n, label, '<input type="' + (o.type || 'text') + '" id="e-' + n + '" data-e="' + n + '" value="' + esc(d[n]) + '">', { req: o.req, hint: o.hint }); }
  return '<form class="panel stack" data-form="article" novalidate><h3 style="font-size:20px;font-weight:650">' + esc(adm.edit.id === 'new' ? tr('Publier un article', 'Publish an article') : tr('Modifier l’article', 'Edit article')) + '</h3>' +
    ei('title', tr('Titre', 'Title'), { req: 1 }) + ei('authors', tr('Auteurs', 'Authors'), { req: 1, hint: esc(tr('Dans l’ordre de la publication.', 'In publication order.')) }) +
    '<div class="row3">' + fld('e-type', 'Type', '<select id="e-type" data-e="type">' + opts(TYPES.map(function (t) { return [t[0], lang === 'fr' ? t[1] : t[2]]; }), d.type) + '</select>', {}) + fld('e-area', tr('Domaine', 'Field'), '<select id="e-area" data-e="area">' + opts(DOMAINS.map(function (x) { return [x.k, x[lang][0]]; }), d.area) + '</select>', {}) + ei('date', tr('Date de publication', 'Publication date'), { type: 'date' }) + '</div>' +
    '<div class="row2">' + ei('issue', tr('Volume / numéro', 'Volume / issue'), { hint: tr('Exemple : Vol. 1, N° 1', 'Example: Vol. 1, No. 1') }) + ei('doi', 'DOI', { hint: tr('Sans https://doi.org/', 'Without https://doi.org/') }) + '</div>' +
    fld('e-abstract', tr('Résumé', 'Abstract'), '<textarea id="e-abstract" data-e="abstract" rows="5">' + esc(d.abstract) + '</textarea>', {}) +
    '<div class="row2"><div class="fld"><label for="e-pdf">PDF</label>' + (d.pdf ? '<p class="hint">' + esc(tr('PDF déposé.', 'PDF uploaded.')) + ' <button type="button" class="btn link" data-act="rmPdf">' + esc(tr('Retirer', 'Remove')) + '</button></p>' : '') + (cap.assets ? '<input type="file" id="e-pdf" data-eup="pdf" accept="application/pdf,.pdf">' : '<p class="hint">' + esc(tr('Dépôt indisponible dans cette vue.', 'Upload unavailable in this view.')) + '</p>') + '</div>' + ei('link', tr('Ou lien vers le texte intégral', 'Or link to the full text'), { type: 'url' }) + '</div>' +
    (adm.edit.err ? '<p class="err" role="alert">' + esc(adm.edit.err) + '</p>' : '') +
    '<div class="cta-row"><button type="submit" class="btn primary sm">' + esc(tr('Enregistrer', 'Save')) + '</button><button type="button" class="btn sm" data-act="cancelEdit">' + esc(tr('Annuler', 'Cancel')) + '</button></div></form>';
}
function boardTab() {
  var d = adm.edit && adm.edit.kind === 'member' ? memberForm(adm.edit.data) : '';
  var list = DATA.board.map(function (m, i) {
    return '<div><div class="t"><b>' + esc(m.name) + '</b><span>' + esc(lang === 'fr' ? roleOf(m.role)[1] : roleOf(m.role)[2]) + ' · ' + esc([m.aff, m.country].filter(Boolean).join(', ')) + '</span></div><div class="rowact">' +
      '<button class="btn sm" data-act="mUp" data-i="' + i + '" aria-label="' + esc(tr('Monter', 'Move up')) + '"' + (i === 0 ? ' disabled' : '') + '>↑</button><button class="btn sm" data-act="mDown" data-i="' + i + '" aria-label="' + esc(tr('Descendre', 'Move down')) + '"' + (i === DATA.board.length - 1 ? ' disabled' : '') + '>↓</button>' +
      '<button class="btn sm" data-act="mEdit" data-i="' + i + '">' + esc(tr('Modifier', 'Edit')) + '</button><button class="btn sm danger" data-act="mDel" data-i="' + i + '">' + esc(tr('Supprimer', 'Delete')) + '</button></div></div>';
  }).join('');
  return '<div class="stack"><div class="cta-row"><button class="btn primary sm" data-act="mNew">' + esc(tr('Ajouter un membre', 'Add a member')) + '</button></div>' + d +
    (list ? '<div class="list">' + list + '</div>' : '<div class="empty"><h3>' + esc(tr('Aucun membre', 'No member')) + '</h3><p>' + esc(tr('Ajoutez le rédacteur en chef, les rédacteurs associés et le comité scientifique.', 'Add the editor-in-chief, associate editors and the scientific committee.')) + '</p></div>') +
    '<p class="hint">' + esc(tr('L’ordre dans chaque groupe suit cette liste. Les modifications ne sont visibles du public qu’après « Publier sur le site ».', 'Order within each group follows this list. Changes only become public after “Publish to the site”.')) + '</p></div>';
}
function articlesTab() {
  var d = adm.edit && adm.edit.kind === 'article' ? articleForm(adm.edit.data) : '';
  var list = DATA.articles.map(function (a, i) {
    return '<div><div class="t"><b>' + esc(a.title) + '</b><span>' + esc(a.authors) + ' · ' + esc(domName(a.area)) + (a.date ? ' · ' + esc(a.date) : '') + '</span></div><div class="rowact"><button class="btn sm" data-act="aEdit" data-i="' + i + '">' + esc(tr('Modifier', 'Edit')) + '</button><button class="btn sm danger" data-act="aDel" data-i="' + i + '">' + esc(tr('Supprimer', 'Delete')) + '</button></div></div>';
  }).join('');
  return '<div class="stack"><div class="cta-row"><button class="btn primary sm" data-act="aNew">' + esc(tr('Publier un article', 'Publish an article')) + '</button></div>' + d +
    (list ? '<div class="list">' + list + '</div>' : '<div class="empty"><h3>' + esc(tr('Aucun article publié', 'No published article')) + '</h3><p>' + esc(tr('Après acceptation, ajoutez ici l’article définitif avec son DOI et son PDF.', 'After acceptance, add the final article here with its DOI and PDF.')) + '</p></div>') + '</div>';
}
function settingsTab() {
  var s = DATA.settings;
  function si(n, label, hint) { return fld('s-' + n, label, '<input type="text" id="s-' + n + '" name="' + n + '" value="' + esc(s[n]) + '">', { hint: hint }); }
  return '<form class="panel stack" data-form="settings" novalidate style="max-width:760px">' +
    '<div class="row2">' + si('email', tr('E-mail du secrétariat', 'Editorial office email'), esc(tr('Affiché sur la page Contact et dans le mode d’envoi par e-mail.', 'Shown on the Contact page and used in email submission mode.'))) + si('issn', 'ISSN', esc(tr('Laissez vide tant qu’il n’est pas attribué.', 'Leave empty until assigned.'))) + '</div>' +
    '<div class="row2">' + si('publisher', tr('Éditeur', 'Publisher')) + si('issue', tr('Numéro en préparation', 'Issue in preparation'), esc(tr('Exemple : Volume 1, Numéro 1 (2027)', 'Example: Volume 1, Issue 1 (2027)'))) + '</div>' +
    fld('s-address', tr('Adresse postale', 'Postal address'), '<textarea id="s-address" name="address" rows="3">' + esc(s.address) + '</textarea>', {}) +
    '<label class="chk"><input type="checkbox" id="s-open" name="open"' + (s.open ? ' checked' : '') + '><span>' + esc(tr('Appel à contributions ouvert', 'Call for papers open')) + '</span></label>' +
    '<div class="cta-row"><button type="submit" class="btn primary sm">' + esc(tr('Enregistrer les paramètres', 'Save settings')) + '</button></div></form>' +
    '<div class="panel stack" style="margin-top:20px;max-width:760px"><h3 style="font-size:19px;font-weight:650">' + esc(tr('Sauvegarde du contenu', 'Content backup')) + '</h3><p class="muted">' + esc(tr('Le comité, les articles et les paramètres sont stockés dans la page. Exportez-les en JSON pour les archiver.', 'The board, articles and settings are stored in the page. Export them as JSON to archive them.')) + '</p><div class="cta-row"><button class="btn sm" data-act="copyJson">' + esc(tr('Copier le JSON', 'Copy JSON')) + '</button>' + (cap.dl ? '<button class="btn sm" data-act="dlJson">' + esc(tr('Télécharger', 'Download')) + '</button>' : '') + '</div></div>';
}
function viewAdmin() {
  var head = headHTML(esc(tr('Réservé à la rédaction', 'Editorial staff only')), tr('Espace éditorial', 'Editorial desk'), '');
  if (!cap.ready) return head + '<section class="band tight"><div class="wrap"><p class="muted">' + esc(tr('Chargement…', 'Loading…')) + '</p></div></section>';
  if (!cap.admin) return head + '<section class="band tight"><div class="wrap"><div class="empty"><h3>' + esc(tr('Accès réservé', 'Restricted access')) + '</h3><p>' + esc(tr('Cet espace est réservé aux éditeurs de la revue. Connectez-vous avec un compte qui a le droit de modifier la page.', 'This area is for the journal’s editors. Sign in with an account that can edit the page.')) + '</p></div></div></section>';
  startAdmin();
  var tabs = [['subs', tr('Soumissions', 'Submissions')], ['board', tr('Comité', 'Board')], ['articles', 'Articles'], ['settings', tr('Paramètres', 'Settings')]];
  var body = adm.tab === 'subs' ? '<div class="cta-row" style="margin-bottom:16px;align-items:end"><div class="fld" style="flex:1;min-width:220px"><label for="adm-q">' + esc(tr('Rechercher', 'Search')) + '</label><input type="search" id="adm-q" value="' + esc(adm.q) + '" placeholder="' + esc(tr('Titre, auteur, référence', 'Title, author, reference')) + '"></div><button class="btn sm" data-act="exportCsv">' + esc(tr('Exporter en CSV', 'Export CSV')) + '</button></div><div id="adm-body">' + subsHTML() + '</div>' :
    adm.tab === 'board' ? boardTab() : adm.tab === 'articles' ? articlesTab() : settingsTab();
  return head + '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="pubbar" id="pubbar">' + pubBar() + '</div><div class="tabs" role="tablist">' + tabs.map(function (t) { return '<button role="tab" data-act="tab" data-v="' + t[0] + '" aria-selected="' + (adm.tab === t[0]) + '">' + esc(t[1]) + '</button>'; }).join('') + '</div>' + body + '</div></section>';
}
function pubBar() {
  if (!dirty) return '';
  return '<div class="alert warn" style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap"><span><b>' + esc(tr('Modifications non publiées.', 'Unpublished changes.')) + '</b> ' + esc(tr('Le public voit encore l’ancienne version.', 'The public still sees the previous version.')) + '</span><button class="btn primary sm" data-act="publish">' + esc(tr('Publier sur le site', 'Publish to the site')) + '</button></div>';
}
function markDirty() { dirty = true; try { sessionStorage.setItem('mb-dirty', JSON.stringify(DATA)); } catch (e) { /* ignore */ } var b = $('#pubbar'); if (b) b.innerHTML = pubBar(); }

/* ---------- self publish ---------- */
var SHELL = '<div id="app"></div><div id="ov"></div><div id="toasts" class="toast-wrap" aria-live="polite"></div>';
function buildDoc() {
  var css = $('#app-css').textContent, js = $('#app-js').textContent;
  if (js.indexOf('/*MB-START*/') < 0 || js.indexOf('/*MB-END*/') < 0 || css.indexOf('--d-a') < 0) return null;
  var reset = '';
  $$('style', document.head).forEach(function (s) { if (!reset && /safe-area/.test(s.textContent)) reset = s.textContent; });
  if (!reset) reset = ':root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui,sans-serif}img{max-width:100%}[hidden]{display:none!important}';
  var json = JSON.stringify(DATA).replace(/</g, '\\u003c').split(String.fromCharCode(8232)).join('\\u2028').split(String.fromCharCode(8233)).join('\\u2029');
  var end = '</scr' + 'ipt>';
  var page = '<title>Matrix Bioscience</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n' +
    '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n<link rel="stylesheet" href="' + FONT_URL + '">\n' +
    '<style id="app-css">' + css + '</style>\n' + SHELL + '\n<script type="application/json" id="site-data">' + json + end + '\n<script id="app-js">' + js + end;
  return '<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>' + reset + '</style></head><body>' + page + '</body></html>';
}
async function publishSite() {
  if (!cap.art) { toast(tr('La publication directe est indisponible dans cette vue. Copiez le JSON et transmettez-le.', 'Direct publishing is unavailable in this view. Copy the JSON and pass it on.')); return; }
  var html = buildDoc();
  if (!html) { toast(tr('Publication automatique impossible. Utilisez « Copier le JSON ».', 'Automatic publishing not possible. Use “Copy JSON”.')); return; }
  try { toast(tr('Publication en cours…', 'Publishing…')); await cap.art.publish(html); }
  catch (er) {
    var c = er && er.code;
    toast(c === 'conflict' ? tr('Une version plus récente existe. La page se recharge ; refaites la modification.', 'A newer version exists. The page is reloading; redo the change.') :
      (c === 'not_writer' || c === 'not_granted') ? tr('Votre compte ne peut pas modifier la page.', 'Your account cannot edit the page.') : tr('Échec de la publication', 'Publishing failed') + (c ? ' (' + c + ')' : ''));
  }
}

/* ---------- render ---------- */
var app = $('#app');
function toast(msg) {
  var w = $('#toasts'); if (!w) return;
  var d = document.createElement('div'); d.className = 'toast'; d.textContent = msg; w.appendChild(d);
  setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 4200);
}
async function copyText(text, msg) {
  try { await navigator.clipboard.writeText(text); toast(msg || tr('Copié', 'Copied')); return; } catch (e) { /* fall through */ }
  try {
    var ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0';
    document.body.appendChild(ta); ta.select(); var ok = document.execCommand('copy'); document.body.removeChild(ta);
    toast(ok ? (msg || tr('Copié', 'Copied')) : tr('Sélectionnez le texte et copiez-le manuellement.', 'Select the text and copy it manually.'));
  } catch (e2) { toast(tr('Sélectionnez le texte et copiez-le manuellement.', 'Select the text and copy it manually.')); }
}
async function saveFile(name, data) { if (!cap.dl) { toast(tr('Téléchargement indisponible dans cette vue.', 'Download unavailable in this view.')); return; } try { await cap.dl.save({ filename: name, data: data }); } catch (e) { /* declined */ } }

function viewFor(r) {
  if (r === 'domaines') return viewDomains();
  if (r === 'articles') return viewArticles();
  if (r === 'comite') return viewBoard();
  if (r === 'auteurs') return viewGuidelines();
  if (r === 'politiques') return viewPolicies();
  if (r === 'contact') return viewContact();
  if (r === 'soumettre') return viewSubmit();
  if (r === 'suivi') return viewTrack();
  if (r === 'editorial') return viewAdmin();
  return viewHome();
}
function renderView() {
  var v = $('#view'); if (!v) return;
  v.innerHTML = viewFor(route);
  if (pending) { var el = document.getElementById(pending); pending = null; if (el) setTimeout(function () { el.scrollIntoView({ block: 'start' }); }, 30); }
}
function renderAll() {
  app.innerHTML = headerHTML() + '<main id="view" tabindex="-1"></main>' + footerHTML();
  renderView();
}
function setRoute() {
  var h = (location.hash || '').replace(/^#/, '');
  route = ROUTES.indexOf(h) >= 0 ? h : 'accueil';
  renderAll();
  if (!pending) window.scrollTo(0, 0);
  if (route === 'suivi') { track.subs = null; track.status = {}; track.err = ''; loadTrack(); }
}

/* ---------- editorial edit helpers ---------- */
function newMember() { return { id: uid2(), name: '', role: 'associate', aff: '', country: '', expertise: '', orcid: '', bio: '', photo: '' }; }
function newArticle() { return { id: uid2(), title: '', authors: '', type: 'research', area: 'C', date: '', issue: '', doi: '', abstract: '', pdf: '', link: '' }; }
function armed(el, label) {
  if (el.getAttribute('data-armed')) return true;
  el.setAttribute('data-armed', '1'); el.setAttribute('data-orig', el.textContent); el.textContent = label;
  setTimeout(function () { if (el.isConnected) { el.removeAttribute('data-armed'); el.textContent = el.getAttribute('data-orig'); } }, 4000);
  return false;
}
function saveMember() {
  var d = adm.edit.data;
  if (!d.name.trim() || !d.aff.trim()) { adm.edit.err = tr('Nom et institution sont requis.', 'Name and institution are required.'); renderView(); return; }
  if (d.orcid.trim() && !/^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$/.test(d.orcid.trim())) { adm.edit.err = tr('Format ORCID invalide.', 'Invalid ORCID format.'); renderView(); return; }
  var m = Object.assign({}, d, { name: d.name.trim(), aff: d.aff.trim(), orcid: d.orcid.trim() });
  var i = -1; DATA.board.forEach(function (x, k) { if (x.id === m.id) i = k; });
  if (i >= 0) DATA.board[i] = m; else DATA.board.push(m);
  adm.edit = null; markDirty(); renderView(); toast(tr('Membre enregistré. Pensez à publier.', 'Member saved. Remember to publish.'));
}
function saveArticle() {
  var d = adm.edit.data;
  if (!d.title.trim() || !d.authors.trim()) { adm.edit.err = tr('Titre et auteurs sont requis.', 'Title and authors are required.'); renderView(); return; }
  if (d.link.trim() && !/^https?:\/\//i.test(d.link.trim())) { adm.edit.err = tr('Le lien doit commencer par https://', 'The link must start with https://'); renderView(); return; }
  var a = Object.assign({}, d, { title: d.title.trim(), authors: d.authors.trim(), doi: d.doi.trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i, ''), link: d.link.trim() });
  var i = -1; DATA.articles.forEach(function (x, k) { if (x.id === a.id) i = k; });
  if (i >= 0) DATA.articles[i] = a; else DATA.articles.push(a);
  adm.edit = null; markDirty(); renderView(); toast(tr('Article enregistré. Pensez à publier.', 'Article saved. Remember to publish.'));
}
function saveSettings(form) {
  var fd = new FormData(form), em = String(fd.get('email') || '').trim();
  if (em && !/^\S+@\S+\.\S+$/.test(em)) { toast(tr('Adresse e-mail invalide.', 'Invalid email address.')); return; }
  DATA.settings = { email: em, issn: String(fd.get('issn') || '').trim(), publisher: String(fd.get('publisher') || '').trim(), issue: String(fd.get('issue') || '').trim(), address: String(fd.get('address') || '').trim(), open: !!fd.get('open') };
  markDirty(); toast(tr('Paramètres enregistrés. Pensez à publier.', 'Settings saved. Remember to publish.'));
}
async function saveStatus(ref) {
  var sel = $('#st-sel'), note = $('#st-note');
  if (!sel || !cap.db) return;
  var now = new Date().toISOString();
  try {
    await cap.db.doc('status/' + ref).set({ ref: ref, status: sel.value, updatedAt: now });
    await cap.db.doc('notes/' + ref).set({ ref: ref, text: note.value, updatedAt: now });
    toast(tr('Statut enregistré', 'Status saved'));
  } catch (er) { toast(tr('Enregistrement impossible', 'Could not save') + (er && er.code ? ' (' + er.code + ')' : '')); }
}

/* ---------- events ---------- */
document.addEventListener('click', function (e) {
  var t = e.target;
  var cp = t.closest && t.closest('[data-copy]');
  if (cp) { copyText(cp.getAttribute('data-copy')); return; }
  var sc = t.closest && t.closest('[data-scroll]');
  if (sc) { e.preventDefault(); var el0 = document.getElementById(sc.getAttribute('data-scroll')); if (el0) el0.scrollIntoView({ block: 'start' }); return; }
  var dm = t.closest && t.closest('[data-dom]');
  if (dm) { pending = 'dom-' + dm.getAttribute('data-dom'); if (route === 'domaines') { e.preventDefault(); renderView(); } return; }
  var ar = t.closest && t.closest('[data-area]');
  if (ar) { F.area = ar.getAttribute('data-area'); step = 0; done = null; saveDraft(); return; }
  var well = t.closest && t.closest('.well[data-row]');
  if (well) { pending = 'dom-' + well.getAttribute('data-row'); if (location.hash === '#domaines') { renderView(); } else { location.hash = 'domaines'; } return; }
  var a = t.closest && t.closest('[data-act]');
  if (!a) return;
  var act = a.getAttribute('data-act'), i = parseInt(a.getAttribute('data-i'), 10);
  if (act === 'closeOv') { if (a.id === 'ovbg' && t !== a) return; $('#ov').innerHTML = ''; return; }
  if (act === 'lang') { lang = lang === 'fr' ? 'en' : 'fr'; lsSet('mb-lang', lang); document.documentElement.setAttribute('lang', lang); renderAll(); return; }
  if (act === 'theme') {
    var cur = document.documentElement.getAttribute('data-theme');
    if (!cur) cur = (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
    var nx = cur === 'dark' ? 'light' : 'dark'; document.documentElement.setAttribute('data-theme', nx); lsSet('mb-theme', nx); return;
  }
  if (act === 'menu') { var top = $('#top'); var o = top.classList.toggle('open'); a.setAttribute('aria-expanded', o ? 'true' : 'false'); return; }
  if (act === 'step') {
    var to = parseInt(a.getAttribute('data-to'), 10);
    if (to > step) { var er = validate(step); if (Object.keys(er).length) { errs = er; renderView(); firstBad(); return; } }
    errs = {}; step = to; renderView(); window.scrollTo(0, 0); return;
  }
  if (act === 'addAuthor') { F.authors.push({ name: '', aff: '', country: '', email: '', orcid: '', corr: false }); saveDraft(); renderView(); return; }
  if (act === 'delAuthor') { var wasC = F.authors[i].corr; F.authors.splice(i, 1); if (wasC && F.authors.length) F.authors[0].corr = true; saveDraft(); renderView(); return; }
  if (act === 'corr') { F.authors.forEach(function (x, k) { x.corr = k === i; }); saveDraft(); return; }
  if (act === 'rmFile') { var kind = a.getAttribute('data-kind'); F[kind].splice(i, 1); saveDraft(); renderView(); return; }
  if (act === 'resetForm') { if (!armed(a, tr('Confirmer l’effacement', 'Confirm clearing'))) return; F = blankForm(); step = 0; errs = {}; lsSet('mb-draft', ''); renderView(); return; }
  if (act === 'newSub') { done = null; step = 0; errs = {}; renderView(); window.scrollTo(0, 0); return; }
  if (act === 'copyPkg') { copyText(packageText(done.rec), tr('Dossier copié', 'File copied')); return; }
  if (act === 'dlPkg') { saveFile('matrix-bioscience-' + done.rec.ref + '.txt', packageText(done.rec)); return; }
  if (act === 'filter') { adm.filter = a.getAttribute('data-v'); var b = $('#adm-body'); if (b) b.innerHTML = subsHTML(); return; }
  if (act === 'openSub') {
    var ref = a.getAttribute('data-ref'), rec = null; adm.subs.forEach(function (r) { if (r.ref === ref) rec = r; });
    if (rec) { $('#ov').innerHTML = openSubHTML(rec); var f = $('#st-sel'); if (f) f.focus(); } return;
  }
  if (act === 'saveStatus') { saveStatus(a.getAttribute('data-ref')); return; }
  if (act === 'tab') { adm.tab = a.getAttribute('data-v'); adm.edit = null; renderView(); return; }
  if (act === 'exportCsv') { exportCsv(); return; }
  if (act === 'mNew') { adm.edit = { kind: 'member', id: 'new', data: newMember(), err: '' }; renderView(); return; }
  if (act === 'mEdit') { adm.edit = { kind: 'member', id: DATA.board[i].id, data: Object.assign(newMember(), DATA.board[i]), err: '' }; renderView(); var n1 = $('#e-name'); if (n1) n1.focus(); return; }
  if (act === 'mDel') { if (!armed(a, tr('Confirmer', 'Confirm'))) return; DATA.board.splice(i, 1); markDirty(); renderView(); return; }
  if (act === 'mUp' && i > 0) { var t1 = DATA.board[i]; DATA.board[i] = DATA.board[i - 1]; DATA.board[i - 1] = t1; markDirty(); renderView(); return; }
  if (act === 'mDown' && i < DATA.board.length - 1) { var t2 = DATA.board[i]; DATA.board[i] = DATA.board[i + 1]; DATA.board[i + 1] = t2; markDirty(); renderView(); return; }
  if (act === 'aNew') { adm.edit = { kind: 'article', id: 'new', data: newArticle(), err: '' }; renderView(); return; }
  if (act === 'aEdit') { adm.edit = { kind: 'article', id: DATA.articles[i].id, data: Object.assign(newArticle(), DATA.articles[i]), err: '' }; renderView(); var n2 = $('#e-title'); if (n2) n2.focus(); return; }
  if (act === 'aDel') { if (!armed(a, tr('Confirmer', 'Confirm'))) return; DATA.articles.splice(i, 1); markDirty(); renderView(); return; }
  if (act === 'cancelEdit') { adm.edit = null; renderView(); return; }
  if (act === 'rmPhoto') { adm.edit.data.photo = ''; renderView(); return; }
  if (act === 'rmPdf') { adm.edit.data.pdf = ''; renderView(); return; }
  if (act === 'publish') { publishSite(); return; }
  if (act === 'copyJson') { copyText(JSON.stringify(DATA, null, 2), tr('JSON copié', 'JSON copied')); return; }
  if (act === 'dlJson') { saveFile('matrix-bioscience-contenu.json', JSON.stringify(DATA, null, 2)); return; }
});

function onField(e) {
  var t = e.target, v;
  if (!t || !t.getAttribute) return;
  var f = t.getAttribute('data-f');
  if (f) {
    v = t.type === 'checkbox' ? t.checked : t.value; F[f] = v;
    if (errs[f]) { delete errs[f]; var fl = t.closest('.fld'); if (fl) { fl.classList.remove('bad'); var er = $('.err', fl); if (er) er.parentNode.removeChild(er); } }
    if (f === 'abstract') { var c = $('#abs-count'), tt = typeOf(F.type), wc = words(v); if (c) { c.textContent = wc + ' / ' + tt[4] + ' ' + tr('mots', 'words'); c.classList.toggle('over', wc > tt[4]); } }
    if (f === 'type' && e.type === 'change') renderView();
    saveDraft(); return;
  }
  var au = t.getAttribute('data-a');
  if (au) { var p = au.split('.'); F.authors[+p[0]][p[1]] = t.value; if (errs['a' + p[0]] && errs['a' + p[0]][p[1]]) { delete errs['a' + p[0]][p[1]]; var fl2 = t.closest('.fld'); if (fl2) fl2.classList.remove('bad'); } saveDraft(); return; }
  var ed = t.getAttribute('data-e');
  if (ed && adm.edit) { adm.edit.data[ed] = t.value; return; }
  var fa = t.getAttribute('data-fa');
  if (fa) { fArt[fa] = t.value; var l = $('#art-list'); if (l) l.innerHTML = articleList(); return; }
  if (t.id === 'adm-q') { adm.q = t.value; var b = $('#adm-body'); if (b) b.innerHTML = subsHTML(); }
}
document.addEventListener('input', onField);
document.addEventListener('change', function (e) {
  var t = e.target;
  if (t && t.getAttribute) {
    if (t.getAttribute('data-up')) { uploadFile(t); return; }
    if (t.getAttribute('data-eup')) { eupload(t); return; }
  }
  if (t && t.tagName === 'SELECT') onField(e);
});
async function eupload(input) {
  var k = input.getAttribute('data-eup'), file = input.files && input.files[0];
  if (!file || !cap.assets || !adm.edit) return;
  if (file.size > 20 * 1048576) { toast(tr('Fichier trop volumineux (20 Mo maximum).', 'File too large (20 MB maximum).')); return; }
  try {
    toast(tr('Téléversement…', 'Uploading…'));
    var res = await cap.assets.upload(file, file.type ? { type: file.type } : undefined);
    adm.edit.data[k] = res.id; renderView();
  } catch (er) { toast(tr('Téléversement impossible', 'Upload failed') + (er && er.code ? ' (' + er.code + ')' : '')); }
}
document.addEventListener('submit', function (e) {
  var f = e.target; if (!f || !f.getAttribute) return;
  var kind = f.getAttribute('data-form'); if (!kind) return;
  e.preventDefault();
  if (kind === 'submit') doSubmit();
  else if (kind === 'member') saveMember();
  else if (kind === 'article') saveArticle();
  else if (kind === 'settings') saveSettings(f);
});
document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape') { var ov = $('#ov'); if (ov && ov.innerHTML) ov.innerHTML = ''; }
  if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.matches && e.target.matches('tr.click')) { e.preventDefault(); e.target.click(); }
});
function hl(e, on) {
  var t = e.target, el = t.closest && (t.closest('.leg[data-dom]') || t.closest('.well[data-row]'));
  var p = $('#plate'); if (!el || !p) return;
  if (on) p.setAttribute('data-hl', el.getAttribute('data-dom') || el.getAttribute('data-row')); else p.removeAttribute('data-hl');
}
document.addEventListener('mouseover', function (e) { hl(e, true); });
document.addEventListener('mouseout', function (e) { hl(e, false); });
document.addEventListener('focusin', function (e) { hl(e, true); });
document.addEventListener('focusout', function (e) { hl(e, false); });
window.addEventListener('hashchange', setRoute);

/* ---------- init ---------- */
async function use(n) { try { if (window.claude && typeof window.claude.use === 'function') return await window.claude.use(n); } catch (e) { /* unavailable */ } return null; }
async function init() {
  document.documentElement.setAttribute('lang', lang);
  setRoute();
  var r = await Promise.all([use('user'), use('db'), use('assets'), use('downloads'), use('artifact')]);
  try { if (r[0]) { cap.admin = !!(await r[0].canEdit()); cap.uid = await r[0].id(); } } catch (e) { /* ignore */ }
  cap.db = r[1]; cap.assets = r[2]; cap.dl = r[3]; cap.art = r[4]; cap.ready = true;
  var keep = route === 'soumettre' && (F.title || F.abstract);
  if (!keep || true) { var y = window.scrollY; renderAll(); window.scrollTo(0, y); }
  if (route === 'suivi') loadTrack();
}
init();
})();
/*MB-END*/
