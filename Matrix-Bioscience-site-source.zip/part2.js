
/* ---------- submission form ---------- */
function blankForm() {
  return {
    type: 'research', area: 'C', title: '', abstract: '', keywords: '', mlang: 'en', words: '',
    authors: [{ name: '', aff: '', country: '', email: '', orcid: '', corr: true }], credit: '',
    cover: '', suggest: '', exclude: '', funding: '', coi: '',
    ethics: 'na', ethicsText: '', data: 'text', dataText: '', ai: 'none', aiText: '',
    d1: false, d2: false, d3: false, d4: false, files: [], supp: []
  };
}
var F = blankForm();
try { var dr = lsGet('mb-draft'); if (dr) F = Object.assign(blankForm(), JSON.parse(dr)); } catch (e) { F = blankForm(); }
var step = 0, errs = {}, done = null, busy = false;
var saveTimer = null;
function saveDraft() { clearTimeout(saveTimer); saveTimer = setTimeout(function () { lsSet('mb-draft', JSON.stringify(F)); }, 400); }

function opts(list, sel) { return list.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (String(sel) === String(o[0]) ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join(''); }
function fld(id, label, inner, o) {
  o = o || {};
  return '<div class="fld' + (o.err ? ' bad' : '') + '"><label for="' + id + '">' + label + (o.req ? '<span class="req" aria-hidden="true"> *</span>' : '') + '</label>' + inner +
    (o.hint ? '<p class="hint">' + o.hint + '</p>' : '') + (o.err ? '<p class="err" role="alert">' + esc(o.err) + '</p>' : '') + '</div>';
}
function tin(name, o) {
  o = o || {};
  return '<input type="' + (o.type || 'text') + '" id="f-' + name + '" data-f="' + name + '" value="' + esc(F[name]) + '"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (errs[name] ? ' aria-invalid="true"' : '') + '>';
}
function tarea(name, rows, ph) { return '<textarea id="f-' + name + '" data-f="' + name + '" rows="' + (rows || 4) + '"' + (ph ? ' placeholder="' + esc(ph) + '"' : '') + (errs[name] ? ' aria-invalid="true"' : '') + '>' + esc(F[name]) + '</textarea>'; }
function chk(name, label) { return '<label class="chk' + (errs[name] ? ' bad' : '') + '"><input type="checkbox" id="f-' + name + '" data-f="' + name + '"' + (F[name] ? ' checked' : '') + '><span>' + label + (errs[name] ? '<br><span class="err">' + esc(errs[name]) + '</span>' : '') + '</span></label>'; }

function step0() {
  var t = typeOf(F.type), wc = words(F.abstract);
  return '<div class="stack">' +
    '<div class="row2">' + fld('f-type', tr('Type d’article', 'Article type'), '<select id="f-type" data-f="type">' + opts(TYPES.map(function (x) { return [x[0], lang === 'fr' ? x[1] : x[2]]; }), F.type) + '</select>', { req: 1, hint: esc(tr('Maximum ' + t[3] + ' mots de texte principal, résumé de ' + t[4] + ' mots au plus.', 'Up to ' + t[3] + ' main-text words, abstract of ' + t[4] + ' words at most.')) }) +
    fld('f-area', tr('Domaine principal', 'Main field'), '<select id="f-area" data-f="area">' + opts(DOMAINS.map(function (d) { return [d.k, d.k + ' · ' + d[lang][0]]; }), F.area) + '</select>', { req: 1 }) + '</div>' +
    fld('f-title', tr('Titre', 'Title'), tin('title'), { req: 1, err: errs.title }) +
    fld('f-abstract', tr('Résumé', 'Abstract'), tarea('abstract', 8) + '<div class="count' + (wc > t[4] ? ' over' : '') + '" id="abs-count">' + wc + ' / ' + t[4] + ' ' + esc(tr('mots', 'words')) + '</div>', { req: 1, err: errs.abstract }) +
    fld('f-keywords', tr('Mots-clés', 'Keywords'), tin('keywords'), { req: 1, err: errs.keywords, hint: esc(tr('Entre 3 et 8 mots-clés, séparés par des virgules.', 'Between 3 and 8 keywords, separated by commas.')) }) +
    '<div class="row2">' + fld('f-mlang', tr('Langue du manuscrit', 'Manuscript language'), '<select id="f-mlang" data-f="mlang">' + opts([['en', 'English'], ['fr', 'Français']], F.mlang) + '</select>', { req: 1 }) +
    fld('f-words', tr('Nombre de mots du texte principal', 'Main-text word count'), tin('words', { type: 'number' }), { err: errs.words, hint: esc(tr('Facultatif.', 'Optional.')) }) + '</div></div>';
}
function authorBlock(a, i) {
  var e = errs['a' + i] || {};
  var id = function (n) { return 'a' + i + '-' + n; };
  function ain(n, type) { return '<input type="' + (type || 'text') + '" id="' + id(n) + '" data-a="' + i + '.' + n + '" value="' + esc(a[n]) + '"' + (e[n] ? ' aria-invalid="true"' : '') + '>'; }
  return '<div class="author"><div class="author-head"><b style="font-family:var(--f-display)">' + esc(tr('Auteur ', 'Author ')) + (i + 1) + '</b><div class="rowact">' +
    '<label class="chk" style="grid-template-columns:20px auto;font-size:14px"><input type="radio" name="corr" id="' + id('corr') + '" data-act="corr" data-i="' + i + '"' + (a.corr ? ' checked' : '') + '><span>' + esc(tr('Auteur correspondant', 'Corresponding author')) + '</span></label>' +
    (F.authors.length > 1 ? '<button type="button" class="btn sm danger" data-act="delAuthor" data-i="' + i + '">' + esc(tr('Retirer', 'Remove')) + '</button>' : '') + '</div></div>' +
    '<div class="row2">' + fld(id('name'), tr('Nom complet', 'Full name'), ain('name'), { req: 1, err: e.name }) + fld(id('email'), 'E-mail', ain('email', 'email'), { req: a.corr ? 1 : 0, err: e.email }) + '</div>' +
    '<div class="row2">' + fld(id('aff'), tr('Affiliation', 'Affiliation'), ain('aff'), { req: 1, err: e.aff }) + fld(id('country'), tr('Pays', 'Country'), ain('country')) + '</div>' +
    fld(id('orcid'), 'ORCID', ain('orcid'), { err: e.orcid, hint: esc(tr('Format 0000-0000-0000-0000. Facultatif.', 'Format 0000-0000-0000-0000. Optional.')) }) + '</div>';
}
function step1() {
  return '<div class="stack"><div class="authors">' + F.authors.map(authorBlock).join('') + '</div>' +
    (errs.authors ? '<p class="err" role="alert">' + esc(errs.authors) + '</p>' : '') +
    '<div><button type="button" class="btn sm" data-act="addAuthor">' + esc(tr('Ajouter un auteur', 'Add an author')) + '</button></div>' +
    fld('f-credit', tr('Contributions des auteurs', 'Author contributions'), tarea('credit', 4, tr('Exemple : A.B. conceptualisation, méthodologie ; C.D. analyse, rédaction.', 'Example: A.B. conceptualisation, methodology; C.D. analysis, writing.')), { hint: esc(tr('Taxonomie CRediT. Facultatif à la soumission, obligatoire à l’acceptation.', 'CRediT taxonomy. Optional at submission, required at acceptance.')) }) + '</div>';
}
function step2() {
  return '<div class="stack">' +
    fld('f-cover', tr('Lettre de présentation', 'Cover letter'), tarea('cover', 6), { req: 1, err: errs.cover, hint: esc(tr('Intérêt de l’article pour les lecteurs de la revue, nouveauté, lien avec le périmètre.', 'Why the article matters to the journal’s readers, what is new, how it fits the scope.')) }) +
    '<div class="row2">' + fld('f-suggest', tr('Relecteurs proposés', 'Suggested reviewers'), tarea('suggest', 4, tr('Un par ligne : nom, institution, e-mail (3 maximum)', 'One per line: name, institution, email (3 maximum)')), {}) +
    fld('f-exclude', tr('Relecteurs à exclure', 'Reviewers to exclude'), tarea('exclude', 4, tr('Un par ligne, avec le motif', 'One per line, with the reason')), {}) + '</div>' +
    fld('f-funding', tr('Financement', 'Funding'), tarea('funding', 3, tr('Organismes, numéros de subvention, ou « Aucun financement spécifique ».', 'Funders, grant numbers, or “No specific funding”.')), {}) +
    fld('f-coi', tr('Conflits d’intérêts', 'Conflicts of interest'), tarea('coi', 3, tr('Décrivez-les, ou écrivez « Aucun conflit d’intérêts ».', 'Describe them, or write “No conflicts of interest”.')), { req: 1, err: errs.coi }) +
    '<div class="row2">' + fld('f-ethics', tr('Éthique', 'Ethics'), '<select id="f-ethics" data-f="ethics">' + opts([['na', tr('Sans objet (pas d’humains, d’animaux ni de prélèvements réglementés)', 'Not applicable (no humans, animals or regulated sampling)')], ['human', tr('Étude sur des personnes, approbation obtenue', 'Human study, approval obtained')], ['animal', tr('Étude sur des animaux, approbation obtenue', 'Animal study, approval obtained')], ['permit', tr('Ressources biologiques avec autorisation de prélèvement', 'Biological resources with collection permit')]], F.ethics) + '</select>', { req: 1 }) +
    fld('f-ethicsText', tr('Référence d’approbation', 'Approval reference'), tin('ethicsText'), { err: errs.ethicsText, hint: esc(tr('Comité, numéro et date. Obligatoire sauf « sans objet ».', 'Committee, number and date. Required unless “not applicable”.')) }) + '</div>' +
    '<div class="row2">' + fld('f-data', tr('Disponibilité des données', 'Data availability'), '<select id="f-data" data-f="data">' + opts([['text', tr('Dans l’article et ses annexes', 'In the article and its supplements')], ['repo', tr('Déposées dans un dépôt public', 'Deposited in a public repository')], ['request', tr('Sur demande raisonnable', 'On reasonable request')], ['none', tr('Non disponibles (motif à préciser)', 'Not available (reason required)')]], F.data) + '</select>', { req: 1 }) +
    fld('f-dataText', tr('Précisions', 'Details'), tin('dataText'), { err: errs.dataText, hint: esc(tr('Lien ou numéro d’accès du dépôt, ou motif de la restriction.', 'Repository link or accession, or reason for the restriction.')) }) + '</div>' +
    '<div class="row2">' + fld('f-ai', tr('Outils d’IA générative', 'Generative AI tools'), '<select id="f-ai" data-f="ai">' + opts([['none', tr('Aucun outil utilisé', 'No tool used')], ['used', tr('Outil utilisé (à décrire)', 'Tool used (describe)')]], F.ai) + '</select>', { req: 1 }) +
    fld('f-aiText', tr('Description de l’usage', 'Description of use'), tin('aiText'), { err: errs.aiText }) + '</div>' +
    '<div class="stack" style="gap:12px;padding-top:6px">' +
    chk('d1', esc(tr('Le manuscrit est original et n’est pas en cours d’évaluation dans une autre revue.', 'The manuscript is original and not under review in another journal.'))) +
    chk('d2', esc(tr('Tous les auteurs ont lu et approuvé la version soumise.', 'All authors have read and approved the submitted version.'))) +
    chk('d3', esc(tr('Les exigences éthiques et réglementaires ont été respectées.', 'Ethical and regulatory requirements have been met.'))) +
    chk('d4', esc(tr('J’accepte la publication sous licence CC BY 4.0 en cas d’acceptation.', 'I agree to publication under a CC BY 4.0 licence if accepted.'))) + '</div></div>';
}
function fileLi(f, kind, i) {
  return '<li><span>' + esc(f.name) + ' <span class="muted">· ' + (f.size ? (f.size / 1048576).toFixed(1) + ' Mo' : '') + '</span></span><button type="button" class="btn link" data-act="rmFile" data-kind="' + kind + '" data-i="' + i + '">' + esc(tr('Retirer', 'Remove')) + '</button></li>';
}
function step3() {
  var canUp = !!cap.assets && !!cap.db && !!cap.uid, t = typeOf(F.type);
  var au = F.authors.map(function (a) { return a.name + (a.corr ? ' *' : ''); }).join(', ');
  var files = canUp ?
    '<div class="filebox"><div><b class="lbl">' + esc(tr('Manuscrit (PDF)', 'Manuscript (PDF)')) + '</b><span class="req"> *</span><p class="hint">' + esc(tr('PDF de 20 Mo au plus, sans nom d’auteur dans le texte ni dans les propriétés du fichier (évaluation en double anonymat).', 'PDF up to 20 MB, with no author names in the text or file properties (double-anonymous review).')) + '</p></div>' +
    (F.files.length ? '<ul class="filelist">' + F.files.map(function (f, i) { return fileLi(f, 'files', i); }).join('') + '</ul>' : '') +
    '<div><input type="file" id="up-ms" data-up="files" accept="application/pdf,.pdf"></div>' + (errs.files ? '<p class="err" role="alert">' + esc(errs.files) + '</p>' : '') + '</div>' +
    '<div class="filebox"><div><b class="lbl">' + esc(tr('Fichiers complémentaires (facultatif)', 'Supplementary files (optional)')) + '</b><p class="hint">' + esc(tr('PDF, images, CSV ou texte. 20 Mo par fichier.', 'PDF, images, CSV or text. 20 MB per file.')) + '</p></div>' +
    (F.supp.length ? '<ul class="filelist">' + F.supp.map(function (f, i) { return fileLi(f, 'supp', i); }).join('') + '</ul>' : '') +
    '<div><input type="file" id="up-supp" data-up="supp" accept=".pdf,.csv,.txt,.json,.md,image/png,image/jpeg,image/webp"></div></div>' :
    '<div class="alert warn"><b>' + esc(tr('Dépôt de fichier indisponible avec votre accès.', 'File upload is not available with your access.')) + '</b> ' + esc(tr('Préparez le dossier ci-dessous, puis envoyez le manuscrit en PDF par e-mail au secrétariat en indiquant la référence qui vous sera donnée.', 'Prepare the file below, then email the PDF manuscript to the editorial office quoting the reference you will be given.')) + '</div>';
  return '<div class="stack">' + files +
    '<div><h3 style="font-size:18px;font-weight:650;margin-bottom:6px">' + esc(tr('Récapitulatif', 'Summary')) + '</h3><dl class="recap">' +
    '<div><dt>' + esc(tr('Titre', 'Title')) + '</dt><dd>' + esc(F.title) + '</dd></div>' +
    '<div><dt>Type</dt><dd>' + esc(lang === 'fr' ? t[1] : t[2]) + '</dd></div>' +
    '<div><dt>' + esc(tr('Domaine', 'Field')) + '</dt><dd>' + esc(domName(F.area)) + '</dd></div>' +
    '<div><dt>' + esc(tr('Auteurs', 'Authors')) + '</dt><dd>' + esc(au) + '</dd></div>' +
    '<div><dt>' + esc(tr('Mots-clés', 'Keywords')) + '</dt><dd>' + esc(F.keywords) + '</dd></div>' +
    '<div><dt>' + esc(tr('Résumé', 'Abstract')) + '</dt><dd>' + words(F.abstract) + ' ' + esc(tr('mots', 'words')) + '</dd></div></dl></div>' +
    (canUp ? '<div class="alert ok">' + esc(tr('L’envoi en ligne est disponible : le dossier sera transmis directement à la rédaction.', 'Online submission is available: the file will go straight to the editorial team.')) + '</div>' :
      '<div class="alert warn"><b>' + esc(tr('Envoi par e-mail.', 'Submission by email.')) + '</b> ' + esc(tr('Vous n’êtes pas connecté, ou l’envoi en ligne n’est pas activé pour votre accès. En validant, vous obtenez un dossier prêt à copier et à envoyer au secrétariat.', 'You are not signed in, or online submission is not enabled for your access. On confirming, you get a file ready to copy and send to the editorial office.')) + '</div>') +
    '</div>';
}
var STEPS = [['Manuscrit', 'Manuscript'], ['Auteurs', 'Authors'], ['Déclarations', 'Declarations'], ['Envoi', 'Send']];
function stepBodies() { return [step0, step1, step2, step3]; }

function validate(n) {
  var e = {}, t = typeOf(F.type), kw;
  if (n === 0) {
    if (F.title.trim().length < 10) e.title = tr('Saisissez un titre d’au moins 10 caractères.', 'Enter a title of at least 10 characters.');
    var wc = words(F.abstract);
    if (wc < 50) e.abstract = tr('Le résumé doit compter au moins 50 mots.', 'The abstract must be at least 50 words.');
    else if (wc > t[4]) e.abstract = tr('Le résumé dépasse ' + t[4] + ' mots (' + wc + ').', 'The abstract exceeds ' + t[4] + ' words (' + wc + ').');
    kw = F.keywords.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
    if (kw.length < 3 || kw.length > 8) e.keywords = tr('Indiquez entre 3 et 8 mots-clés.', 'Give between 3 and 8 keywords.');
    if (F.words && (isNaN(+F.words) || +F.words < 0)) e.words = tr('Nombre invalide.', 'Invalid number.');
  } else if (n === 1) {
    var okc = 0;
    F.authors.forEach(function (a, i) {
      var x = {};
      if (!a.name.trim()) x.name = tr('Nom requis.', 'Name required.');
      if (!a.aff.trim()) x.aff = tr('Affiliation requise.', 'Affiliation required.');
      if (a.corr) { okc++; if (!/^\S+@\S+\.\S+$/.test(a.email.trim())) x.email = tr('Adresse e-mail valide requise.', 'Valid email required.'); }
      else if (a.email.trim() && !/^\S+@\S+\.\S+$/.test(a.email.trim())) x.email = tr('Adresse e-mail invalide.', 'Invalid email.');
      if (a.orcid.trim() && !/^\d{4}-\d{4}-\d{4}-\d{3}[\dX]$/.test(a.orcid.trim())) x.orcid = tr('Format ORCID invalide.', 'Invalid ORCID format.');
      if (Object.keys(x).length) e['a' + i] = x;
    });
    if (okc !== 1) e.authors = tr('Désignez un auteur correspondant.', 'Select one corresponding author.');
  } else if (n === 2) {
    if (F.cover.trim().length < 30) e.cover = tr('Rédigez une lettre de présentation (30 caractères minimum).', 'Write a cover letter (30 characters minimum).');
    if (!F.coi.trim()) e.coi = tr('Déclaration requise, même s’il n’y a aucun conflit.', 'Statement required, even if there is no conflict.');
    if (F.ethics !== 'na' && !F.ethicsText.trim()) e.ethicsText = tr('Indiquez la référence d’approbation.', 'Give the approval reference.');
    if ((F.data === 'repo' || F.data === 'none') && !F.dataText.trim()) e.dataText = tr('Précisez le dépôt ou le motif.', 'Specify the repository or the reason.');
    if (F.ai === 'used' && !F.aiText.trim()) e.aiText = tr('Décrivez l’usage de l’outil.', 'Describe the tool use.');
    ['d1', 'd2', 'd3', 'd4'].forEach(function (k) { if (!F[k]) e[k] = tr('Case à cocher pour continuer.', 'Tick to continue.'); });
  } else if (n === 3) {
    if (cap.assets && cap.db && cap.uid && !F.files.length) e.files = tr('Déposez le manuscrit en PDF.', 'Upload the PDF manuscript.');
  }
  return e;
}
function firstBad() { var el = $('[aria-invalid="true"], .chk.bad input, .filebox .err'); if (el) { try { el.focus(); } catch (x) { /* ignore */ } } }

function viewSubmit() {
  if (done) return viewDone();
  var online = !!cap.db && !!cap.uid;
  return headHTML(esc(tr('Soumission en ligne', 'Online submission')), tr('Soumettre un manuscrit', 'Submit a manuscript'), tr('Quatre étapes. Votre saisie est conservée sur cet appareil jusqu’à l’envoi.', 'Four steps. Your entries are kept on this device until you send.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="sub-grid"><div>' +
    '<ol class="stepper">' + STEPS.map(function (s, i) { return '<li class="' + (i === step ? 'on' : (i < step ? 'done' : '')) + '"' + (i === step ? ' aria-current="step"' : '') + '><small>' + esc(tr('Étape ', 'Step ')) + (i + 1) + '</small>' + esc(tr(s[0], s[1])) + '</li>'; }).join('') + '</ol>' +
    '<form id="subform" novalidate data-form="submit"><div class="panel" id="stepbody">' + stepBodies()[step]() + '</div>' +
    '<div class="formnav"><div>' + (step > 0 ? '<button type="button" class="btn" data-act="step" data-to="' + (step - 1) + '">' + esc(tr('Retour', 'Back')) + '</button>' : '') + '</div>' +
    '<div>' + (step < 3 ? '<button type="button" class="btn primary" data-act="step" data-to="' + (step + 1) + '">' + esc(tr('Continuer', 'Continue')) + '</button>' :
      '<button type="submit" class="btn primary"' + (busy ? ' disabled' : '') + '>' + esc(busy ? tr('Envoi…', 'Sending…') : (online ? tr('Envoyer le manuscrit', 'Send manuscript') : tr('Préparer le dossier', 'Prepare the file'))) + '</button>') + '</div></div></form></div>' +
    '<aside class="stack" style="align-content:start">' +
    '<div class="alert' + (online ? ' ok' : ' warn') + '">' + (online ? '<b>' + esc(tr('Connecté.', 'Signed in.')) + '</b> ' + esc(tr('Votre soumission sera transmise en ligne.', 'Your submission will be sent online.')) : '<b>' + esc(tr('Mode e-mail.', 'Email mode.')) + '</b> ' + esc(tr('Connectez-vous pour envoyer en ligne et suivre le dossier ; sinon vous recevrez un dossier à envoyer par e-mail.', 'Sign in to submit online and track the file; otherwise you will get a file to send by email.'))) + '</div>' +
    '<div class="panel"><h3 style="font-size:17px;font-weight:650">' + esc(tr('Avant de commencer', 'Before you start')) + '</h3><p class="muted" style="font-size:15px;margin-top:6px">' + esc(tr('Préparez un PDF anonymisé, la liste des auteurs avec leurs ORCID et vos déclarations éthiques.', 'Prepare an anonymised PDF, the author list with ORCIDs and your ethics statements.')) + '</p><p style="margin-top:10px"><a href="#auteurs">' + esc(tr('Instructions aux auteurs', 'Author guidelines')) + '</a></p><p style="margin-top:4px"><a href="#suivi">' + esc(tr('Suivre mes soumissions', 'Track my submissions')) + '</a></p>' +
    '<button type="button" class="btn link" data-act="resetForm" style="margin-top:8px">' + esc(tr('Effacer le brouillon', 'Clear draft')) + '</button></div></aside></div></div></section>';
}
function recordFromForm(ref) {
  return {
    ref: ref, createdAt: new Date().toISOString(), type: F.type, area: F.area, title: F.title.trim(), abstract: F.abstract.trim(),
    keywords: F.keywords.trim(), mlang: F.mlang, words: F.words || '', authors: F.authors.map(function (a) { return { name: a.name.trim(), aff: a.aff.trim(), country: a.country.trim(), email: a.email.trim(), orcid: a.orcid.trim(), corr: !!a.corr }; }),
    credit: F.credit, cover: F.cover, suggest: F.suggest, exclude: F.exclude, funding: F.funding, coi: F.coi,
    ethics: F.ethics, ethicsText: F.ethicsText, data: F.data, dataText: F.dataText, ai: F.ai, aiText: F.aiText, files: F.files, supp: F.supp
  };
}
function packageText(r) {
  var L = [];
  L.push('MATRIX BIOSCIENCE · ' + tr('Dossier de soumission', 'Submission file'));
  L.push(tr('Référence', 'Reference') + ': ' + r.ref);
  L.push(tr('Date', 'Date') + ': ' + r.createdAt);
  L.push('');
  L.push(tr('Type', 'Type') + ': ' + typeName(r.type));
  L.push(tr('Domaine', 'Field') + ': ' + domName(r.area));
  L.push(tr('Titre', 'Title') + ': ' + r.title);
  L.push(tr('Langue', 'Language') + ': ' + r.mlang);
  L.push(tr('Mots-clés', 'Keywords') + ': ' + r.keywords);
  L.push('');
  L.push(tr('AUTEURS', 'AUTHORS'));
  r.authors.forEach(function (a, i) { L.push((i + 1) + '. ' + a.name + (a.corr ? ' (' + tr('correspondant', 'corresponding') + ')' : '') + ' — ' + a.aff + (a.country ? ', ' + a.country : '') + (a.email ? ' — ' + a.email : '') + (a.orcid ? ' — ORCID ' + a.orcid : '')); });
  if (r.credit) { L.push(''); L.push(tr('CONTRIBUTIONS', 'CONTRIBUTIONS')); L.push(r.credit); }
  L.push(''); L.push(tr('RÉSUMÉ', 'ABSTRACT')); L.push(r.abstract);
  L.push(''); L.push(tr('LETTRE DE PRÉSENTATION', 'COVER LETTER')); L.push(r.cover);
  if (r.suggest) { L.push(''); L.push(tr('RELECTEURS PROPOSÉS', 'SUGGESTED REVIEWERS')); L.push(r.suggest); }
  if (r.exclude) { L.push(''); L.push(tr('RELECTEURS À EXCLURE', 'REVIEWERS TO EXCLUDE')); L.push(r.exclude); }
  L.push(''); L.push(tr('FINANCEMENT', 'FUNDING')); L.push(r.funding || '-');
  L.push(tr('CONFLITS D’INTÉRÊTS', 'CONFLICTS OF INTEREST') + ': ' + r.coi);
  L.push(tr('ÉTHIQUE', 'ETHICS') + ': ' + r.ethics + (r.ethicsText ? ' — ' + r.ethicsText : ''));
  L.push(tr('DONNÉES', 'DATA') + ': ' + r.data + (r.dataText ? ' — ' + r.dataText : ''));
  L.push(tr('IA GÉNÉRATIVE', 'GENERATIVE AI') + ': ' + r.ai + (r.aiText ? ' — ' + r.aiText : ''));
  L.push(''); L.push(tr('Déclarations 1 à 4 cochées par l’auteur correspondant.', 'Declarations 1 to 4 ticked by the corresponding author.'));
  return L.join('\n');
}
function viewDone() {
  var r = done.rec, online = done.online, mail = DATA.settings.email;
  return headHTML(esc(online ? tr('Soumission enregistrée', 'Submission recorded') : tr('Dossier prêt', 'File ready')), online ? tr('Merci, votre manuscrit est reçu', 'Thank you, your manuscript is received') : tr('Dossier prêt à envoyer', 'File ready to send'),
    online ? tr('Conservez cette référence. Elle sert à suivre le dossier et à écrire à la rédaction.', 'Keep this reference. Use it to track the file and to write to the editorial team.') : tr('Rien n’a encore été transmis. Envoyez le texte ci-dessous au secrétariat par e-mail, avec le manuscrit en PDF.', 'Nothing has been sent yet. Email the text below to the editorial office together with the PDF manuscript.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="stack" style="max-width:820px"><div><p class="eyebrow" style="margin-bottom:8px">' + esc(tr('Référence', 'Reference')) + '</p><div class="refbox" id="refbox">' + esc(r.ref) + '</div></div>' +
    (online ? '<div class="alert ok">' + esc(tr('La rédaction contrôle le périmètre, la forme et la similarité du texte, puis vous écrit. Le statut du dossier est consultable dans « Suivre une soumission ».', 'The editorial team checks scope, format and similarity, then writes to you. File status is available under “Track a submission”.')) + '</div>' :
      '<div class="alert warn"><b>' + esc(tr('Adresse du secrétariat : ', 'Editorial office address: ')) + '</b>' + (mail ? '<span class="mono">' + esc(mail) + '</span>' : esc(tr('à venir (voir la page Contact)', 'coming soon (see the Contact page)'))) + '</div>' +
      '<pre class="pkg" id="pkg">' + esc(packageText(r)) + '</pre>') +
    '<div class="cta-row">' + (online ? '' : '<button class="btn primary" data-act="copyPkg">' + esc(tr('Copier le dossier', 'Copy the file')) + '</button>') +
    (cap.dl ? '<button class="btn' + (online ? ' primary' : '') + '" data-act="dlPkg">' + esc(tr('Télécharger le récépissé', 'Download receipt')) + '</button>' : '') +
    (online ? '<a class="btn" href="#suivi">' + esc(tr('Suivre ma soumission', 'Track my submission')) + '</a>' : '') +
    '<button class="btn link" data-act="newSub">' + esc(tr('Nouvelle soumission', 'New submission')) + '</button></div></div></div></section>';
}
async function doSubmit() {
  if (busy) return;
  for (var n = 0; n < 4; n++) { var e = validate(n); if (Object.keys(e).length) { errs = e; step = n; renderView(); firstBad(); return; } }
  var online = !!cap.db && !!cap.uid, ref = 'MB-' + new Date().getFullYear() + '-' + Math.random().toString(36).slice(2, 8).toUpperCase();
  var rec = recordFromForm(ref);
  if (!online) { done = { rec: rec, online: false }; renderView(); window.scrollTo(0, 0); return; }
  busy = true; renderView();
  try {
    var dref = cap.db.doc('submissions/' + cap.uid), snap = await dref.get(), o = {};
    o[ref] = rec;
    if (snap.exists) await dref.update({ subs: o }); else await dref.set({ uid: cap.uid, subs: o });
    done = { rec: rec, online: true };
    F = blankForm(); step = 0; errs = {}; lsSet('mb-draft', '');
  } catch (er) {
    if (er && er.code === 'invalid_argument') { done = { rec: rec, online: false }; busy = false; renderView(); window.scrollTo(0, 0); toast(tr('L’envoi en ligne n’est pas autorisé pour votre accès : utilisez l’e-mail.', 'Online submission is not allowed for your access: use email.')); return; }
    toast(tr('L’envoi a échoué. Votre saisie est conservée ; réessayez ou utilisez l’e-mail.', 'Sending failed. Your entries are kept; try again or use email.') + (er && er.code ? ' (' + er.code + ')' : ''));
  }
  busy = false; renderView(); window.scrollTo(0, 0);
}
async function uploadFile(input) {
  var kind = input.getAttribute('data-up'), file = input.files && input.files[0];
  if (!file || !cap.assets) return;
  var isPdf = /pdf$/i.test(file.type) || /\.pdf$/i.test(file.name);
  var type = file.type;
  if (!type) { var x = (file.name.split('.').pop() || '').toLowerCase(); type = { pdf: 'application/pdf', csv: 'text/csv', txt: 'text/plain', json: 'application/json', md: 'text/markdown' }[x] || ''; }
  if (/excel/.test(type)) type = 'text/csv';
  if (kind === 'files' && !isPdf) { errs.files = tr('Le manuscrit doit être un PDF.', 'The manuscript must be a PDF.'); renderView(); return; }
  if (file.size > 20 * 1048576) { toast(tr('Fichier trop volumineux (20 Mo maximum).', 'File too large (20 MB maximum).')); input.value = ''; return; }
  try {
    toast(tr('Téléversement…', 'Uploading…'));
    var res = await cap.assets.upload(file, type ? { type: type } : undefined);
    var item = { id: res.id, name: file.name, size: res.sizeBytes };
    if (kind === 'files') F.files = [item]; else F.supp.push(item);
    delete errs.files; saveDraft(); renderView();
  } catch (er) {
    toast(tr('Téléversement impossible', 'Upload failed') + (er && er.code ? ' (' + er.code + ')' : ''));
  }
}

/* ---------- tracking ---------- */
var track = { loading: false, subs: null, status: {}, err: '' };
async function loadTrack() {
  if (!cap.db || !cap.uid || track.loading) return;
  track.loading = true;
  try {
    var snap = await cap.db.doc('submissions/' + cap.uid).get(), list = [];
    if (snap.exists) { var subs = (snap.data() || {}).subs || {}; Object.keys(subs).forEach(function (k) { list.push(subs[k]); }); }
    list.sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); });
    track.subs = list;
    for (var i = 0; i < list.length; i++) {
      var s = await cap.db.doc('status/' + list[i].ref).get();
      track.status[list[i].ref] = s.exists ? (s.data() || {}) : null;
    }
  } catch (er) { track.err = er && er.code ? er.code : 'error'; track.subs = track.subs || []; }
  track.loading = false;
  if (route === 'suivi') renderView();
}
function viewTrack() {
  var head = headHTML(esc(tr('Mes dossiers', 'My files')), tr('Suivre une soumission', 'Track a submission'), tr('Le statut est mis à jour par la rédaction à chaque étape.', 'The editorial team updates the status at each stage.'));
  var body;
  if (!cap.db || !cap.uid) body = '<div class="empty"><h3>' + esc(tr('Connexion requise', 'Sign-in required')) + '</h3><p>' + esc(tr('Le suivi en ligne n’est disponible que pour les manuscrits soumis en ligne par un compte connecté. Pour un envoi par e-mail, écrivez au secrétariat avec votre référence.', 'Online tracking is only available for manuscripts submitted online by a signed-in account. For an email submission, write to the editorial office with your reference.')) + '</p></div>';
  else if (track.subs === null) body = '<p class="muted">' + esc(tr('Chargement…', 'Loading…')) + '</p>';
  else if (!track.subs.length) body = '<div class="empty"><h3>' + esc(tr('Aucune soumission', 'No submission')) + '</h3><p>' + esc(tr('Vous n’avez pas encore soumis de manuscrit avec ce compte.', 'You have not submitted a manuscript with this account yet.')) + '</p><a class="btn primary sm" href="#soumettre">' + esc(tr('Soumettre', 'Submit')) + '</a></div>';
  else body = '<div class="list">' + track.subs.map(function (s) {
    var st = track.status[s.ref], k = st && st.status ? st.status : 'received';
    return '<div><div class="t"><b>' + esc(s.title) + '</b><span class="mono">' + esc(s.ref) + '</span> · <span>' + esc(fmtDate(s.createdAt, true)) + '</span> · <span>' + esc(typeName(s.type)) + '</span></div><div>' + pill(k) + '</div></div>';
  }).join('') + '</div>';
  return head + '<section class="band tight" style="padding-top:8px"><div class="wrap" style="max-width:900px;margin:0 auto">' + body + (track.err ? '<p class="err" style="margin-top:12px">' + esc(track.err) + '</p>' : '') + '</div></section>';
}

/* ---------- editorial desk ---------- */
var adm = { tab: 'subs', subs: [], status: {}, notes: {}, filter: 'all', q: '', subscribed: false, open: null, edit: null, err: '' };
function flatten(docs) {
  var out = [];
  docs.forEach(function (d) { var dd = d.data() || {}, subs = dd.subs || {}; Object.keys(subs).forEach(function (k) { var r = subs[k]; r._uid = d.id; out.push(r); }); });
  out.sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); });
  return out;
}
function startAdmin() {
  if (adm.subscribed || !cap.db || !cap.admin) return;
  adm.subscribed = true;
  var refresh = function () { if (route === 'editorial' && adm.tab === 'subs') { var b = $('#adm-body'); if (b) b.innerHTML = subsHTML(); } };
  var onErr = function (e) { adm.err = (e && e.code) || 'error'; refresh(); };
  try {
    cap.db.collection('submissions').onSnapshot(function (s) { adm.subs = flatten(s.docs); refresh(); }, onErr);
    cap.db.collection('status').onSnapshot(function (s) { adm.status = {}; s.docs.forEach(function (d) { adm.status[d.id] = d.data() || {}; }); refresh(); }, onErr);
    cap.db.collection('notes').onSnapshot(function (s) { adm.notes = {}; s.docs.forEach(function (d) { adm.notes[d.id] = d.data() || {}; }); }, onErr);
  } catch (e) { onErr(e); }
}
function statusOfRef(ref) { var s = adm.status[ref]; return s && s.status ? s.status : 'received'; }
function subsHTML() {
  var counts = { all: adm.subs.length };
  STATUSES.forEach(function (s) { counts[s[0]] = 0; });
  adm.subs.forEach(function (r) { counts[statusOfRef(r.ref)]++; });
  var q = adm.q.trim().toLowerCase();
  var list = adm.subs.filter(function (r) {
    if (adm.filter !== 'all' && statusOfRef(r.ref) !== adm.filter) return false;
    if (q && (r.title + ' ' + r.ref + ' ' + r.authors.map(function (a) { return a.name; }).join(' ')).toLowerCase().indexOf(q) < 0) return false;
    return true;
  });
  var chips = '<div class="chips"><button class="chip" data-act="filter" data-v="all" aria-pressed="' + (adm.filter === 'all') + '">' + esc(tr('Toutes', 'All')) + ' <em>' + counts.all + '</em></button>' +
    STATUSES.map(function (s) { return '<button class="chip" data-act="filter" data-v="' + s[0] + '" aria-pressed="' + (adm.filter === s[0]) + '">' + esc(lang === 'fr' ? s[1] : s[2]) + ' <em>' + counts[s[0]] + '</em></button>'; }).join('') + '</div>';
  var tbl = list.length ? '<div class="tbl-wrap"><table><thead><tr><th>' + esc(tr('Référence', 'Reference')) + '</th><th>' + esc(tr('Date', 'Date')) + '</th><th>' + esc(tr('Titre', 'Title')) + '</th><th>' + esc(tr('Domaine', 'Field')) + '</th><th>' + esc(tr('Auteur correspondant', 'Corresponding author')) + '</th><th>' + esc(tr('Statut', 'Status')) + '</th></tr></thead><tbody>' +
    list.map(function (r) {
      var c = (r.authors.filter(function (a) { return a.corr; })[0] || r.authors[0] || {});
      return '<tr class="click" tabindex="0" data-act="openSub" data-ref="' + esc(r.ref) + '"><td class="mono" style="font-size:12.5px">' + esc(r.ref) + '</td><td style="white-space:nowrap">' + esc(fmtDate(r.createdAt)) + '</td><td style="min-width:260px"><b>' + esc(r.title) + '</b></td><td><span class="dot" style="--c:' + domVar(r.area) + '">' + esc(domName(r.area)) + '</span></td><td>' + esc(c.name || '') + '</td><td>' + pill(statusOfRef(r.ref)) + '</td></tr>';
    }).join('') + '</tbody></table></div>' :
    '<div class="empty"><h3>' + esc(adm.subs.length ? tr('Aucun résultat', 'No result') : tr('Aucune soumission reçue', 'No submission received')) + '</h3><p>' + esc(adm.subs.length ? tr('Modifiez le filtre ou la recherche.', 'Change the filter or search.') : tr('Les manuscrits soumis en ligne apparaîtront ici en temps réel.', 'Manuscripts submitted online will appear here in real time.')) + '</p></div>';
  return chips + tbl + (adm.err ? '<p class="err" style="margin-top:10px">' + esc(adm.err) + '</p>' : '');
}
function csvCell(v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; }
async function exportCsv() {
  if (!cap.dl) { toast(tr('Export indisponible dans cette vue.', 'Export unavailable in this view.')); return; }
  var head = ['reference', 'date', 'status', 'type', 'field', 'title', 'corresponding_author', 'email', 'authors', 'keywords', 'files'];
  var rows = adm.subs.map(function (r) {
    var c = r.authors.filter(function (a) { return a.corr; })[0] || r.authors[0] || {};
    return [r.ref, r.createdAt, statusOfRef(r.ref), r.type, domName(r.area), r.title, c.name, c.email, r.authors.map(function (a) { return a.name; }).join('; '), r.keywords, (r.files || []).map(function (f) { return f.name; }).join('; ')].map(csvCell).join(',');
  });
  try { await cap.dl.save({ filename: 'matrix-bioscience-submissions.csv', data: '﻿' + [head.join(',')].concat(rows).join('\n') }); } catch (e) { /* declined */ }
}
function openSubHTML(r) {
  var st = statusOfRef(r.ref), note = (adm.notes[r.ref] || {}).text || '';
  function row(k, v) { return '<div><dt>' + esc(k) + '</dt><dd>' + v + '</dd></div>'; }
  var files = (r.files || []).concat(r.supp || []);
  return '<div class="ov" data-act="closeOv" id="ovbg"><div class="sheet" role="dialog" aria-modal="true" aria-labelledby="ov-t"><div class="sheet-head"><div><p class="eyebrow">' + esc(r.ref) + ' · ' + esc(fmtDate(r.createdAt, true)) + '</p><h2 id="ov-t" style="margin-top:6px">' + esc(r.title) + '</h2></div><button class="btn sm" data-act="closeOv" data-close="1">' + esc(tr('Fermer', 'Close')) + '</button></div><div class="sheet-body">' +
    '<div class="panel"><div class="row2"><div class="fld"><label for="st-sel">' + esc(tr('Statut', 'Status')) + '</label><select id="st-sel">' + opts(STATUSES.map(function (s) { return [s[0], lang === 'fr' ? s[1] : s[2]]; }), st) + '</select></div>' +
    '<div class="fld"><label for="st-note">' + esc(tr('Note interne (invisible pour les auteurs)', 'Internal note (hidden from authors)')) + '</label><textarea id="st-note" rows="3">' + esc(note) + '</textarea></div></div><div class="cta-row" style="margin-top:14px"><button class="btn primary sm" data-act="saveStatus" data-ref="' + esc(r.ref) + '">' + esc(tr('Enregistrer', 'Save')) + '</button></div></div>' +
    '<div><h3>' + esc(tr('Fiche', 'Record')) + '</h3><dl class="recap">' +
    row('Type', esc(typeName(r.type))) + row(tr('Domaine', 'Field'), esc(domName(r.area))) + row(tr('Langue', 'Language'), esc(r.mlang)) + row(tr('Mots-clés', 'Keywords'), esc(r.keywords)) +
    row(tr('Auteurs', 'Authors'), r.authors.map(function (a) { return esc(a.name) + (a.corr ? ' *' : '') + ' — ' + esc(a.aff) + (a.country ? ', ' + esc(a.country) : '') + (a.email ? ' — <span class="mono">' + esc(a.email) + '</span>' : '') + (a.orcid ? ' — ORCID ' + esc(a.orcid) : ''); }).join('<br>')) +
    row(tr('Résumé', 'Abstract'), esc(r.abstract)) + row(tr('Lettre de présentation', 'Cover letter'), esc(r.cover).replace(/\n/g, '<br>')) +
    (r.suggest ? row(tr('Relecteurs proposés', 'Suggested reviewers'), esc(r.suggest).replace(/\n/g, '<br>')) : '') + (r.exclude ? row(tr('Relecteurs exclus', 'Excluded reviewers'), esc(r.exclude).replace(/\n/g, '<br>')) : '') +
    row(tr('Financement', 'Funding'), esc(r.funding || '-')) + row(tr('Conflits d’intérêts', 'Conflicts of interest'), esc(r.coi)) +
    row(tr('Éthique', 'Ethics'), esc(r.ethics) + (r.ethicsText ? ' — ' + esc(r.ethicsText) : '')) + row(tr('Données', 'Data'), esc(r.data) + (r.dataText ? ' — ' + esc(r.dataText) : '')) + row(tr('IA générative', 'Generative AI'), esc(r.ai) + (r.aiText ? ' — ' + esc(r.aiText) : '')) +
    row(tr('Fichiers', 'Files'), files.length ? files.map(function (f) { return '<a href="/_blob/' + esc(f.id) + '" target="_blank" rel="noopener">' + esc(f.name) + '</a>'; }).join('<br>') : esc(tr('Aucun fichier déposé en ligne', 'No file uploaded online'))) +
    '</dl></div></div></div></div>';
}

function memberForm(d) {
  function ei(n, label, o) { o = o || {}; return fld('e-' + n, label, '<input type="text" id="e-' + n + '" data-e="' + n + '" value="' + esc(d[n]) + '">', { req: o.req, hint: o.hint }); }
  return '<form class="panel stack" data-form="member" novalidate><h3 style="font-size:20px;font-weight:650">' + esc(adm.edit.id === 'new' ? tr('Ajouter un membre', 'Add a member') : tr('Modifier le membre', 'Edit member')) + '</h3>' +
    '<div class="row2">' + ei('name', tr('Nom complet', 'Full name'), { req: 1 }) + fld('e-role', tr('Fonction', 'Role'), '<select id="e-role" data-e="role">' + opts(ROLES.map(function (r) { return [r[0], lang === 'fr' ? r[1] : r[2]]; }), d.role) + '</select>', { req: 1 }) + '</div>' +
    '<div class="row2">' + ei('aff', tr('Institution', 'Institution'), { req: 1 }) + ei('country', tr('Pays', 'Country')) + '</div>' +
    ei('expertise', tr('Domaines d’expertise', 'Expertise'), { hint: esc(tr('Séparés par des virgules.', 'Separated by commas.')) }) +
    '<div class="row2">' + ei('orcid', 'ORCID', { hint: '0000-0000-0000-0000' }) + '<div class="fld"><label for="e-photo">' + esc(tr('Photo', 'Photo')) + '</label>' + (d.photo ? '<div class="rowact"><div class="avatar" style="width:48px;height:48px"><img src="/_blob/' + esc(d.photo) + '" alt=""></div><button type="button" class="btn sm" data-act="rmPhoto">' + esc(tr('Retirer', 'Remove')) + '</button></div>' : '') + (cap.assets ? '<input type="file" id="e-photo" data-eup="photo" accept="image/png,image/jpeg,image/webp">' : '<p class="hint">' + esc(tr('Dépôt de photo indisponible dans cette vue.', 'Photo upload unavailable in this view.')) + '</p>') + '</div></div>' +
    fld('e-bio', tr('Courte biographie', 'Short bio'), '<textarea id="e-bio" data-e="bio" rows="3">' + esc(d.bio) + '</textarea>', {}) +
    (adm.edit.err ? '<p class="err" role="alert">' + esc(adm.edit.err) + '</p>' : '') +
    '<div class="cta-row"><button type="submit" class="btn primary sm">' + esc(tr('Enregistrer', 'Save')) + '</button><button type="button" class="btn sm" data-act="cancelEdit">' + esc(tr('Annuler', 'Cancel')) + '</button></div></form>';
}
function articleForm(d) {
  function ei(n, label, o) { o = o || {}; return fld('e-' + n, label, '<input type="' + (o.type || 'text') + '" id="e-' + n + '" data-e="' + n + '" value="' + esc(d[n]) + '">', { req: o.req, hint: o.hint }); }
  return '<form class="panel stack" data-form="article" novalidate><h3 style="font-size:20px;font-weight:650">' + esc(adm.edit.id === 'new' ? tr('Publier un article', 'Publish an article') : tr('Modifier l’article', 'Edit article')) + '</h3>' +
    ei('title', tr('Titre', 'Title'), { req: 1 }) + ei('authors', tr('Auteurs', 'Authors'), { req: 1, hint: esc(tr('Dans l’ordre de la publication.', 'In publication order.')) }) +
    '<div class="row3">' + fld('e-type', 'Type', '<select id="e-type" data-e="type">' + opts(TYPES.map(function (t) { return [t[0], lang === 'fr' ? t[1] : t[2]]; }), d.type) + '</select>', {}) + fld('e-area', tr('Domaine', 'Field'), '<select id="e-area" data-e="area">' + opts(DOMAINS.map(function (x) { return [x.k, x[lang][0]]; }), d.area) + '</select>', {}) + ei('date', tr('Date de publication', 'Publication date'), { type: 'date' }) + '</div>' +
    '<div class="row2">' + ei('issue', tr('Volume / numéro', 'Volume / issue'), { hint: tr('Exemple : Vol. 1, N° 1', 'Example: Vol. 1, No. 1') }) + ei('doi', 'DOI', { hint: tr('Sans https://doi.org/', 'Without https://doi.org/') }) + '</div>' +
    fld('e-abstract', tr('Résumé', 'Abstract'), '<textarea id="e-abstract" data-e="abstract" rows="5">' + esc(d.abstract) + '</textarea>', {}) +
    '<div class="row2"><div class="fld"><label for="e-pdf">PDF</label>' + (d.pdf ? '<p class="hint">' + esc(tr('PDF déposé.', 'PDF uploaded.')) + ' <button type="button" class="btn link" data-act="rmPdf">' + esc(tr('Retirer', 'Remove')) + '</button></p>' : '') + (cap.assets ? '<input type="file" id="e-pdf" data-eup="pdf" accept="application/pdf,.pdf">' : '<p class="hint">' + esc(tr('Dépôt indisponible dans cette vue.', 'Upload unavailable in this view.')) + '</p>') + '</div>' + ei('link', tr('Ou lien vers le texte intégral', 'Or link to the full text'), { type: 'url' }) + '</div>' +
    (adm.edit.err ? '<p class="err" role="alert">' + esc(adm.edit.err) + '</p>' : '') +
    '<div class="cta-row"><button type="submit" class="btn primary sm">' + esc(tr('Enregistrer', 'Save')) + '</button><button type="button" class="btn sm" data-act="cancelEdit">' + esc(tr('Annuler', 'Cancel')) + '</button></div></form>';
}
function boardTab() {
  var d = adm.edit && adm.edit.kind === 'member' ? memberForm(adm.edit.data) : '';
  var list = DATA.board.map(function (m, i) {
    return '<div><div class="t"><b>' + esc(m.name) + '</b><span>' + esc(lang === 'fr' ? roleOf(m.role)[1] : roleOf(m.role)[2]) + ' · ' + esc([m.aff, m.country].filter(Boolean).join(', ')) + '</span></div><div class="rowact">' +
      '<button class="btn sm" data-act="mUp" data-i="' + i + '" aria-label="' + esc(tr('Monter', 'Move up')) + '"' + (i === 0 ? ' disabled' : '') + '>↑</button><button class="btn sm" data-act="mDown" data-i="' + i + '" aria-label="' + esc(tr('Descendre', 'Move down')) + '"' + (i === DATA.board.length - 1 ? ' disabled' : '') + '>↓</button>' +
      '<button class="btn sm" data-act="mEdit" data-i="' + i + '">' + esc(tr('Modifier', 'Edit')) + '</button><button class="btn sm danger" data-act="mDel" data-i="' + i + '">' + esc(tr('Supprimer', 'Delete')) + '</button></div></div>';
  }).join('');
  return '<div class="stack"><div class="cta-row"><button class="btn primary sm" data-act="mNew">' + esc(tr('Ajouter un membre', 'Add a member')) + '</button></div>' + d +
    (list ? '<div class="list">' + list + '</div>' : '<div class="empty"><h3>' + esc(tr('Aucun membre', 'No member')) + '</h3><p>' + esc(tr('Ajoutez le rédacteur en chef, les rédacteurs associés et le comité scientifique.', 'Add the editor-in-chief, associate editors and the scientific committee.')) + '</p></div>') +
    '<p class="hint">' + esc(tr('L’ordre dans chaque groupe suit cette liste. Les modifications ne sont visibles du public qu’après « Publier sur le site ».', 'Order within each group follows this list. Changes only become public after “Publish to the site”.')) + '</p></div>';
}
function articlesTab() {
  var d = adm.edit && adm.edit.kind === 'article' ? articleForm(adm.edit.data) : '';
  var list = DATA.articles.map(function (a, i) {
    return '<div><div class="t"><b>' + esc(a.title) + '</b><span>' + esc(a.authors) + ' · ' + esc(domName(a.area)) + (a.date ? ' · ' + esc(a.date) : '') + '</span></div><div class="rowact"><button class="btn sm" data-act="aEdit" data-i="' + i + '">' + esc(tr('Modifier', 'Edit')) + '</button><button class="btn sm danger" data-act="aDel" data-i="' + i + '">' + esc(tr('Supprimer', 'Delete')) + '</button></div></div>';
  }).join('');
  return '<div class="stack"><div class="cta-row"><button class="btn primary sm" data-act="aNew">' + esc(tr('Publier un article', 'Publish an article')) + '</button></div>' + d +
    (list ? '<div class="list">' + list + '</div>' : '<div class="empty"><h3>' + esc(tr('Aucun article publié', 'No published article')) + '</h3><p>' + esc(tr('Après acceptation, ajoutez ici l’article définitif avec son DOI et son PDF.', 'After acceptance, add the final article here with its DOI and PDF.')) + '</p></div>') + '</div>';
}
function settingsTab() {
  var s = DATA.settings;
  function si(n, label, hint) { return fld('s-' + n, label, '<input type="text" id="s-' + n + '" name="' + n + '" value="' + esc(s[n]) + '">', { hint: hint }); }
  return '<form class="panel stack" data-form="settings" novalidate style="max-width:760px">' +
    '<div class="row2">' + si('email', tr('E-mail du secrétariat', 'Editorial office email'), esc(tr('Affiché sur la page Contact et dans le mode d’envoi par e-mail.', 'Shown on the Contact page and used in email submission mode.'))) + si('issn', 'ISSN', esc(tr('Laissez vide tant qu’il n’est pas attribué.', 'Leave empty until assigned.'))) + '</div>' +
    '<div class="row2">' + si('publisher', tr('Éditeur', 'Publisher')) + si('issue', tr('Numéro en préparation', 'Issue in preparation'), esc(tr('Exemple : Volume 1, Numéro 1 (2027)', 'Example: Volume 1, Issue 1 (2027)'))) + '</div>' +
    fld('s-address', tr('Adresse postale', 'Postal address'), '<textarea id="s-address" name="address" rows="3">' + esc(s.address) + '</textarea>', {}) +
    '<label class="chk"><input type="checkbox" id="s-open" name="open"' + (s.open ? ' checked' : '') + '><span>' + esc(tr('Appel à contributions ouvert', 'Call for papers open')) + '</span></label>' +
    '<div class="cta-row"><button type="submit" class="btn primary sm">' + esc(tr('Enregistrer les paramètres', 'Save settings')) + '</button></div></form>' +
    '<div class="panel stack" style="margin-top:20px;max-width:760px"><h3 style="font-size:19px;font-weight:650">' + esc(tr('Sauvegarde du contenu', 'Content backup')) + '</h3><p class="muted">' + esc(tr('Le comité, les articles et les paramètres sont stockés dans la page. Exportez-les en JSON pour les archiver.', 'The board, articles and settings are stored in the page. Export them as JSON to archive them.')) + '</p><div class="cta-row"><button class="btn sm" data-act="copyJson">' + esc(tr('Copier le JSON', 'Copy JSON')) + '</button>' + (cap.dl ? '<button class="btn sm" data-act="dlJson">' + esc(tr('Télécharger', 'Download')) + '</button>' : '') + '</div></div>';
}
function viewAdmin() {
  var head = headHTML(esc(tr('Réservé à la rédaction', 'Editorial staff only')), tr('Espace éditorial', 'Editorial desk'), '');
  if (!cap.ready) return head + '<section class="band tight"><div class="wrap"><p class="muted">' + esc(tr('Chargement…', 'Loading…')) + '</p></div></section>';
  if (!cap.admin) return head + '<section class="band tight"><div class="wrap"><div class="empty"><h3>' + esc(tr('Accès réservé', 'Restricted access')) + '</h3><p>' + esc(tr('Cet espace est réservé aux éditeurs de la revue. Connectez-vous avec un compte qui a le droit de modifier la page.', 'This area is for the journal’s editors. Sign in with an account that can edit the page.')) + '</p></div></div></section>';
  startAdmin();
  var tabs = [['subs', tr('Soumissions', 'Submissions')], ['board', tr('Comité', 'Board')], ['articles', 'Articles'], ['settings', tr('Paramètres', 'Settings')]];
  var body = adm.tab === 'subs' ? '<div class="cta-row" style="margin-bottom:16px;align-items:end"><div class="fld" style="flex:1;min-width:220px"><label for="adm-q">' + esc(tr('Rechercher', 'Search')) + '</label><input type="search" id="adm-q" value="' + esc(adm.q) + '" placeholder="' + esc(tr('Titre, auteur, référence', 'Title, author, reference')) + '"></div><button class="btn sm" data-act="exportCsv">' + esc(tr('Exporter en CSV', 'Export CSV')) + '</button></div><div id="adm-body">' + subsHTML() + '</div>' :
    adm.tab === 'board' ? boardTab() : adm.tab === 'articles' ? articlesTab() : settingsTab();
  return head + '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="pubbar" id="pubbar">' + pubBar() + '</div><div class="tabs" role="tablist">' + tabs.map(function (t) { return '<button role="tab" data-act="tab" data-v="' + t[0] + '" aria-selected="' + (adm.tab === t[0]) + '">' + esc(t[1]) + '</button>'; }).join('') + '</div>' + body + '</div></section>';
}
function pubBar() {
  if (!dirty) return '';
  return '<div class="alert warn" style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap"><span><b>' + esc(tr('Modifications non publiées.', 'Unpublished changes.')) + '</b> ' + esc(tr('Le public voit encore l’ancienne version.', 'The public still sees the previous version.')) + '</span><button class="btn primary sm" data-act="publish">' + esc(tr('Publier sur le site', 'Publish to the site')) + '</button></div>';
}
function markDirty() { dirty = true; try { sessionStorage.setItem('mb-dirty', JSON.stringify(DATA)); } catch (e) { /* ignore */ } var b = $('#pubbar'); if (b) b.innerHTML = pubBar(); }

/* ---------- self publish ---------- */
var SHELL = '<div id="app"></div><div id="ov"></div><div id="toasts" class="toast-wrap" aria-live="polite"></div>';
function buildDoc() {
  var css = $('#app-css').textContent, js = $('#app-js').textContent;
  if (js.indexOf('/*MB-START*/') < 0 || js.indexOf('/*MB-END*/') < 0 || css.indexOf('--d-a') < 0) return null;
  var reset = '';
  $$('style', document.head).forEach(function (s) { if (!reset && /safe-area/.test(s.textContent)) reset = s.textContent; });
  if (!reset) reset = ':root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui,sans-serif}img{max-width:100%}[hidden]{display:none!important}';
  var json = JSON.stringify(DATA).replace(/</g, '\\u003c').split(String.fromCharCode(8232)).join('\\u2028').split(String.fromCharCode(8233)).join('\\u2029');
  var end = '</scr' + 'ipt>';
  var page = '<title>Matrix Bioscience</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n' +
    '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n<link rel="stylesheet" href="' + FONT_URL + '">\n' +
    '<style id="app-css">' + css + '</style>\n' + SHELL + '\n<script type="application/json" id="site-data">' + json + end + '\n<script id="app-js">' + js + end;
  return '<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>' + reset + '</style></head><body>' + page + '</body></html>';
}
async function publishSite() {
  if (!cap.art) { toast(tr('La publication directe est indisponible dans cette vue. Copiez le JSON et transmettez-le.', 'Direct publishing is unavailable in this view. Copy the JSON and pass it on.')); return; }
  var html = buildDoc();
  if (!html) { toast(tr('Publication automatique impossible. Utilisez « Copier le JSON ».', 'Automatic publishing not possible. Use “Copy JSON”.')); return; }
  try { toast(tr('Publication en cours…', 'Publishing…')); await cap.art.publish(html); }
  catch (er) {
    var c = er && er.code;
    toast(c === 'conflict' ? tr('Une version plus récente existe. La page se recharge ; refaites la modification.', 'A newer version exists. The page is reloading; redo the change.') :
      (c === 'not_writer' || c === 'not_granted') ? tr('Votre compte ne peut pas modifier la page.', 'Your account cannot edit the page.') : tr('Échec de la publication', 'Publishing failed') + (c ? ' (' + c + ')' : ''));
  }
}
