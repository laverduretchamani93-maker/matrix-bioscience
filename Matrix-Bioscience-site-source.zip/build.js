const fs = require('fs');
const css = fs.readFileSync('app.css', 'utf8');
const js = fs.readFileSync('part1.js', 'utf8') + fs.readFileSync('part2.js', 'utf8') + fs.readFileSync('part3.js', 'utf8');
fs.writeFileSync('app.js', js);
const data = {
  settings: { email: '', issn: '', publisher: '', address: '', open: true, issue: '' },
  board: [{ id: 'fondateur', name: 'Laverdure Tchamani Piame', role: 'founder', aff: 'Walter Sisulu University', country: 'South Africa', expertise: 'Food microbiology, Functional foods, Food safety', orcid: '', bio: '', photo: '' }],
  articles: []
};
const FONT_URL = 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wdth,wght@12..96,75..100,200..800&family=IBM+Plex+Mono:wght@400;500&family=Newsreader:ital,opsz,wght@0,6..72,300..700;1,6..72,300..700&display=swap';
const page = '<title>Matrix Bioscience</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n' +
 '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n<link rel="stylesheet" href="' + FONT_URL + '">\n' +
 '<style id="app-css">' + css + '</style>\n<div id="app"></div><div id="ov"></div><div id="toasts" class="toast-wrap" aria-live="polite"></div>\n' +
 '<script type="application/json" id="site-data">' + JSON.stringify(data).replace(/</g, '\\u003c') + '</scr' + 'ipt>\n<script id="app-js">' + js + '</scr' + 'ipt>\n';
fs.writeFileSync('index.html', page);
console.log('bytes', page.length, 'script-end occurrences in js:', (js.match(/<\/script/gi) || []).length);
