/*MB-START*/
(function () {
'use strict';

/* ---------- helpers ---------- */
var FONT_URL = 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wdth,wght@12..96,75..100,200..800&family=IBM+Plex+Mono:wght@400;500&family=Newsreader:ital,opsz,wght@0,6..72,300..700;1,6..72,300..700&display=swap';
var $ = function (s, r) { return (r || document).querySelector(s); };
var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ESC[c]; }); }
function nl2p(s) { return String(s || '').split(/\n{2,}/).map(function (p) { return '<p>' + esc(p).replace(/\n/g, '<br>') + '</p>'; }).join(''); }
function uid2() { return Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3); }
function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } }
function words(s) { var m = String(s || '').trim().match(/\S+/g); return m ? m.length : 0; }

var DATA = {};
try { DATA = JSON.parse($('#site-data').textContent) || {}; } catch (e) { DATA = {}; }
DATA.settings = Object.assign({ email: '', issn: '', publisher: '', address: '', open: true, issue: '' }, DATA.settings || {});
DATA.board = Array.isArray(DATA.board) ? DATA.board : [];
DATA.articles = Array.isArray(DATA.articles) ? DATA.articles : [];

var lang = lsGet('mb-lang');
if (lang !== 'fr' && lang !== 'en') lang = /^en/i.test(navigator.language || '') ? 'en' : 'fr';
function tr(fr, en) { return lang === 'fr' ? fr : en; }
var th0 = lsGet('mb-theme');
if (th0 === 'dark' || th0 === 'light') document.documentElement.setAttribute('data-theme', th0);

var cap = { db: null, uid: null, assets: null, dl: null, art: null, admin: false, ready: false };
var route = 'accueil';
var pending = null;
var dirty = false;

var ROUTES = ['accueil', 'domaines', 'articles', 'comite', 'auteurs', 'politiques', 'contact', 'soumettre', 'suivi', 'editorial'];
var NAV = [
  ['accueil', 'Accueil', 'Home'], ['domaines', 'Domaines', 'Fields'], ['articles', 'Articles', 'Articles'],
  ['comite', 'Comité éditorial', 'Editorial board'], ['auteurs', 'Auteurs', 'Authors'],
  ['politiques', 'Politiques', 'Policies'], ['contact', 'Contact', 'Contact']
];

/* ---------- content ---------- */
var DOMAINS = [
  { k: 'A', fr: ['Sciences biologiques', 'Biologie cellulaire et moléculaire, génétique, physiologie, écologie et biodiversité. Des travaux qui expliquent le fonctionnement des organismes et de leurs populations.', ['Biologie cellulaire et moléculaire', 'Génétique et génomique', 'Physiologie', 'Écologie et biodiversité', 'Évolution', 'Biologie du développement']],
    en: ['Biological sciences', 'Cell and molecular biology, genetics, physiology, ecology and biodiversity. Work that explains how organisms and their populations function.', ['Cell and molecular biology', 'Genetics and genomics', 'Physiology', 'Ecology and biodiversity', 'Evolution', 'Developmental biology']] },
  { k: 'B', fr: ['Biotechnologie', 'Outils et procédés qui utilisent le vivant : génie génétique, bioprocédés, biologie synthétique, biotechnologies industrielles et environnementales.', ['Génie génétique et édition du génome', 'Bioprocédés et fermentation industrielle', 'Biologie synthétique', 'Biotechnologie environnementale', 'Bio-informatique et biologie des systèmes', 'Biocapteurs et diagnostic']],
    en: ['Biotechnology', 'Tools and processes built on living systems: genetic engineering, bioprocesses, synthetic biology, industrial and environmental biotechnology.', ['Genetic engineering and genome editing', 'Bioprocesses and industrial fermentation', 'Synthetic biology', 'Environmental biotechnology', 'Bioinformatics and systems biology', 'Biosensors and diagnostics']] },
  { k: 'C', fr: ['Microbiologie', 'Bactéries, virus, champignons et levures, leurs communautés et leurs effets sur la santé, les aliments et les milieux naturels.', ['Bactériologie, virologie, mycologie', 'Microbiotes (intestin, sol, aliments)', 'Probiotiques et souches d’intérêt technologique', 'Résistance aux antimicrobiens', 'Microbiologie alimentaire', 'Métagénomique']],
    en: ['Microbiology', 'Bacteria, viruses, fungi and yeasts, their communities and their effects on health, food and natural environments.', ['Bacteriology, virology, mycology', 'Microbiomes (gut, soil, food)', 'Probiotics and technological strains', 'Antimicrobial resistance', 'Food microbiology', 'Metagenomics']] },
  { k: 'D', fr: ['Biochimie', 'Structure et fonction des molécules du vivant, voies métaboliques et régulation, avec une attention particulière à la nutrition et aux molécules bioactives.', ['Enzymologie', 'Métabolisme et régulation', 'Protéomique et métabolomique', 'Biochimie nutritionnelle', 'Molécules bioactives', 'Stress oxydant et antioxydants']],
    en: ['Biochemistry', 'Structure and function of biological molecules, metabolic pathways and their regulation, with a focus on nutrition and bioactive compounds.', ['Enzymology', 'Metabolism and regulation', 'Proteomics and metabolomics', 'Nutritional biochemistry', 'Bioactive compounds', 'Oxidative stress and antioxidants']] },
  { k: 'E', fr: ['Agriculture', 'Production végétale et animale, sols, protection des cultures et adaptation des systèmes de production au climat.', ['Agronomie et production végétale', 'Élevage et production animale', 'Aquaculture', 'Sols et fertilité', 'Protection des cultures', 'Agriculture durable et climat', 'Ressources génétiques']],
    en: ['Agriculture', 'Crop and animal production, soils, crop protection and the adaptation of production systems to climate.', ['Agronomy and crop production', 'Livestock and animal production', 'Aquaculture', 'Soils and fertility', 'Crop protection', 'Sustainable agriculture and climate', 'Genetic resources']] },
  { k: 'F', fr: ['Systèmes alimentaires', 'De la production à la consommation : chaînes de valeur, sécurité alimentaire et nutritionnelle, politiques publiques, durabilité.', ['Sécurité alimentaire et nutritionnelle', 'Chaînes de valeur', 'Pertes et gaspillage alimentaires', 'Politiques et gouvernance', 'Durabilité et impact environnemental', 'Alimentation et santé publique', 'Savoirs locaux et aliments traditionnels']],
    en: ['Food systems', 'From production to consumption: value chains, food and nutrition security, public policy, sustainability.', ['Food and nutrition security', 'Value chains', 'Food loss and waste', 'Policy and governance', 'Sustainability and environmental impact', 'Diet and public health', 'Local knowledge and traditional foods']] },
  { k: 'G', fr: ['Science des aliments', 'Transformation, conservation, qualité et sécurité sanitaire des aliments, aliments fonctionnels et procédés de fermentation.', ['Transformation et conservation', 'Qualité et sécurité sanitaire', 'Aliments fonctionnels et nutraceutiques', 'Fermentation', 'Analyse sensorielle', 'Emballage', 'Valorisation des coproduits']],
    en: ['Food science', 'Processing, preservation, quality and safety of foods, functional foods and fermentation processes.', ['Processing and preservation', 'Quality and food safety', 'Functional foods and nutraceuticals', 'Fermentation', 'Sensory analysis', 'Packaging', 'By-product valorisation']] },
  { k: 'H', fr: ['Interdisciplinaire', 'Travaux qui relient plusieurs domaines : une approche One Health, un lien entre alimentation et santé, une méthode utile à plusieurs disciplines.', ['One Health', 'Alimentation et santé métabolique', 'Statistiques et modélisation', 'Éthique, biosécurité et réglementation', 'Enseignement des sciences du vivant']],
    en: ['Interdisciplinary', 'Work that connects several fields: a One Health approach, a link between diet and health, a method useful across disciplines.', ['One Health', 'Diet and metabolic health', 'Statistics and modelling', 'Ethics, biosafety and regulation', 'Life science education']] }
];
function dom(k) { for (var i = 0; i < DOMAINS.length; i++) if (DOMAINS[i].k === k) return DOMAINS[i]; return DOMAINS[7]; }
function domName(k) { return dom(k)[lang][0]; }
function domVar(k) { return 'var(--d-' + String(k).toLowerCase() + ')'; }

var TYPES = [
  ['research', 'Article de recherche', 'Original research', 6000, 250, 'Travaux originaux avec méthodes, résultats et discussion.', 'Original work with methods, results and discussion.'],
  ['review', 'Revue de littérature', 'Review article', 8000, 300, 'Synthèse critique et structurée de la littérature sur une question précise.', 'Critical, structured synthesis of the literature on a defined question.'],
  ['short', 'Communication brève', 'Short communication', 3000, 150, 'Résultat préliminaire ou ciblé qui mérite une diffusion rapide.', 'Preliminary or focused finding that deserves fast dissemination.'],
  ['methods', 'Méthodes et protocoles', 'Methods and protocols', 5000, 250, 'Méthode nouvelle ou améliorée, décrite assez précisément pour être reproduite.', 'New or improved method, described precisely enough to be reproduced.'],
  ['perspective', 'Point de vue', 'Perspective', 2000, 150, 'Position argumentée sur une question d’actualité scientifique.', 'Argued position on a current scientific question.'],
  ['data', 'Note de données', 'Data note', 2500, 150, 'Description d’un jeu de données, d’une collection de souches ou d’un génome.', 'Description of a dataset, a strain collection or a genome.']
];
function typeOf(k) { for (var i = 0; i < TYPES.length; i++) if (TYPES[i][0] === k) return TYPES[i]; return TYPES[0]; }
function typeName(k) { var t = typeOf(k); return lang === 'fr' ? t[1] : t[2]; }

var ROLES = [
  ['founder', 'Fondateur', 'Founder', 'Fondation', 'Founding'],
  ['chief', 'Rédacteur en chef', 'Editor-in-Chief', 'Rédaction en chef', 'Editor-in-Chief'],
  ['deputy', 'Rédacteur en chef adjoint', 'Deputy Editor', 'Rédaction en chef adjointe', 'Deputy Editors'],
  ['associate', 'Rédacteur associé', 'Associate Editor', 'Rédacteurs associés', 'Associate Editors'],
  ['scientific', 'Membre du comité scientifique', 'Scientific committee member', 'Comité scientifique', 'Scientific committee'],
  ['advisory', 'Conseil consultatif international', 'International advisory board', 'Conseil consultatif international', 'International advisory board']
];
function roleOf(k) { for (var i = 0; i < ROLES.length; i++) if (ROLES[i][0] === k) return ROLES[i]; return ROLES[4]; }
function roleRank(k) { for (var i = 0; i < ROLES.length; i++) if (ROLES[i][0] === k) return i; return 4; }

var STATUSES = [
  ['received', 'Reçue', 'Received', '--d-h'],
  ['screening', 'Contrôle éditorial', 'Editorial screening', '--d-b'],
  ['review', 'En évaluation', 'Under review', '--d-c'],
  ['revision', 'Révision demandée', 'Revision requested', '--d-f'],
  ['accepted', 'Acceptée', 'Accepted', '--d-a'],
  ['rejected', 'Refusée', 'Declined', '--crit'],
  ['published', 'Publiée', 'Published', '--d-d']
];
function stOf(k) { for (var i = 0; i < STATUSES.length; i++) if (STATUSES[i][0] === k) return STATUSES[i]; return STATUSES[0]; }
function pill(k) { var s = stOf(k); return '<span class="pill" style="--c:var(' + s[3] + ')">' + esc(lang === 'fr' ? s[1] : s[2]) + '</span>'; }

function fmtDate(iso, long) {
  if (!iso) return '';
  var d = new Date(iso);
  if (isNaN(d.getTime())) return String(iso);
  try { return d.toLocaleDateString(lang === 'fr' ? 'fr-FR' : 'en-GB', { day: 'numeric', month: long ? 'long' : 'short', year: 'numeric' }); } catch (e) { return String(iso).slice(0, 10); }
}
function initials(n) { var p = String(n || '?').trim().split(/\s+/); return ((p[0] || '?')[0] + (p.length > 1 ? p[p.length - 1][0] : '')).toUpperCase(); }
function hue(n) { var h = 0, s = String(n || ''); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return 'var(--d-' + 'abcdefg'[h % 7] + ')'; }
function issnText() { return DATA.settings.issn ? 'ISSN ' + esc(DATA.settings.issn) : tr('ISSN en cours d’attribution', 'ISSN pending'); }
function issueLabel() { return DATA.settings.issue || tr('Volume 1, Numéro 1', 'Volume 1, Issue 1'); }

/* ---------- plate ---------- */
function plateSVG() {
  var rows = 'ABCDEFGH', cols = 12, pitch = 36, R = 14, ox = 38, oy = 34;
  var w = ox + (cols - 1) * pitch + 2 * R + 16, h = oy + 7 * pitch + 2 * R + 14;
  var s = '<svg class="plate" id="plate" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(tr('Microplaque de 96 puits. Chaque rangée de A à H correspond à un domaine de la revue.', '96-well microplate. Each row from A to H stands for one field of the journal.')) + '">';
  s += '<path class="plate-body" d="M26 2 H' + (w - 12) + ' Q' + (w - 2) + ' 2 ' + (w - 2) + ' 12 V' + (h - 12) + ' Q' + (w - 2) + ' ' + (h - 2) + ' ' + (w - 12) + ' ' + (h - 2) + ' H12 Q2 ' + (h - 2) + ' 2 ' + (h - 12) + ' V26 Z"/>';
  var r, c, cx, cy, op;
  for (c = 0; c < cols; c++) s += '<text class="plate-lbl" x="' + (ox + R + c * pitch) + '" y="' + (oy - 6) + '">' + (c + 1) + '</text>';
  for (r = 0; r < 8; r++) {
    cy = oy + R + r * pitch;
    s += '<text class="plate-lbl" x="18" y="' + (cy + 4) + '">' + rows[r] + '</text>';
    for (c = 0; c < cols; c++) {
      cx = ox + R + c * pitch;
      if (c === cols - 1) { s += '<circle class="well blank r-' + rows[r] + '" data-row="' + rows[r] + '" cx="' + cx + '" cy="' + cy + '" r="' + R + '"/>'; }
      else { op = (0.96 - c * 0.078).toFixed(2); s += '<circle class="well r-' + rows[r] + '" data-row="' + rows[r] + '" cx="' + cx + '" cy="' + cy + '" r="' + R + '" fill-opacity="' + op + '"/>'; }
    }
  }
  return s + '</svg>';
}
function logoSVG() {
  return '<svg viewBox="0 0 30 30" aria-hidden="true"><circle cx="9" cy="9" r="6" fill="var(--d-c)"/><circle cx="21" cy="9" r="6" fill="var(--d-a)" fill-opacity=".72"/><circle cx="9" cy="21" r="6" fill="var(--d-b)" fill-opacity=".5"/><circle cx="21" cy="21" r="6" fill="none" stroke="var(--ink-2)" stroke-width="1.5"/></svg>';
}

/* ---------- shell ---------- */
function headerHTML() {
  var nav = NAV.map(function (n) { return '<a href="#' + n[0] + '"' + (route === n[0] ? ' aria-current="page"' : '') + '>' + esc(tr(n[1], n[2])) + '</a>'; }).join('');
  var admin = cap.admin ? '<a class="ibtn admin-link" href="#editorial" title="' + esc(tr('Espace éditorial', 'Editorial desk')) + '"' + (route === 'editorial' ? ' aria-current="page"' : '') + '>' + esc(tr('Éditeur', 'Editor')) + '</a>' : '';
  return '<header class="top" id="top"><div class="wrap">' +
    '<a class="brand" href="#accueil" aria-label="Matrix Bioscience">' + logoSVG() + '<b>Matrix Bioscience</b></a>' +
    '<nav class="nav" aria-label="' + esc(tr('Navigation principale', 'Main navigation')) + '">' + nav + '</nav>' +
    '<div class="tools">' + admin +
    '<button class="ibtn" data-act="lang" aria-label="' + esc(tr('Switch to English', 'Passer en français')) + '">' + (lang === 'fr' ? 'EN' : 'FR') + '</button>' +
    '<button class="ibtn" data-act="theme" aria-label="' + esc(tr('Changer de thème', 'Switch theme')) + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg></button>' +
    '<a class="btn primary sm" href="#soumettre">' + esc(tr('Soumettre', 'Submit')) + '</a>' +
    '<button class="ibtn menu-btn" data-act="menu" aria-label="Menu" aria-expanded="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>' +
    '</div></div></header>';
}
function footerHTML() {
  var s = DATA.settings;
  return '<footer class="foot"><div class="wrap"><div class="foot-grid">' +
    '<div><a class="brand" href="#accueil">' + logoSVG() + '<b>Matrix Bioscience</b></a>' +
    '<p class="muted" style="margin-top:14px;max-width:26em;font-size:16px">' + esc(tr('Revue multidisciplinaire en accès libre : sciences biologiques, biotechnologie, microbiologie, biochimie, agriculture, systèmes alimentaires et science des aliments.', 'Open-access multidisciplinary journal: biological sciences, biotechnology, microbiology, biochemistry, agriculture, food systems and food science.')) + '</p>' +
    '<p class="mono muted" style="margin-top:12px;font-size:12.5px">' + issnText() + (s.publisher ? ' · ' + esc(s.publisher) : '') + '</p></div>' +
    '<div><h4>' + esc(tr('La revue', 'The journal')) + '</h4><ul>' +
    '<li><a href="#domaines">' + esc(tr('Domaines', 'Fields')) + '</a></li><li><a href="#articles">Articles</a></li><li><a href="#comite">' + esc(tr('Comité éditorial', 'Editorial board')) + '</a></li><li><a href="#politiques">' + esc(tr('Politiques', 'Policies')) + '</a></li></ul></div>' +
    '<div><h4>' + esc(tr('Auteurs', 'Authors')) + '</h4><ul>' +
    '<li><a href="#soumettre">' + esc(tr('Soumettre un manuscrit', 'Submit a manuscript')) + '</a></li><li><a href="#suivi">' + esc(tr('Suivre une soumission', 'Track a submission')) + '</a></li><li><a href="#auteurs">' + esc(tr('Instructions aux auteurs', 'Author guidelines')) + '</a></li><li><a href="#contact">Contact</a></li></ul></div>' +
    '</div><small>© 2026 Matrix Bioscience. ' + esc(tr('Les articles sont publiés sous licence Creative Commons CC BY 4.0.', 'Articles are published under a Creative Commons CC BY 4.0 licence.')) + '</small></div></footer>';
}

/* ---------- public views ---------- */
function headHTML(eyebrow, title, lead) {
  return '<section class="page-head"><div class="wrap"><p class="eyebrow">' + eyebrow + '</p><h1>' + esc(title) + '</h1>' + (lead ? '<p>' + esc(lead) + '</p>' : '') + '</div></section>';
}
function legendHTML() {
  return DOMAINS.map(function (d) {
    return '<a class="leg r-' + d.k + '" href="#domaines" data-dom="' + d.k + '"><b>' + d.k + '</b><i></i>' + esc(d[lang][0]) + '</a>';
  }).join('');
}
function articleItem(a) {
  var pdf = a.pdf ? '<a href="/_blob/' + esc(a.pdf) + '" target="_blank" rel="noopener">PDF</a>' : (a.link ? '<a href="' + esc(a.link) + '" target="_blank" rel="noopener">' + esc(tr('Texte intégral', 'Full text')) + '</a>' : '');
  var doi = a.doi ? '<a href="https://doi.org/' + esc(a.doi) + '" target="_blank" rel="noopener">DOI ' + esc(a.doi) + '</a>' : '';
  return '<article class="art"><div class="art-meta"><span class="dot" style="--c:' + domVar(a.area) + '">' + esc(domName(a.area)) + '</span><span>' + esc(typeName(a.type)) + '</span>' +
    (a.date ? '<span>' + esc(fmtDate(a.date, true)) + '</span>' : '') + (a.issue ? '<span>' + esc(a.issue) + '</span>' : '') + '</div>' +
    '<h3>' + esc(a.title) + '</h3><p class="au">' + esc(a.authors) + '</p>' +
    (a.abstract ? '<details><summary>' + esc(tr('Résumé', 'Abstract')) + '</summary><p>' + esc(a.abstract) + '</p></details>' : '') +
    ((pdf || doi) ? '<div class="links">' + pdf + doi + '</div>' : '') + '</article>';
}
function memberHTML(m) {
  var av = m.photo ? '<div class="avatar"><img src="/_blob/' + esc(m.photo) + '" alt="" loading="lazy"></div>' : '<div class="avatar" style="--c:' + hue(m.name) + '" aria-hidden="true">' + esc(initials(m.name)) + '</div>';
  var exp = String(m.expertise || '').split(',').map(function (x) { return x.trim(); }).filter(Boolean);
  return '<div class="member">' + av + '<div><h3>' + esc(m.name) + '</h3><p class="aff">' + esc([m.aff, m.country].filter(Boolean).join(', ')) + '</p>' +
    (exp.length ? '<div class="exp">' + exp.map(function (x) { return '<span class="tag">' + esc(x) + '</span>'; }).join('') + '</div>' : '') +
    (m.bio ? '<p class="bio">' + esc(m.bio) + '</p>' : '') +
    (m.orcid ? '<a class="orcid" href="https://orcid.org/' + esc(m.orcid) + '" target="_blank" rel="noopener">ORCID ' + esc(m.orcid) + '</a>' : '') + '</div></div>';
}
function sortedBoard() {
  return DATA.board.map(function (m, i) { return { m: m, i: i }; }).sort(function (a, b) { return roleRank(a.m.role) - roleRank(b.m.role) || a.i - b.i; }).map(function (x) { return x.m; });
}

function viewHome() {
  var arts = DATA.articles.slice().sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')); }).slice(0, 3);
  var board = sortedBoard().slice(0, 6);
  var steps = [
    [tr('Soumission en ligne', 'Online submission'), tr('Le dossier est déposé avec le manuscrit en PDF et les déclarations.', 'The file is deposited with the PDF manuscript and the declarations.')],
    [tr('Contrôle éditorial', 'Editorial check'), tr('Périmètre, forme, contrôle de similarité et éthique.', 'Scope, format, similarity check and ethics.')],
    [tr('Évaluation', 'Peer review'), tr('Au moins deux relecteurs indépendants, en double anonymat.', 'At least two independent reviewers, double-anonymous.')],
    [tr('Décision', 'Decision'), tr('Accepter, demander une révision ou refuser, avec les rapports.', 'Accept, request a revision or decline, with the reports.')],
    [tr('Révision', 'Revision'), tr('Les auteurs répondent point par point aux relecteurs.', 'Authors reply to the reviewers point by point.')],
    [tr('Publication', 'Publication'), tr('Mise en ligne en accès libre dès la mise en forme terminée.', 'Open-access release as soon as typesetting is done.')]
  ];
  return '<section class="hero"><div class="wrap hero-grid"><div>' +
    '<p class="eyebrow">' + esc(tr('Revue à comité de lecture', 'Peer-reviewed journal')) + ' · ' + issnText() + '</p>' +
    '<h1>Matrix <span>Bioscience</span></h1>' +
    '<p class="lede">' + esc(tr('Revue en accès libre consacrée aux sciences biologiques, à la biotechnologie, à la microbiologie, à la biochimie, à l’agriculture, aux systèmes alimentaires et à la science des aliments. Elle publie des travaux originaux, des revues de littérature et des articles de méthode après évaluation par les pairs.', 'An open-access journal covering the biological sciences, biotechnology, microbiology, biochemistry, agriculture, food systems and food science. It publishes original research, reviews and methods papers after peer review.')) + '</p>' +
    '<div class="cta-row"><a class="btn primary" href="#soumettre">' + esc(tr('Soumettre un manuscrit', 'Submit a manuscript')) + '</a><a class="btn" href="#auteurs">' + esc(tr('Instructions aux auteurs', 'Author guidelines')) + '</a></div>' +
    '<dl class="facts">' +
    '<div><dt>' + esc(tr('Accès libre', 'Open access')) + '</dt><dd>' + esc(tr('Licence CC BY 4.0, lecture gratuite', 'CC BY 4.0 licence, free to read')) + '</dd></div>' +
    '<div><dt>' + esc(tr('Évaluation par les pairs', 'Peer review')) + '</dt><dd>' + esc(tr('Double anonymat, deux relecteurs au minimum', 'Double-anonymous, two reviewers minimum')) + '</dd></div>' +
    '<div><dt>' + esc(tr('Publication continue', 'Continuous publication')) + '</dt><dd>' + esc(tr('Chaque article paraît dès qu’il est prêt', 'Each article appears as soon as it is ready')) + '</dd></div>' +
    '<div><dt>' + esc(tr('Deux langues', 'Two languages')) + '</dt><dd>' + esc(tr('Manuscrits en anglais ou en français', 'Manuscripts in English or French')) + '</dd></div>' +
    '</dl></div>' +
    '<figure class="plate-wrap">' + plateSVG() + '<div class="legend" id="legend">' + legendHTML() + '</div>' +
    '<figcaption class="plate-cap">' + esc(tr('Une rangée par domaine, de A à H. La dilution de gauche à droite reprend la logique d’une plaque de 96 puits ; la colonne 12 reste vide, comme les puits témoins.', 'One row per field, A to H. The left-to-right dilution follows the logic of a 96-well plate; column 12 stays empty, like control wells.')) + '</figcaption></figure>' +
    '</div></section>' +

    '<section class="band alt"><div class="wrap"><div class="sec-head"><div><p class="eyebrow">' + esc(tr('Dernières publications', 'Latest publications')) + '</p><h2>' + esc(tr('Articles récents', 'Recent articles')) + '</h2></div>' +
    (arts.length ? '<a class="btn sm" href="#articles">' + esc(tr('Tous les articles', 'All articles')) + '</a>' : '') + '</div>' +
    (arts.length ? arts.map(articleItem).join('') :
      '<div class="empty"><h3>' + esc(tr('Le premier numéro est en préparation', 'The first issue is in preparation')) + '</h3><p>' + esc(tr('Aucun article n’est encore publié. Les premiers manuscrits acceptés paraîtront dans ' + issueLabel() + '.', 'No article is published yet. The first accepted manuscripts will appear in ' + issueLabel() + '.')) + '</p><a class="btn primary sm" href="#soumettre">' + esc(tr('Proposer un manuscrit', 'Propose a manuscript')) + '</a></div>') +
    '</div></section>' +

    '<section class="band"><div class="wrap"><div class="callout"><div>' +
    '<p class="eyebrow" style="color:inherit;opacity:.7">' + esc(DATA.settings.open ? tr('Appel ouvert', 'Open call') : tr('Appel à venir', 'Call opening soon')) + ' · ' + esc(issueLabel()) + '</p>' +
    '<h2 style="margin-top:10px">' + esc(tr('Six formats d’article, une même exigence de rigueur', 'Six article formats, one standard of rigour')) + '</h2>' +
    '<p>' + esc(tr('Les travaux qui croisent plusieurs disciplines sont les bienvenus : un résultat de microbiologie lu par des spécialistes de l’aliment, une méthode utile aux agronomes comme aux biochimistes.', 'Work that crosses disciplines is welcome: a microbiology result read by food scientists, a method useful to agronomists and biochemists alike.')) + '</p>' +
    '<div class="cta-row" style="margin-top:20px"><a class="btn primary" href="#soumettre">' + esc(tr('Soumettre', 'Submit')) + '</a><a class="btn" href="#auteurs">' + esc(tr('Formats et consignes', 'Formats and guidelines')) + '</a></div></div>' +
    '<ul>' + TYPES.map(function (t) { return '<li><b>' + t[3].toLocaleString(lang === 'fr' ? 'fr-FR' : 'en-GB') + '</b>' + esc(lang === 'fr' ? t[1] : t[2]) + '</li>'; }).join('') + '</ul>' +
    '</div><p class="muted" style="font-size:14px;margin-top:10px;font-family:var(--f-display)">' + esc(tr('Nombre maximal de mots du texte principal, hors références.', 'Maximum main-text word count, excluding references.')) + '</p></div></section>' +

    '<section class="band alt"><div class="wrap"><div class="sec-head"><div><p class="eyebrow">' + esc(tr('Parcours d’un manuscrit', 'Life of a manuscript')) + '</p><h2>' + esc(tr('De la soumission à la publication', 'From submission to publication')) + '</h2></div></div>' +
    '<ol class="steps">' + steps.map(function (s) { return '<li><h3>' + esc(s[0]) + '</h3><p>' + esc(s[1]) + '</p></li>'; }).join('') + '</ol></div></section>' +

    '<section class="band"><div class="wrap"><div class="sec-head"><div><p class="eyebrow">' + esc(tr('Comité éditorial', 'Editorial board')) + '</p><h2>' + esc(tr('Les personnes qui dirigent la revue', 'The people who lead the journal')) + '</h2></div><a class="btn sm" href="#comite">' + esc(tr('Voir le comité', 'See the board')) + '</a></div>' +
    (board.length ? '<div class="members">' + board.map(memberHTML).join('') + '</div>' : '<div class="empty"><h3>' + esc(tr('Comité en cours de constitution', 'Board being assembled')) + '</h3><p>' + esc(tr('Les noms des rédacteurs et des membres du comité scientifique seront annoncés ici.', 'Names of editors and scientific committee members will be announced here.')) + '</p></div>') +
    '</div></section>';
}

function viewDomains() {
  return headHTML(esc(tr('Champs couverts', 'Scope')), tr('Huit domaines, une même revue', 'Eight fields, one journal'),
    tr('Matrix Bioscience accepte tout manuscrit qui relève d’un de ces domaines ou qui en relie plusieurs. En cas de doute sur le périmètre, écrivez au secrétariat avant de soumettre.', 'Matrix Bioscience accepts any manuscript that falls within one of these fields or links several of them. If you are unsure about scope, write to the editorial office before submitting.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap">' +
    DOMAINS.map(function (d) {
      return '<div class="dom r-' + d.k + '" id="dom-' + d.k + '"><div class="dom-row"><span class="dom-letter">' + d.k + '</span><span class="dots"><i></i><i></i><i></i><i></i></span></div>' +
        '<div><h2>' + esc(d[lang][0]) + '</h2><p>' + esc(d[lang][1]) + '</p><div class="cta-row" style="margin-top:18px"><a class="btn sm" href="#soumettre" data-area="' + d.k + '">' + esc(tr('Soumettre dans ce domaine', 'Submit in this field')) + '</a></div></div>' +
        '<ul class="topics">' + d[lang][2].map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>';
    }).join('') + '</div></section>';
}

var fArt = { q: '', area: '', type: '' };
function filteredArticles() {
  var q = fArt.q.trim().toLowerCase();
  return DATA.articles.filter(function (a) {
    if (fArt.area && a.area !== fArt.area) return false;
    if (fArt.type && a.type !== fArt.type) return false;
    if (q && (a.title + ' ' + a.authors + ' ' + (a.abstract || '')).toLowerCase().indexOf(q) < 0) return false;
    return true;
  }).sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')); });
}
function articleList() {
  var l = filteredArticles();
  if (l.length) return l.map(articleItem).join('');
  if (DATA.articles.length) return '<div class="empty"><h3>' + esc(tr('Aucun résultat', 'No result')) + '</h3><p>' + esc(tr('Aucun article ne correspond à ces filtres.', 'No article matches these filters.')) + '</p></div>';
  return '<div class="empty"><h3>' + esc(tr('Le premier numéro est en préparation', 'The first issue is in preparation')) + '</h3><p>' + esc(tr('Les articles acceptés seront publiés ici, un par un, avec leur DOI et leur PDF en accès libre.', 'Accepted articles will be published here one by one, with their DOI and open-access PDF.')) + '</p><a class="btn primary sm" href="#soumettre">' + esc(tr('Proposer un manuscrit', 'Propose a manuscript')) + '</a></div>';
}
function viewArticles() {
  return headHTML(esc(issueLabel()), tr('Articles', 'Articles'), tr('Tous les articles sont en accès libre. Filtrez par domaine ou par type.', 'All articles are open access. Filter by field or type.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="filters">' +
    '<div class="fld"><label for="fa-q">' + esc(tr('Recherche', 'Search')) + '</label><input type="search" id="fa-q" data-fa="q" value="' + esc(fArt.q) + '" placeholder="' + esc(tr('Titre, auteur, mot du résumé', 'Title, author, abstract word')) + '"></div>' +
    '<div class="fld"><label for="fa-area">' + esc(tr('Domaine', 'Field')) + '</label><select id="fa-area" data-fa="area"><option value="">' + esc(tr('Tous', 'All')) + '</option>' + DOMAINS.map(function (d) { return '<option value="' + d.k + '"' + (fArt.area === d.k ? ' selected' : '') + '>' + esc(d[lang][0]) + '</option>'; }).join('') + '</select></div>' +
    '<div class="fld"><label for="fa-type">Type</label><select id="fa-type" data-fa="type"><option value="">' + esc(tr('Tous', 'All')) + '</option>' + TYPES.map(function (t) { return '<option value="' + t[0] + '"' + (fArt.type === t[0] ? ' selected' : '') + '>' + esc(lang === 'fr' ? t[1] : t[2]) + '</option>'; }).join('') + '</select></div>' +
    '</div><div id="art-list">' + articleList() + '</div></div></section>';
}

function viewBoard() {
  var groups = ROLES.map(function (r) { return { r: r, list: sortedBoard().filter(function (m) { return m.role === r[0]; }) }; }).filter(function (g) { return g.list.length; });
  return headHTML(esc(tr('Gouvernance scientifique', 'Scientific governance')), tr('Comité éditorial', 'Editorial board'),
    tr('Les rédacteurs décident des manuscrits retenus pour évaluation et des décisions finales. Les membres du comité scientifique orientent la politique de la revue et relisent des manuscrits.', 'Editors decide which manuscripts go to review and make final decisions. Scientific committee members guide journal policy and review manuscripts.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap">' +
    (groups.length ? groups.map(function (g) {
      return '<div class="board-group"><div><h2>' + esc(lang === 'fr' ? g.r[3] : g.r[4]) + '</h2><p class="n">' + g.list.length + '</p></div><div class="members">' + g.list.map(memberHTML).join('') + '</div></div>';
    }).join('') : '<div class="empty"><h3>' + esc(tr('Comité en cours de constitution', 'Board being assembled')) + '</h3><p>' + esc(tr('Les noms seront annoncés ici.', 'Names will be announced here.')) + '</p></div>') +
    '<div class="panel" style="margin-top:36px;display:flex;justify-content:space-between;gap:20px;align-items:center;flex-wrap:wrap"><div style="max-width:38em"><h3 style="font-size:20px;font-weight:650">' + esc(tr('Devenir relecteur ou membre du comité', 'Become a reviewer or board member')) + '</h3><p class="muted" style="margin-top:6px">' + esc(tr('Nous recherchons des chercheurs actifs dans chacun des huit domaines. Envoyez un CV court et vos domaines d’expertise au secrétariat.', 'We are looking for active researchers in each of the eight fields. Send a short CV and your areas of expertise to the editorial office.')) + '</p></div><a class="btn" href="#contact">' + esc(tr('Contacter le secrétariat', 'Contact the editorial office')) + '</a></div>' +
    '</div></section>';
}

function viewGuidelines() {
  var secs = [
    ['types', tr('Types d’articles', 'Article types'), '<div class="tbl-wrap"><table><thead><tr><th>Type</th><th class="num">' + esc(tr('Mots (max.)', 'Words (max.)')) + '</th><th class="num">' + esc(tr('Résumé (max.)', 'Abstract (max.)')) + '</th><th>' + esc(tr('Contenu', 'Content')) + '</th></tr></thead><tbody>' +
      TYPES.map(function (t) { return '<tr><td><b>' + esc(lang === 'fr' ? t[1] : t[2]) + '</b></td><td class="num">' + t[3].toLocaleString(lang === 'fr' ? 'fr-FR' : 'en-GB') + '</td><td class="num">' + t[4] + '</td><td>' + esc(lang === 'fr' ? t[5] : t[6]) + '</td></tr>'; }).join('') +
      '</tbody></table></div><p class="muted" style="font-size:15px">' + esc(tr('Le texte principal s’entend hors résumé, références, légendes et tableaux. Un dépassement raisonnable est discuté avec l’éditeur avant la soumission.', 'Main text excludes abstract, references, legends and tables. A reasonable excess is discussed with the editor before submission.')) + '</p>'],
    ['structure', tr('Structure du manuscrit', 'Manuscript structure'),
      tr('<p><b>Page de titre.</b> Titre précis (jusqu’à 20 mots), auteurs avec affiliations et ORCID, auteur correspondant, mots-clés (3 à 8).</p><p><b>Résumé.</b> Un seul paragraphe pour les articles de recherche : contexte, objectif, méthodes, résultats principaux, conclusion. Fournissez-le en anglais et en français.</p><p><b>Corps du texte.</b> Introduction, matériel et méthodes, résultats, discussion, conclusion. Les revues de littérature remplacent méthodes et résultats par une section décrivant la stratégie de recherche bibliographique.</p><p><b>Fin d’article.</b> Contributions des auteurs (taxonomie CRediT), financement, conflits d’intérêts, éthique, disponibilité des données, remerciements, références.</p>',
        '<p><b>Title page.</b> Precise title (up to 20 words), authors with affiliations and ORCID, corresponding author, keywords (3 to 8).</p><p><b>Abstract.</b> A single paragraph for research articles: background, aim, methods, main results, conclusion. Provide it in English and French.</p><p><b>Main text.</b> Introduction, materials and methods, results, discussion, conclusion. Reviews replace methods and results with a section describing the literature search strategy.</p><p><b>End matter.</b> Author contributions (CRediT taxonomy), funding, conflicts of interest, ethics, data availability, acknowledgements, references.</p>')],
    ['format', tr('Mise en forme', 'Formatting'),
      tr('<ul><li>Dépôt du manuscrit en PDF lors de la soumission. La version Word éditable est demandée avec la révision.</li><li>Police de 11 points, interligne 1,5, numérotation continue des lignes et des pages.</li><li>Figures en 300 dpi minimum, avec légende autonome. Tableaux modifiables, jamais sous forme d’image.</li><li>Unités du Système international. Noms d’espèces en italique, nom complet à la première mention.</li><li>Souches microbiennes : numéro de collection ou de dépôt. Séquences : numéro d’accès dans une base publique.</li></ul>',
        '<ul><li>Upload the manuscript as a PDF at submission. The editable Word version is requested with the revision.</li><li>11-point font, 1.5 line spacing, continuous line and page numbers.</li><li>Figures at 300 dpi minimum, each with a self-contained legend. Editable tables, never as images.</li><li>SI units. Species names in italics, full name at first mention.</li><li>Microbial strains: collection or deposit number. Sequences: accession number in a public database.</li></ul>')],
    ['refs', tr('Références', 'References'),
      tr('<p>Références numérotées dans l’ordre d’apparition, au format Vancouver, avec le DOI quand il existe. Citez de préférence des sources évaluées par des pairs. Toute donnée non publiée ou communication personnelle se signale dans le texte, pas dans la liste.</p>',
        '<p>References numbered in order of appearance, Vancouver format, with the DOI when one exists. Prefer peer-reviewed sources. Unpublished data and personal communications are flagged in the text, not in the list.</p>')],
    ['avant', tr('Avant de soumettre', 'Before you submit'),
      tr('<ul><li>Le manuscrit est original et n’est pas en évaluation ailleurs.</li><li>Tous les auteurs ont lu et approuvé la version soumise.</li><li>L’approbation éthique, le consentement et les autorisations de prélèvement sont documentés.</li><li>Les données et les souches sont accessibles ou leur restriction est justifiée.</li><li>Tout recours à un outil d’intelligence artificielle générative est déclaré.</li></ul>',
        '<ul><li>The manuscript is original and not under review elsewhere.</li><li>All authors have read and approved the submitted version.</li><li>Ethics approval, consent and collection permits are documented.</li><li>Data and strains are accessible or any restriction is justified.</li><li>Any use of generative AI tools is declared.</li></ul>')],
    ['apres', tr('Après acceptation', 'After acceptance'),
      tr('<p>Les épreuves sont envoyées à l’auteur correspondant, qui dispose de quelques jours pour les corriger. L’article est ensuite publié avec son DOI. Les auteurs conservent leur droit d’auteur et le texte est diffusé sous licence CC BY 4.0.</p>',
        '<p>Proofs are sent to the corresponding author, who has a few days to correct them. The article is then published with its DOI. Authors keep their copyright and the text is released under a CC BY 4.0 licence.</p>')]
  ];
  return headHTML(esc(tr('Pour les auteurs', 'For authors')), tr('Instructions aux auteurs', 'Author guidelines'), tr('Ce qu’il faut préparer avant d’ouvrir le formulaire de soumission.', 'What to prepare before opening the submission form.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap two-col"><nav class="toc" aria-label="' + esc(tr('Sur cette page', 'On this page')) + '">' +
    secs.map(function (s) { return '<a href="#auteurs" data-scroll="g-' + s[0] + '">' + esc(s[1]) + '</a>'; }).join('') + '</nav>' +
    '<div class="prose">' + secs.map(function (s) { return '<h2 id="g-' + s[0] + '" style="scroll-margin-top:90px">' + esc(s[1]) + '</h2>' + s[2]; }).join('') +
    '<div class="cta-row" style="margin-top:36px"><a class="btn primary" href="#soumettre">' + esc(tr('Ouvrir le formulaire de soumission', 'Open the submission form')) + '</a></div></div></div></section>';
}

function viewPolicies() {
  var P = [
    [tr('Évaluation par les pairs', 'Peer review'), tr('Chaque manuscrit passe d’abord un contrôle éditorial portant sur le périmètre, la forme et la similarité avec des textes existants. Les manuscrits retenus sont envoyés à au moins deux relecteurs indépendants, en double anonymat : les relecteurs ignorent l’identité des auteurs et les auteurs celle des relecteurs. Les décisions possibles sont l’acceptation, la révision mineure, la révision majeure et le refus. Un auteur qui conteste une décision peut écrire à l’éditeur en argumentant ; un second avis est alors demandé à un rédacteur qui n’a pas traité le manuscrit.', 'Every manuscript first goes through an editorial check of scope, format and similarity with existing texts. Retained manuscripts go to at least two independent reviewers, double-anonymous: reviewers do not know the authors and authors do not know the reviewers. Possible decisions are acceptance, minor revision, major revision and rejection. An author who disputes a decision may write to the editor with arguments; a second opinion is then requested from an editor who did not handle the manuscript.')],
    [tr('Accès libre et licence', 'Open access and licence'), tr('Tous les articles sont lisibles gratuitement dès leur publication et diffusés sous licence Creative Commons CC BY 4.0. Les auteurs conservent leur droit d’auteur. Les conditions financières, y compris les éventuelles exonérations pour les auteurs de pays à revenu faible, sont communiquées avant l’acceptation et jamais après.', 'All articles are free to read on publication and released under a Creative Commons CC BY 4.0 licence. Authors keep their copyright. Financial terms, including any waivers for authors from low-income countries, are communicated before acceptance and never after.')],
    [tr('Éthique de la recherche', 'Research ethics'), tr('Les études sur des personnes exigent l’approbation d’un comité d’éthique et un consentement éclairé. Les études sur des animaux suivent les lignes directrices ARRIVE et l’approbation d’un comité compétent. Les essais cliniques doivent être enregistrés avant l’inclusion du premier participant. Pour les ressources génétiques et les souches prélevées dans un pays, les auteurs indiquent les autorisations obtenues, y compris au titre du Protocole de Nagoya. Les travaux à risque biologique précisent le niveau de biosécurité utilisé.', 'Studies on people require ethics committee approval and informed consent. Animal studies follow the ARRIVE guidelines and approval by a competent committee. Clinical trials must be registered before the first participant is enrolled. For genetic resources and strains collected in a country, authors state the permits obtained, including under the Nagoya Protocol. Work with biological risk states the biosafety level used.')],
    [tr('Intégrité, plagiat et images', 'Integrity, plagiarism and images'), tr('Les manuscrits sont contrôlés avec un logiciel de similarité avant l’évaluation. La revue refuse le plagiat, y compris le plagiat de ses propres textes, la fabrication ou la falsification de données et la manipulation d’images. Des images originales (gels, immunoempreintes, microscopie) peuvent être demandées. Les manuscrits issus d’officines de rédaction sont refusés.', 'Manuscripts are screened with similarity software before review. The journal rejects plagiarism, including self-plagiarism, fabrication or falsification of data, and image manipulation. Original images (gels, blots, microscopy) may be requested. Manuscripts from paper mills are rejected.')],
    [tr('Auteurs et contributions', 'Authorship and contributions'), tr('Est auteur toute personne qui a contribué de façon substantielle à la conception, aux données ou à leur analyse, a participé à la rédaction et approuve la version finale. Les contributions sont décrites selon la taxonomie CRediT. Tout ajout, retrait ou changement d’ordre des auteurs après la soumission exige l’accord écrit de tous les auteurs concernés.', 'An author is anyone who made a substantial contribution to the design, the data or their analysis, took part in drafting and approves the final version. Contributions are described with the CRediT taxonomy. Any addition, removal or reordering of authors after submission requires written agreement from all authors involved.')],
    [tr('Conflits d’intérêts', 'Conflicts of interest'), tr('Auteurs, relecteurs et rédacteurs déclarent tout lien financier ou personnel susceptible d’influencer le travail ou son évaluation. Un rédacteur ne traite pas un manuscrit de son entourage proche ni de sa propre institution. Les auteurs peuvent proposer jusqu’à trois relecteurs et en exclure ; l’éditeur n’est pas tenu de suivre ces suggestions.', 'Authors, reviewers and editors declare any financial or personal tie that could influence the work or its evaluation. An editor does not handle a manuscript from a close associate or their own institution. Authors may suggest up to three reviewers and exclude some; the editor is not bound by these suggestions.')],
    [tr('Données et matériel', 'Data and materials'), tr('Chaque article comporte une déclaration de disponibilité des données. Les séquences sont déposées dans une base publique avant la publication et les souches dans une collection reconnue quand c’est possible. Si les données ne peuvent pas être partagées, la raison est exposée.', 'Each article carries a data availability statement. Sequences are deposited in a public database before publication and strains in a recognised collection when possible. If data cannot be shared, the reason is stated.')],
    [tr('Intelligence artificielle', 'Artificial intelligence'), tr('Un outil d’IA ne peut pas être auteur. Les auteurs déclarent tout usage d’un outil génératif dans la rédaction, l’analyse ou la production d’images, et restent responsables du contenu. Les relecteurs et rédacteurs ne déposent pas de manuscrits confidentiels dans des outils d’IA accessibles au public.', 'An AI tool cannot be an author. Authors declare any use of a generative tool in writing, analysis or image production, and remain responsible for the content. Reviewers and editors do not upload confidential manuscripts to publicly accessible AI tools.')],
    [tr('Corrections et rétractations', 'Corrections and retractions'), tr('Une erreur qui modifie l’interprétation d’un article donne lieu à un erratum. Un article dont les conclusions sont invalidées par une faute ou une inconduite est rétracté ; la notice reste liée à l’article, qui demeure consultable avec la mention de rétractation. La revue s’appuie sur les recommandations du Committee on Publication Ethics (COPE) pour instruire les plaintes.', 'An error that changes the interpretation of an article leads to a correction. An article whose conclusions are invalidated by error or misconduct is retracted; the notice stays linked to the article, which remains accessible with a retraction mark. The journal relies on the Committee on Publication Ethics (COPE) recommendations to investigate complaints.')],
    [tr('Confidentialité et archivage', 'Confidentiality and archiving'), tr('Les manuscrits soumis sont confidentiels jusqu’à leur publication. Les données personnelles des auteurs et des relecteurs servent uniquement à la gestion éditoriale. Les articles publiés sont conservés dans au moins une archive numérique pérenne.', 'Submitted manuscripts are confidential until publication. Personal data of authors and reviewers is used solely for editorial management. Published articles are preserved in at least one long-term digital archive.')]
  ];
  return headHTML(esc(tr('Règles de la revue', 'Journal rules')), tr('Politiques éditoriales', 'Editorial policies'), tr('Ces règles s’appliquent aux auteurs, aux relecteurs et aux rédacteurs.', 'These rules apply to authors, reviewers and editors.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="acc">' +
    P.map(function (p, i) { return '<details' + (i === 0 ? ' open' : '') + '><summary>' + esc(p[0]) + '</summary><div class="body"><p>' + esc(p[1]) + '</p></div></details>'; }).join('') + '</div></div></section>';
}

function viewContact() {
  var s = DATA.settings;
  var mail = s.email ? '<p class="mono" style="font-size:17px;overflow-wrap:anywhere">' + esc(s.email) + '</p><button class="btn sm" data-copy="' + esc(s.email) + '" style="margin-top:12px">' + esc(tr('Copier l’adresse', 'Copy address')) + '</button>' :
    '<p class="muted">' + esc(tr('L’adresse du secrétariat sera publiée prochainement.', 'The editorial office address will be published soon.')) + '</p>' + (cap.admin ? '<p class="hint" style="margin-top:8px">' + esc(tr('Renseignez-la dans Espace éditorial > Paramètres.', 'Set it under Editorial desk > Settings.')) + '</p>' : '');
  return headHTML(esc(tr('Secrétariat de rédaction', 'Editorial office')), 'Contact', tr('Pour une question avant soumission, une proposition de numéro spécial ou une candidature de relecteur.', 'For a pre-submission question, a special issue proposal or a reviewer application.')) +
    '<section class="band tight" style="padding-top:8px"><div class="wrap"><div class="grid g3">' +
    '<div class="panel"><h3 style="font-size:19px;font-weight:650;margin-bottom:12px">' + esc(tr('Adresse du secrétariat', 'Editorial office address')) + '</h3>' + mail + '</div>' +
    '<div class="panel"><h3 style="font-size:19px;font-weight:650;margin-bottom:12px">' + esc(tr('Publication', 'Publisher')) + '</h3><p>' + esc(s.publisher || tr('Éditeur à préciser', 'Publisher to be announced')) + '</p>' + (s.address ? '<p class="muted" style="margin-top:8px">' + esc(s.address).replace(/\n/g, '<br>') + '</p>' : '') + '<p class="mono muted" style="margin-top:12px;font-size:12.5px">' + issnText() + '</p></div>' +
    '<div class="panel"><h3 style="font-size:19px;font-weight:650;margin-bottom:12px">' + esc(tr('Numéros spéciaux', 'Special issues')) + '</h3><p class="muted">' + esc(tr('Une thématique, une liste de contributeurs pressentis et un calendrier suffisent pour ouvrir la discussion. Indiquez ces éléments dans votre message.', 'A theme, a list of prospective contributors and a timeline are enough to start the discussion. Include them in your message.')) + '</p></div>' +
    '</div></div></section>';
}
